# -*- coding: utf-8 -*-
# Plugin by WooshMan - Modified by Emil Nabil for Dreambox official images

from Plugins.Plugin import PluginDescriptor
import shutil
import os, random

screens = '/usr/share/bootlogos/'
logopath = '/etc/enigma2/'
bootlogo_path = '/usr/share/dreambox-bootlogo/'  

def autostart(reason, **kwargs):
    if reason != 0:
        return

    for logo in ['bootlogo.mvi', 'backdrop.mvi', 'bootlogo_wait.mvi']:
        target_file = os.path.join(logopath, logo)
        if os.path.exists(target_file):
            try:
                os.remove(target_file)
            except Exception:
                pass

    if os.path.isdir(screens):
        available_logos = [f for f in os.listdir(screens) if f.endswith('.mvi')]
        if available_logos:
            newscreen = random.choice(available_logos)
            source_logo = os.path.join(screens, newscreen)

            try:
                shutil.copy(source_logo, os.path.join(bootlogo_path, 'bootlogo.mvi'))
                shutil.copy(source_logo, os.path.join(bootlogo_path, 'backdrop.mvi'))
                shutil.copy(source_logo, os.path.join(bootlogo_path, 'bootlogo_wait.mvi'))
            except Exception as e:
                print("[BootLogoSwapper] Error copying logo:", str(e))

def Plugins(**kwargs):
    return PluginDescriptor(
        name="-Boot Logo Swap",
        description="Boot Logo Swapper (Dreambox Official Images Compatible)",
        where=PluginDescriptor.WHERE_AUTOSTART,
        icon="/usr/lib/enigma2/python/Plugins/Extensions/BootLogoSwap-Gemini/images/plugin.png",
        fnc=autostart
    )





