# -*- coding: utf-8 -*-
from gLocale import ArchBox, OEversion
from Tools.Directories import createDir, pathExists
from Tools.HardwareInfo import HardwareInfo
from Tools.Log import Log
from gVersion import gVersion
from twisted.web.client import downloadPage
import os

def CheckGeminiApt():
	KEYFILE="/tmp/gemini4.key"
	#Wegen Backup nicht in /etc/enigma2
	INITFILE="/etc/GP-Feed-init"
	INITKEY="/etc/GP-Key-init"
	
	oe="krogoth"
	if OEversion=="2.6.0":
		oe="pyro"

	def _createFeedConf(version, url, typ):
		fname="/etc/apt/sources.list.d/%s-%s-feed.list" %(version,typ)
		if pathExists(fname)==False:
			try:
				wfile = open(fname, 'w')
				wfile.write("deb %s%s ./\n" % (url,typ))
				wfile.close()
				Log.i("'%s' create"%fname)
			except Exception, e:
				Log.e(e)
		else:
			Log.i("'%s' found"%fname)
			
	def __installkey(val=None):
		if pathExists(KEYFILE):
			cmd = "apt-key add '%s'" %KEYFILE
			os.system(cmd)
			try:
				open(INITKEY, 'w').close()
				Log.i("keyfile installed")
				os.remove(KEYFILE)
			except Exception, e:
				Log.e(e)
			
	def __downloadERR(error):
		Log.e(error.getErrorMessage())
			
	#print "-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-"
	
	#data und cache Ordner anlegen
	if pathExists("/data")==False:
		createDir("/data")
	if pathExists("/tmp/.cache/gemini")==False:
		createDir("/tmp/.cache/gemini",True)
		
	#wenn INITFILE nicht vorhanden apt-Listen erstellen
	if pathExists(INITFILE)==False and ArchBox and OEversion:
		apturl=None
		if ArchBox=="armhf":
			extraPlugins="extraPluginsArmhf"
			apturl="http://download.blue-panel.com/%s/gemini4-unstable/" %oe
		elif ArchBox=="mipsel":
			extraPlugins="extraPluginsMipsel"
			apturl="http://download.blue-panel.com/%s/gemini4-unstable/" %oe
		elif ArchBox=="aarch64":
			extraPlugins="extraPluginsAarch64"
			apturl="http://download.blue-panel.com/%s/gemini4-unstable/" %oe
			
		if apturl:
			device = HardwareInfo().get_device_name()
			_createFeedConf(gVersion,apturl,ArchBox)
			_createFeedConf(gVersion,apturl,device)
			_createFeedConf(gVersion,apturl,'all')
			_createFeedConf(gVersion,apturl,'allcodes')
			_createFeedConf(gVersion,apturl,extraPlugins)
		
			try:
				open(INITFILE, 'w').close()
				from Components.config import config
				config.misc.recording_allowed.value = True
				config.misc.recording_allowed.save()
			except Exception, e:
				Log.e(e)
			
	#key file installieren
	if os.path.exists(INITKEY)==False and OEversion:
		url="http://download.blue-panel.com/info@ihad.tv.key"
		if OEversion=="2.6.0":
			url="http://download.blue-panel.com/pyro/gemini4-unstable/keyFile.key"
		Log.i("download keyfile")
		downloadPage(url, KEYFILE, timeout=10).addCallback(__installkey).addErrback(__downloadERR)

CheckGeminiApt()
