from __future__ import print_function
from __future__ import division

#
# Alan Turing Plugins (c) gutemine 2023
#
import gettext
import time
from Components.Slider import Slider
from datetime import date
from os import (
    path as os_path,
    listdir as os_listdir,
    remove as os_remove,
    rename as os_rename,
    symlink as os_symlink,
    stat as os_stat,
    mkdir as os_mkdir,
)
from Components.Pixmap import Pixmap
from Plugins.Plugin import PluginDescriptor
from Screens.Console import Console
from Components.ConfigList import ConfigListScreen, ConfigList
from Components.config import (
    config,
    configfile,
    ConfigSubsection,
    ConfigText,
    ConfigBoolean,
    ConfigInteger,
    ConfigSelection,
    ConfigSlider,
    ConfigLocations,
    ConfigSelectionNumber,
    getConfigListEntry,
    ConfigSubList,
)
from Tools.LoadPixmap import LoadPixmap
from Components.Sources.StaticText import StaticText
from Components.Sources.Clock import Clock
from Components.Input import Input
from Components.MenuList import MenuList
from Components.GUIComponent import *
from Components.Label import Label, MultiColorLabel
from Components.ScrollLabel import ScrollLabel
from Components.ActionMap import ActionMap, NumberActionMap, HelpableActionMap
from Screens.Standby import TryQuitMainloop
from Screens.ChoiceBox import ChoiceBox
from Screens.InputBox import InputBox
from Screens.MessageBox import MessageBox
from Screens.HelpMenu import HelpableScreen
from Screens.Screen import Screen
from enigma import (
    runMainloop,
    quitMainloop,
    eActionMap,
    eSize,
    eTimer,
    eConsoleAppContainer,
    eEnv,
    iServiceInformation,
    fbClass,
    eRCInput,
    eDBoxLCD,
    gMainDC,
    getDesktop,
)
import gm

at_version = gm.version()
#
# from twisted.internet import reactor
if os_path.exists("/var/lib/dpkg/status"):
    from enigma import eFileWatch, eFileEvent

at_boxtype = gm.boxtype()
at_images = "/media/at"
at_logfile = "/tmp/gm.log"
# maximum imagename of tar.* images
at_maxlen = 128
at_backups = "/data/backup"
if os_path.exists("/media/hdd/backup"):
    at_backups = "/media/hdd/backup"
gutemine_plugindir = "/usr/lib/enigma2/python/Plugins/SystemPlugins/gutemine"
at_plugindir = "/usr/lib/enigma2/python/Plugins/Extensions/AlanTuring"
ba_plugin = "/usr/lib/enigma2/python/Plugins/Extensions/AlanTuring/BarryAllen.py"
at_title = "Alan Turing"
at_description = "The Enigma" 
at_background = "Silver"
ba_title = "Barry Allen"
notinstalled_string = _("%s is not installed") % at_title
at_busy = "/tmp/gm.pid"
global at_progress
at_progress = 0
global at_duration
at_duration = 0
global at_file
at_file = None
at1 = "Alan Mathison Turing 1912-1954"
at2 = "Father of Computer Science, Mathematician, Logician,"
at3 = "Wartime Codebreaker and Victim of Prejudice."
at4 = _("%s %s (c) gutemine 2022 %s") % (at_title, at_version, at_boxtype)
at5 = "%s %s (c) gutemine3 %s" % (at_title, _("Help"), gm.version())

def atShowInformation(session, **kwargs):
    session.open(AlanTuringInformation)

def atMain(session, **kwargs):
    session.open(AlanTuring)

def atMainConf(menuid):
    cprint(menuid)
    if menuid == "information":
        return [(_("About") + " " + at_title, atShowInformation, "alanturinginfo", None)]
    elif menuid == "menu_information":
        return [(_("About") + " " + at_title, atShowInformation, "alanturinginfo", None)]
    elif menuid == "setup":
        return [(at_title, atMain, "alanturingmain", None)]
    else:
        return []

def at_mountpoint_chosen(option):
    cprint(">>>>>>>>>>>>>> CALLING mountpoint_chosen")
    if option is None:
        return
    (description, mountpoint, session) = option
    if not config.plugins.alanturing.mediascanner.value:
        at_device = gm.device()
        cprint(at_device)
        hdd_device = gm.getdevice("/media/hdd")
        cprint(hdd_device)
        # ignore @ device
        if at_device.startswith("/dev/"):
            at_autofs = "/autofs/%s" % at_device.replace("/dev/", "")
            cprint("%s = %s" % (at_autofs, mountpoint))
            if at_autofs.startswith(mountpoint.rstrip("/")):
                cprint("ignoring @ device %s" % at_device)
                return
        # ignore Harddisk device
        if hdd_device.startswith("/dev/"):
            hdd_autofs = "/autofs/%s" % hdd_device.replace("/dev/", "")
            cprint("%s = %s" % (hdd_autofs, mountpoint))
            if hdd_autofs.startswith(mountpoint.rstrip("/")):
                cprint("ignoring Harddisk device %s" % hdd_device)
                return
    mountpoint_chosen_ori(option)

def atMediascanner():
    if os_path.exists("/usr/lib/enigma2/python/Plugins/Extensions/MediaScanner") and not config.plugins.alanturing.mediascanner.value:
        import Plugins.Extensions.MediaScanner.plugin
        # rename on startup
        try:
            cprint(">>>>>>>>>>>>>> RENAME mountpoint_chosen")
            from Plugins.Extensions.MediaScanner.plugin import (
                mountpoint_chosen as mountpoint_chosen_ori,
            )

            Plugins.Extensions.MediaScanner.plugin.mountpoint_chosen = at_mountpoint_chosen
        except:
            cprint(">>>>>>>>>>>>>> RENAME mountpoint_choosen")
            from Plugins.Extensions.MediaScanner.plugin import (
                mountpoint_choosen as mountpoint_chosen_ori,
            )
            Plugins.Extensions.MediaScanner.plugin.mountpoint_choosen = at_mountpoint_chosen

def atSessionStart(reason, **kwargs):
    if reason == 0 and "session" in kwargs:
        atMediascanner()
        atWebInterface()

storagedevice_description = {"desc": _("storage device"), "Desc": _("Storage device")}

CYANC = "\033[36m"
ENDC = "\033[m"


def cprint(text):
    print(CYANC + "[@] " + text + ENDC + "\n")


def audio2Help():
    cprint("AUDIO pressed")
    # Device Types
    TYPE_STANDARD = "dreambox remote control (native)"
    TYPE_ADVANCED = "dreambox advanced remote control (native)"
    TYPE_KEYBOARD = "dreambox ir keyboard"

    # Advanced remote or standard?
    if config.misc.rcused.value == 0:
        remotetype = TYPE_ADVANCED
    else:
        remotetype = TYPE_STANDARD
    eam = eActionMap.getInstance()
    # press the key with the desired flag
    keycode = 138  # HELP key
    cprint("NOW WRITES OUT: %i = HELP" % (keycode))
    eam.keyPressed(remotetype, keycode, 0)
    # release the key
    eam.keyPressed(remotetype, keycode, 1)

def atWebInterface():
    if os_path.exists("/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/WebChilds/Toplevel.py"):
        from Plugins.Extensions.WebInterface.WebChilds.Toplevel import addExternalChild
        addExternalChild(("alanturing", AlanTuringWeb(), "Alan Turing", "1", True))
    else:
        cprint("Webif not found")

yes_no_descriptions = {False: _("no"), True: _("yes")}

def createConfig():
    if not hasattr(config.plugins, "gutemine"):
        config.plugins.gutemine = ConfigSubsection()
    if not hasattr(config.plugins.gutemine, "backupdate"):
        config.plugins.gutemine.backupdate = ConfigBoolean(
            default=True, descriptions=yes_no_descriptions
        )
    if not hasattr(config.plugins.gutemine, "backuptime"):
        config.plugins.gutemine.backuptime = ConfigBoolean(
            default=False, descriptions=yes_no_descriptions
        )

    if not hasattr(config.plugins, "configurationbackup"):
        config.plugins.configurationbackup = ConfigSubsection()
    if not hasattr(config.plugins.configurationbackup, "backuplocation"):
        config.plugins.configurationbackup.backuplocation = ConfigText(
            default="/media/hdd/", visible_width=50, fixed_size=False
        )
    if not hasattr(config.plugins.configurationbackup, "backupdirs"):
        config.plugins.configurationbackup.backupdirs = ConfigLocations(
            default=[eEnv.resolve("${sysconfdir}/enigma2/"), "/etc/hostname"]
        )

    if not hasattr(config.plugins, "alanturing"):
        config.plugins.alanturing = ConfigSubsection()
    if not hasattr(config.plugins.alanturing, "confirm"):
        config.plugins.alanturing.confirm = ConfigBoolean(
            default=True, descriptions=yes_no_descriptions
        )
    if not hasattr(config.plugins.alanturing, "backupdirselect"):
        config.plugins.alanturing.backupdirselect = ConfigBoolean(
            default=False, descriptions=yes_no_descriptions
        )
    if not hasattr(config.plugins.alanturing, "lazyinit"):
        config.plugins.alanturing.lazyinit = ConfigBoolean(
            default=False, descriptions=yes_no_descriptions
        )
    if not hasattr(config.plugins.alanturing, "resize"):
        config.plugins.alanturing.resize = ConfigBoolean(
            default=False, descriptions=yes_no_descriptions
        )
    if not hasattr(config.plugins.alanturing, "uboot"):
        config.plugins.alanturing.uboot = ConfigBoolean(
            default=False, descriptions=yes_no_descriptions
        )
    partition_options = []
    partition_options.append(("0", _("none")))
    partition_options.append(("1", _("1")))
    config.plugins.alanturing.partition = ConfigSelection(
        default="0", choices=partition_options
    )
    backups_options = []
    backups_options.append(("/data/backup", "/data/backup"))
    if os_path.exists("/media/hdd/backup"):
        backups_options.append(("/media/hdd/backup", "/media/hdd/backup"))
    if not hasattr(config.plugins.alanturing, "backuplocation"):
        config.plugins.alanturing.backuplocation = ConfigSelection(default="/data/backup", choices=backups_options)

    devices = gm.devices()
    devices_options = []
    devices_options.append(("none", _("none")))
    devices_options.append(("", _("Automatic")))
    for device in devices:
        devices_options.append((device, device))
    if not hasattr(config.plugins.alanturing, "device"):
        config.plugins.alanturing.device = ConfigSelection(default="", choices=devices_options)
    if not hasattr(config.plugins.alanturing, "image"):
        config.plugins.alanturing.images = ConfigSubList()
    image_options = []
    image_options.append(("image", _(" ")))
    image_options.append(("select", _("Select")))
    image_options.append(("backup", _("Backup")))
    image_options.append(("rename", _("Rename")))
    image_options.append(("remove", _("Remove")))
    image_options.append(("copy", _("Copy")))
    image_options.append(("update", _("Update")))
    image_options.append(("purge", _("Reset")))
    for x in range(17):
        config.plugins.alanturing.images.append(ConfigSubsection())
        config.plugins.alanturing.images[x].action = ConfigSelection(
            default="image", choices=image_options
        )
    config.plugins.alanturing.backups = ConfigSubList()
    backup_options = []
    backup_options.append(("backup", _(" ")))
    backup_options.append(("restore", _("Restore")))
    backup_options.append(("rename", _("Rename")))
    backup_options.append(("remove", _("Remove")))
    backup_options.append(("copy", _("Copy")))
    for x in range(70):
        config.plugins.alanturing.backups.append(ConfigSubsection())
        config.plugins.alanturing.backups[x].action = ConfigSelection(
            default="backup", choices=backup_options
        )
    config.plugins.alanturing.bootmenu = ConfigBoolean(
            default=True, descriptions=yes_no_descriptions
        )
    config.plugins.alanturing.progress = ConfigBoolean(
            default=True, descriptions=yes_no_descriptions
        )
    config.plugins.alanturing.timeout = ConfigSlider(
        default=10, increment=1, limits=(5, 30)
        )
    if os_path.exists(ba_plugin):
        config.plugins.alanturing.grey = ConfigSlider(default=0, increment=5, limits=(0, 100))
    else:
        config.plugins.alanturing.grey = ConfigSlider(default=20, increment=5, limits=(0, 100))
    display_options = []
    display_options.append(("clock", _("Clock")))
    display_options.append(("alanturing", at_title))
    display_options.append(("dreambox", _("Dreambox")))
    display_options.append(("nothing", _("nothing")))
    config.plugins.alanturing.displayentry = ConfigSelection(
            default="alanturing", choices=display_options
        )
    config.plugins.alanturing.transparency = ConfigSlider(
            default=0, increment=5, limits=(0, 255)
        )
    config.plugins.alanturing.freespace = ConfigSlider(
        default=0, increment=1, limits=(0, 65536)
        )
    config.plugins.alanturing.hdd = ConfigBoolean(
        default=False, descriptions=yes_no_descriptions
        )
    config.plugins.alanturing.pwdreset = ConfigBoolean(
        default=False, descriptions=yes_no_descriptions
        )
    config.plugins.alanturing.mediascanner = ConfigBoolean(
        default=True, descriptions=yes_no_descriptions
        )
    backuptools = []
    backuptools.append(("tar.gz", _("tar.gz")))
    if os_path.exists("/usr/bin/xz"):
        rp = os_path.realpath("/usr/bin/xz")
        if not rp.startswith("/bin/busybox"):
            backuptools.append(("tar.xz", _("tar.xz")))
    if os_path.exists("/usr/bin/pbzip2"):
        backuptools.append(("tar.bz2", _("tar.bz2")))
    config.plugins.alanturing.backuptool = ConfigSelection(
        default="tar.gz", choices=backuptools
    )
    prefix_options = []
    prefix_options.append(("none", _("None")))
    prefix_options.append(("open", "open"))
    if os_path.exists("/var/lib/dpkg/status"):
        config.plugins.alanturing.settingsprefix = ConfigSelection(
            default="none", choices=prefix_options
        )
    else:
        config.plugins.alanturing.settingsprefix = ConfigSelection(
            default="open", choices=prefix_options
        )

    ok_text = _("Please press OK to continue.").rstrip(".")
    tar_options = []
    tar_options.append(("tar", ok_text))
    config.plugins.alanturing.tar = ConfigSelection(default="tar", choices=tar_options)
    xz_options = []
    xz_options.append(("xz", ok_text))
    config.plugins.alanturing.xz = ConfigSelection(default="xz", choices=xz_options)
    pixz_options = []
    pixz_options.append(("pixz", ok_text))
    config.plugins.alanturing.pixz = ConfigSelection(default="pixz", choices=pixz_options)
    pigz_options = []
    pigz_options.append(("pigz", ok_text))
    config.plugins.alanturing.pigz = ConfigSelection(default="pigz", choices=pigz_options)
    pbzip2_options = []
    pbzip2_options.append(("pbzip2", ok_text))
    config.plugins.alanturing.pbzip2 = ConfigSelection(
        default="pbzip2", choices=pbzip2_options
    )
    settingsbackup_options = []
    settingsbackup_options.append(("settingsbackup", ok_text))
    config.plugins.alanturing.settingsbackup = ConfigSelection(
        default="settingsbackup", choices=settingsbackup_options
    )
    settingsrestore_options = []
    settingsrestore_options.append(("settingsrestore", ok_text))
    config.plugins.alanturing.settingsrestore = ConfigSelection(
        default="settingsrestore", choices=settingsrestore_options
    )
    initialize_options = []
    initialize_options.append(("initialize", ok_text))
    config.plugins.alanturing.initialize = ConfigSelection(
        default="initialize", choices=initialize_options
    )
    erase_options = []
    erase_options.append(("erase", ok_text))
    config.plugins.alanturing.erase = ConfigSelection(
        default="erase", choices=erase_options
    )
    s_options = []
    s_options.append(("0", _("none")))
    s_options.append(("1", "1"))
    s_options.append(("2", "2"))
    s_options.append(("3", "3"))
    s_options.append(("4", "4"))
    s_options.append(("5", "5"))
    s_options.append(("6", "6"))
    s_options.append(("7", "7"))
    s_options.append(("8", "8"))
    s_options.append(("10", "10"))
    config.plugins.alanturing.fadetime = ConfigSelection(default="5", choices=s_options)
    config.plugins.alanturing.overwrite = ConfigBoolean(
        default=False, descriptions=yes_no_descriptions
    )
    config.plugins.alanturing.maxlen = ConfigSelectionNumber(32, 64, 1, default=36)
    resolution = []
    resolution.append(("none", _("none")))
    if os_path.exists("/proc/stb/video/videomode_choices"):
        rf = open("/proc/stb/video/videomode_choices", "r")
        line = rf.readline()
        rf.close()
        resolutions = line.split(" ")
        for res in resolutions:
            resolution.append((str(res), str(res)))
    config.plugins.alanturing.resolution = ConfigSelection(
        default="none", choices=resolution
    )
    if os_path.exists("/var/lib/dpkg/status"):
        config.plugins.alanturing.webinterface = ConfigBoolean(
            default=True, descriptions=yes_no_descriptions
        )                 
    else:             
        config.plugins.alanturing.webinterface = ConfigBoolean(
            default=False, descriptions=yes_no_descriptions
        )  
    logos = gm.logos()
    logo_option = []
    for logo in logos:
        logo_option.append((logo, logo.replace(".jpg", "")))
    if os_path.exists(ba_plugin):
        config.plugins.alanturing.logo = ConfigSelection(
            default="infinite.jpg", choices=logo_option
        )
    else:
        config.plugins.alanturing.logo = ConfigSelection(
            default="alanturing.jpg", choices=logo_option
        )
    fonts = gm.fonts()
    font_option = []
    for font in fonts:
        font_option.append((font, font.replace(".ttf", "")))
    config.plugins.alanturing.font = ConfigSelection(
        default="nmsbd.ttf", choices=font_option
    )
    debian = []
    debian.append(("none", _("none")))
    debian.append(("bullseye", "Bullseye"))
    config.plugins.alanturing.debian = ConfigSelection(default="bullseye", choices=debian)
    dummy_options = []
    dummy_options.append(("nothing", _(" ")))
    config.plugins.alanturing.dummy = ConfigSelection(
        default="nothing", choices=dummy_options
    )
    if not hasattr(config.plugins, "barryallen"):
        config.plugins.barryallen = ConfigSubsection()
    if not hasattr(config.plugins.barryallen, "imagespace"):
        config.plugins.barryallen.imagespace = ConfigBoolean(
            default=False, descriptions=yes_no_descriptions    
        )   

createConfig()

try:
    from twisted.web import resource, http
except:
    from twisted.web2 import server, resource, http
API_VERSION = "1.2"

IMAGES = 0
BACKUPS = 1
SETUP = 2
ABOUT = 3

sz_w = getDesktop(0).size().width()
sz_h = getDesktop(0).size().height()


class AlanTuringSummary(Screen):
    skin = (
        """<screen name="AlanTuringSummary" position="0,0" size="132,64" id="1">
    <widget font="Display;12" halign="center" position="6,0" render="Label" size="120,12" source="titletext" valign="center"/>
    <widget font="Display;12" halign="center" position="6,13" render="Label" size="120,12" source="duration" valign="center" />
    <widget name="slider" position="6,26" size="120,8" borderWidth="1"   borderColor="white" foregroundColor="white" transparent="1"/>
    <widget font="Display;26" halign="center" position="6,35" render="Label" size="120,28" source="displayentry" foregroundColor="white" valign="center"/>
    </screen>""",
        """<screen name="AlanTuringSummary" position="0,0" size="96,64" id="2">
    <widget font="Display;15" halign="center" position="0,0" render="Label" size="96,30" source="titletext" transparent="1" valign="center" />
    <widget backgroundColor="dark" borderWidth="1" position="0,34" size="96,8" name="slider" transparent="1" />
    <widget font="Display;15" halign="center" position="0,46" render="Label" size="96,15" source="duration" transparent="1" valign="center" foregroundColor="yellow" />
    </screen>""",
        """<screen name="AlanTuringSummary" position="0,0" size="400,240" id="3">
    <ePixmap pixmap="skin_default/display_bg.png" position="0,0" size="400,240" zPosition="-1" />
    <widget font="Display;48" halign="center" position="center,5" render="Label" size="380,100" source="titletext" transparent="1" valign="top" />
    <widget font="Display;48" halign="center" position="center,60" render="Label" size="100,50" source="duration" transparent="1" valign="center" foregroundColor="yellow" />
    <widget backgroundColor="dark" borderWidth="1" pixmap="skin_default/progress.png" position="center,112" size="380,15" name="slider" transparent="1" />
    <widget font="Display;72" halign="center" position="center,140" render="Label" size="380,84" source="displayentry" transparent="1" foregroundColor="white" valign="center" />
    </screen>""",
        """<screen name="AlanTuringSummary" position="0,0" size="240,86" id="100">
    <widget font="Display;14" halign="center" position="12,0" render="Label" size="220,24" source="titletext" valign="center"/>
    <widget font="Display;14" halign="center" position="12,16" render="Label" size="220,24" source="duration" valign="center" />
    <widget name="slider" position="12,36" size="220,10" borderWidth="1"   borderColor="white" foregroundColor="white" transparent="1"/>
    <widget font="Display;28" halign="center" position="12,48" render="Label" size="220,32" source="displayentry" foregroundColor="white" valign="center"/>
    </screen>""",
    )

    def __init__(self, session, parent):
        Screen.__init__(self, session, parent=parent)
        self.slider = Slider(0, 1024)
        self["slider"] = self.slider
        self["slider"].hide()
        self.clock = Clock()
        global at_progress
        at_progress = "0"
        global at_duration
        at_duration = 0
        if config.plugins.alanturing.displayentry.value == "clock":
            self["displayentry"] = StaticText(
                time.strftime("%H:%M", time.localtime(self.clock.time))
            )
        elif config.plugins.alanturing.displayentry.value == "alanturing":
            self["displayentry"] = StaticText(_("Alan Turing"))
        elif config.plugins.alanturing.displayentry.value == "dreambox":
            self["displayentry"] = StaticText(at_boxtype)
        else:
            self["displayentry"] = StaticText(" ")
        self["titletext"] = StaticText(at_title)
        self["size"] = StaticText(" ")
        self["duration"] = StaticText(" ")
        self.onLayoutFinish.append(self.byLayoutEnd)

    def byLayoutEnd(self):
        global at_progress
        self.slider.setValue(int(at_progress))
        if int(at_progress) > 1024:
            self.slider.setValue(int(int(at_progress) / 10))
        else:
            self.slider.setValue(int(at_progress))
        self.ClockTimer = eTimer()
        if os_path.exists("/var/lib/dpkg/status"):
            self.ClockTimer_conn = self.ClockTimer.timeout.connect(self.updateClock)
        else:
            self.ClockTimer.callback.append(self.updateClock)
        if config.plugins.alanturing.displayentry.value == "clock":
            self.ClockTimer.start(5000, True)

    def updateClock(self):
        if config.plugins.alanturing.displayentry.value == "clock":
            self["displayentry"].setText(
                time.strftime("%H:%M", time.localtime(self.clock.time))
            )
            self.ClockTimer.start(1000, True)
        else:
            self.ClockTimer.stop()


class AlanTuring(Screen, HelpableScreen, ConfigListScreen):
    if sz_w == 2560:
        skin = """
        <screen name="AlanTuring" position="center,240" size="1600,1040" title="Alan Turing" >
        <widget name="logo" position="20,10" size="200,80" />
        <widget backgroundColor="#9f1313" font="Regular;36" halign="center" name="buttonred" position="240,10" foregroundColor="white" shadowColor="black" shadowOffset="-3,-3" size="300,80" valign="center" />
        <widget backgroundColor="#1f771f" font="Regular;36" halign="center" name="buttongreen" position="560,10" foregroundColor="white" shadowColor="black" shadowOffset="-3,-3" size="300,80" valign="center" />
        <widget backgroundColor="#a08500" font="Regular;36" halign="center" name="buttonyellow" position="880,10" foregroundColor="white" shadowColor="black" shadowOffset="-3,-3" size="300,80" valign="center" />
        <widget backgroundColor="#18188b" font="Regular;36" halign="center" name="buttonblue" position="1200,10" foregroundColor="white" shadowColor="black" shadowOffset="-3,-3" size="300,80" valign="center" />
        <widget name="info" position="1510,10" size="80,40" alphatest="on" />
        <widget name="menu" position="1510,50" size="80,40" alphatest="on" />
        <eLabel backgroundColor="grey" position="10,100" size="1580,2" />
        <widget name="slider" position="180,120" size="1240,20" foregroundColor="white" />
        <widget source="size" render="Label" size="140,60" position="20,100" font="Regular;36" halign="center" valign="center" />
        <widget source="duration" render="Label" size="140,60" position="1440,100" font="Regular;36" halign="center" valign="center" />
        <widget name="config" position="20,160" size="1580,780" enableWrapAround="1" scrollbarMode="showOnDemand"/>
        <eLabel backgroundColor="grey" position="10,960" size="1580,2" />
        <widget name="statustext" size="1480,40" position="20,980" font="Regular;32" halign="left" valign="center" foregroundColor="white" />
        <widget name="text" position="1510,980" size="80,40" alphatest="on" />
        </screen>"""
    elif sz_w == 1920:
        skin = """
        <screen name="AlanTuring" position="center,170" size="1200,820" title="Alan Turing" >
        <widget name="logo" position="20,10" size="200,80" />
        <widget backgroundColor="#9f1313" font="Regular;28" halign="center" name="buttonred" position="230,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="210,80" valign="center" />
        <widget backgroundColor="#1f771f" font="Regular;28" halign="center" name="buttongreen" position="450,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="210,80" valign="center" />
        <widget backgroundColor="#a08500" font="Regular;28" halign="center" name="buttonyellow" position="670,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="210,80" valign="center" />
        <widget backgroundColor="#18188b" font="Regular;28" halign="center" name="buttonblue" position="890,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="210,80" valign="center" />
        <widget name="info" position="1125,10" size="60,30" alphatest="on" />
        <widget name="menu" position="1125,50" size="60,30" alphatest="on" />
        <eLabel backgroundColor="grey" position="10,100" size="1180,1" />
        <widget name="slider" position="120,110" size="940,15" foregroundColor="white" />
        <widget source="size" render="Label" size="100,45" position="10,93" font="Regular;24" halign="center" valign="center" />
        <widget source="duration" render="Label" size="100,45" position="1090,93" font="Regular;24" halign="center" valign="center" />
        <widget enableWrapAround="1" name="config" position="10,140" scrollbarMode="showOnDemand" size="1180,590"/>
        <eLabel backgroundColor="grey" position="10,750" size="1180,1" />
        <widget name="statustext" size="1110,40" position="10,760" font="Regular;30" halign="left" valign="center" foregroundColor="white"/>
        <widget name="text" position="1130,770" size="60,30" alphatest="on" />
        </screen>"""
    else:
        skin = """
        <screen name="AlanTuring" position="center,120" size="800,520" title="Alan Turing" >
        <widget name="logo" position="10,5" size="100,40" />
        <widget backgroundColor="#9f1313" font="Regular;18" halign="center" name="buttonred" position="120,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="150,40" valign="center" />
        <widget backgroundColor="#1f771f" font="Regular;18" halign="center" name="buttongreen" position="280,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="150,40" valign="center" />
        <widget backgroundColor="#a08500" font="Regular;18" halign="center" name="buttonyellow" position="440,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="150,40" valign="center" />
        <widget backgroundColor="#18188b" font="Regular;18" halign="center" name="buttonblue" position="600,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="150,40" valign="center" />
        <widget name="info" position="755,5" size="40,20" alphatest="on" />
        <widget name="menu" position="755,25" size="40,20" alphatest="on" />
        <eLabel backgroundColor="grey" position="5,50" size="790,1" />
        <widget name="slider" position="90,60" size="620,5" foregroundColor="white" />
        <widget source="size" render="Label" size="70,30" position="10,50" font="Regular;18" halign="center" valign="center" />
        <widget source="duration" render="Label" size="70,30" position="720,50" font="Regular;18" halign="center" valign="center" />
        <widget name="config" position="10,80" size="790,390" enableWrapAround="1" scrollbarMode="showOnDemand"/>
        <eLabel backgroundColor="grey" position="5,480" size="790,1" />
        <widget name="statustext" size="740,20" position="10,490" font="Regular;16" halign="left" valign="center" foregroundColor="white" />
        <widget name="text" position="755,490" size="40,20" alphatest="on" />
        </screen>"""

    def __init__(self, session, args=0):
        Screen.__init__(self, session)
        HelpableScreen.__init__(self)
        self.skin = AlanTuring.skin
        self.session = session
        self.screen = IMAGES
        self.maxlen = int(config.plugins.alanturing.maxlen.value)
        self.aptInstall = eConsoleAppContainer()
        if os_path.exists("/var/lib/dpkg/status"):
            self.aptInstall_conn = self.aptInstall.appClosed.connect(
                self.aptInstallFinished
            )
            cmd = "apt-get update"
        else:
            self.aptInstall.appClosed.append(self.aptInstallFinished)
            cmd = "opkg update"
        if self.aptMissing():
            cprint("starting update")
            self.install = "update"
            self.aptInstall.execute(cmd)
        else:
            self.install = None
        global at_progress
        global at_duration
        global at_file
        if at_file is None:
            at_progress = gm.progress()
            at_duration = gm.duration()
        else:
            at_progress = gm.progress(at_file)
            at_duration = gm.duration(at_file)
        self.list = []
        ConfigListScreen.__init__(
            self, self.list, session=self.session, on_change=self.changedEntry
        )
        self.onLayoutFinish.append(self.byLayoutEnd)
        self.onShown.append(self.setWindowTitle)

        self["logo"] = Pixmap()
        self.slider = Slider(0, 1024)
        self["slider"] = self.slider
        # self["slider"].hide()
        self["info"] = Pixmap()
        self["menu"] = Pixmap()
        self["text"] = Pixmap()
        self["buttonred"] = Label(_("Exit"))
        self["buttongreen"] = Label(_("Images"))
        self["buttonyellow"] = Label(_("Backup"))
        self["buttonblue"] = Label(_("Setup"))
        self["statustext"] = Label("")
        self["size"] = StaticText(" ")
        self["duration"] = StaticText(" ")

        self.booted = gm.booted()
        self.createSetup(True)
        if os_path.exists("/var/lib/dpkg/status"):
            self.filewatchProgressStart()

        self.busyTimer = eTimer()
        if os_path.exists("/var/lib/dpkg/status"):
            self.busyTimer_conn = self.busyTimer.timeout.connect(self.busyUpdate)
        else:
            self.busyTimer.callback.append(self.busyUpdate)
        self.busyTimer.stop()
        self.busyTimer.start(300, True)

        self["ColorActions"] = HelpableActionMap(
            self,
            "ColorActions",
            {
                "green": (self.green_key, _("Images")),
                "red": (self.red_key, _("Exit")),
                "yellow": (self.yellow_key, _("Backup")),
                "blue": (self.blue_key, _("Setup")),
            },
            -5,
        )

        self["InfoBarTeletextActions"] = HelpableActionMap(
            self,
            "InfobarTeletextActions",
            {
                "startTeletext": (self.showLog, _("Logfile")),
            },
            -5,
        )

        self["ChannelSelectEPGActions"] = HelpableActionMap(
            self,
            "ChannelSelectEPGActions",
            {
                "showEPGList": (self.about, _("Show info screen")),
            },
            -4,
        )

        self["InfobarMenuActions"] = HelpableActionMap(
            self,
            "InfobarMenuActions",
            {
                "mainMenu": (self.blue_key, _("Setup")),
            },
            -4,
        )

        self["SetupActions"] = HelpableActionMap(
            self,
            "SetupActions",
            {
                # "nextSection":          (self.down,_("Move down")),
                # "previousSection":      (self.up,_("Move up")),
                # "save":                 (self.save,_("Save")+" "+_("Setup")),
                "cancel": (self.cancel, _("Exit")),
                "ok": (self.ok_key, _("OK")),
            },
            -4,
        )
        #
        # for new RC use Audio key as Help key alternative
        #
        self["InfobarAudioSelectionActions"] = HelpableActionMap(
            self,
            "InfobarAudioSelectionActions",
            {
                "audioSelection": (self.audioPressed, _("Help")),
            },
            -3,
        )

    def filewatchProgressStart(self):
        self.filewatch_progress = eFileWatch(
            "/tmp", False, eFileEvent.CLOSE_WRITE | eFileEvent.DELETE
        )
        self.filewatch_progress_conn = self.filewatch_progress.fileChanged.connect(
            self.filewatchEventProgress
        )
        self.filewatch_progress.startWatching()

    def filewatchProgressStop(self):
        if self.filewatch_progress and self.filewatch_progress.isWatching():
            self.filewatch_progress.stopWatching()

    def filewatchEventProgress(self, watch, event):
        filename = event.getFullPath()
        if filename == at_busy:
            if not os_path.exists(at_busy):
                #               cprint(">>>>>>>>>>> REMOVED %s" % (filename))
                self.createSetup()

    def createSummary(self):
        return AlanTuringSummary

    def red_key(self):
        self.save()
        self.close(True)

    def save(self):
        cprint("exit Plugin - save settings")
        for x in self["config"].list:
            if len(x) == 2:
                x[1].save()
        config.plugins.gutemine.backupdate.save()
        config.plugins.gutemine.backuptime.save()
        configfile.save()

    def cancel(self):
        for x in self["config"].list:
            if len(x) == 2:
                x[1].cancel()
        config.plugins.gutemine.backupdate.cancel()
        config.plugins.gutemine.backuptime.cancel()
        self.close(False)

    def showLog(self):
        cprint("showing logfile")
        if os_path.exists(at_logfile):
            self.session.open(AlanTuringLog)
        else:
            text = _("Logile") + " " + at_logfile + "\n\n" + _("No details found.")
            self.session.openWithCallback(
                self.refresh, MessageBox, text, MessageBox.TYPE_ERROR, timeout=5
            )

    def aptInstallFinished(self, ret):
        if self.install == "update":
            cprint("apt-get update finished")
            self.install = None
        else:
            text = _("Installation") + " " + self.install + " " + _("finished")
            self.install = None
            self.session.openWithCallback(
                self.refresh, MessageBox, text, MessageBox.TYPE_INFO, timeout=5
            )

    def aptMissing(self):
        rp = os_path.realpath("/bin/tar")
        cprint("realpath: %s\n" % rp)
        if rp.startswith("/bin/busybox"):
            return True
        rp = os_path.realpath("/usr/bin/xz")
        cprint("realpath: %s\n" % rp)
        if not os_path.exists("/usr/bin/xz") or rp.startswith("/bin/busybox"):
            return True
        if not os_path.exists("/bin/pigz"):
            return True
        if not os_path.exists("/usr/bin/pbzip2"):
            return True
        if not os_path.exists("/usr/bin/pixz"):
            return True
        return False

    def createSetup(self, first=False):
        self.list = []
        if self.screen == SETUP:
            self.setTitle(
                at_title + " " + _("Setup") + " " + at_version + " " + at_boxtype
            )
            self["buttonred"].setText(_("Exit"))
            self["buttongreen"].setText(_("Images"))
            self["buttonyellow"].setText(_("Backup"))
            self["buttonblue"].setText(_("Select"))
            self["statustext"].setText(_("Select") + " " + _("Setup") + _("..."))
            self.list.append(("%s %s" % (at_title, _("Menu")),))
            self.list.append(
                getConfigListEntry(_("Menu"), config.plugins.alanturing.bootmenu)
            )
            self.list.append(
                getConfigListEntry(_("InfoBar"), config.plugins.alanturing.progress)
            )
            self.list.append(
                getConfigListEntry(
                    _("Select") + " " + ("Logo"), config.plugins.alanturing.logo
                )
            )
            self.list.append(
                getConfigListEntry(
                    _("Select") + " " + _("Font"), config.plugins.alanturing.font
                )
            )
            #           self.list.append(
            #               getConfigListEntry(
            #                   _("Menu") + " " + _("Resolution"), config.plugins.alanturing.resize
            #               )
            #           )
            self.list.append(
                getConfigListEntry(
                    _("Time") + " [5-30 " + _("seconds") + "]",
                    config.plugins.alanturing.timeout,
                )
            )
            self.list.append(
                getConfigListEntry(
                    _("Menu") + " " + _("Brightness"), config.plugins.alanturing.grey
                )
            )
            free = int(gm.free())
            config.plugins.alanturing.freespace.value = free
            freeMB = "{:n}".format(free)
            atDevice = gm.device()
            cprint("device: %s" % atDevice)
            self.list.append(("%s %s %s" % (at_title, _("Device"), atDevice),))
            if len(atDevice) > 0:
                self.list.append(
                    getConfigListEntry(
                        _("Free") + " %s MB" % freeMB,
                        config.plugins.alanturing.freespace,
                    )
                )
            if self.booted == "Flash":
                self.list.append(
                    getConfigListEntry(
                        _("Device") + " " + _("Select"),
                        config.plugins.alanturing.device,
                    )
                )
                if config.plugins.alanturing.device.value != "none":
#                   self.list.append(
#                       getConfigListEntry(
#                           _("u-boot")+" "+_("Menu"), config.plugins.alanturing.uboot
#                       )
#                   )
#                   self.list.append(
#                       getConfigListEntry(
#                           _("Partitions"), config.plugins.alanturing.partition
#                      )
#                   )
                    self.list.append(
                        getConfigListEntry(
                            _("Fast") + " " + _("Initialize"),
                            config.plugins.alanturing.lazyinit,
                        )
                    )
                    self.list.append(
                        getConfigListEntry(
                            _("Device") + " " + _("Format"),
                            config.plugins.alanturing.initialize,
                        )
                    )
                    self.list.append(
                        getConfigListEntry(
                            _("Device") + " " + _("Reset"),
                            config.plugins.alanturing.erase,
                        )
                    )
            self.list.append(
                getConfigListEntry(
                    _("Device") + " " + _("Scan Files...").replace("...", ""),
                    config.plugins.alanturing.mediascanner,
                )
            )
            self.list.append(("%s %s" % (at_title, _("Settings")),))
            self.list.append(
                getConfigListEntry(
                    _("Choose backup location"),
                    config.plugins.alanturing.backupdirselect,
                )
            )
            self.list.append(
                getConfigListEntry(
                    _("Backup") + " " + _("Format"),
                    config.plugins.alanturing.backuptool,
                )
            )
            rp = os_path.realpath("/bin/tar")
            cprint("realpath: %s\n" % rp)
            ok_text = (
                _("Installation") + " " + _("Please press OK to continue.").rstrip(".")
            )
            if rp.startswith("/bin/busybox"):
                self.list.append(
                    getConfigListEntry(
                        "tar " + _("Installation"), config.plugins.alanturing.tar
                    )
                )
            rp = os_path.realpath("/usr/bin/xz")
            cprint("realpath: %s\n" % rp)
            if not os_path.exists("/usr/bin/xz") or rp.startswith("/bin/busybox"):
                self.list.append(
                    getConfigListEntry(
                        "xz " + _("Installation"), config.plugins.alanturing.xz
                    )
                )
            if not os_path.exists("/usr/bin/pixz"):
                self.list.append(
                    getConfigListEntry(
                        "pixz " + _("Installation"), config.plugins.alanturing.pixz
                    )
                )
            if not os_path.exists("/bin/pigz"):
                self.list.append(
                    getConfigListEntry(
                        "pigz " + _("Installation"), config.plugins.alanturing.pigz
                    )
                )
            if not os_path.exists("/usr/bin/pbzip2"):
                self.list.append(
                    getConfigListEntry(
                        "pbzip2 " + _("Installation"), config.plugins.alanturing.pbzip2
                    )
                )
            self.list.append(
                getConfigListEntry(
                    _("Backup") + " " + _("Date"), config.plugins.gutemine.backupdate
                )
            )
            self.list.append(
                getConfigListEntry(
                    _("Backup") + " " + _("Time"), config.plugins.gutemine.backuptime
                )
            )
            #           self.list.append(
            #               getConfigListEntry(
            #                   _("Debian") + " " + _("Version"), config.plugins.alanturing.debian
            #               )
            #           )
            self.list.append(
                getConfigListEntry(
                    _("Harddisk") + " " + _("Automatic"), config.plugins.alanturing.hdd
                )
            )
            self.list.append(
                getConfigListEntry(
                    _("Password") + " " + _("Reset"), config.plugins.alanturing.pwdreset
                )
            )
            self.list.append(
                getConfigListEntry(_("Ask user"), config.plugins.alanturing.confirm)
            )
            if at_boxtype != "dreamone":
                self.list.append(
                    getConfigListEntry(
                        _("Display"), config.plugins.alanturing.displayentry
                    )
                )
            if os_path.exists("/data/backup"):
                self.list.append(
                    getConfigListEntry(
                        _("Settings") + " " + _("Prefix"),
                        config.plugins.alanturing.settingsprefix,
                    )
                )
                self.list.append(
                    getConfigListEntry(
                        _("Backup system settings"),
                        config.plugins.alanturing.settingsbackup,
                    )
                )
                backupfilename = "/data/backup/enigma2settingsbackup.tar.gz"
                if os_path.exists(backupfilename):
                    self.list.append(
                        getConfigListEntry(
                            _("Restore system settings"),
                            config.plugins.alanturing.settingsrestore,
                        )
                    )
                if os_path.exists("/var/lib/dpkg/status"):           
                    self.list.append(                                                   
                        getConfigListEntry(_("Webinterface"), config.plugins.alanturing.webinterface)
                    )   

        elif self.screen == IMAGES:
            self.setTitle(
                at_title + " " + _("Images") + " " + at_version + " " + at_boxtype
            )
            self["buttonred"].setText(_("Exit"))
            self["buttongreen"].setText(_("Images"))
            self["buttonyellow"].setText(_("Backup"))
            self["buttonblue"].setText(_("Setup"))
            self.list.append((_("Images"),))
            i = 0
            x = 0
            self.images = gm.images()
            for image in self.images:
                if image == self.booted:
                    x = i
                    self.list.append(
                        getConfigListEntry(
                            "@ %s @" % image,
                            config.plugins.alanturing.images[i].action,
                            image,
                        )
                    )
                else:
                    self.list.append(
                        getConfigListEntry(
                            image, config.plugins.alanturing.images[i].action, image
                        )
                    )
                i += 1
            cprint("booted: %s index %d" % (self.booted, x))
            self["statustext"].setText(
                _("Select")
                + " "
                + _("Images")
                + " "
                + _("Action")
                + " < "
                + _("Left")
                + " | "
                + _("Right")
                + " >"
            )
        elif self.screen == BACKUPS:
            self.setTitle(
                at_title + " " + _("Backup") + " " + at_version + " " + at_boxtype
            )
            self["buttonred"].setText(_("Exit"))
            self["buttongreen"].setText(_("Images"))
            self["buttonyellow"].setText(_("Backup"))
            self["buttonblue"].setText(_("Setup"))
            i = 0
            header = ""
            self.backups = gm.backups()
            for backup in self.backups:
                path = os_path.dirname(backup)
                name = os_path.basename(backup)
                name = (
                    name.replace(".tar.gz", "")
                    .replace(".tar.xz", "")
                    .replace(".tar.bz2", "")
                    .replace(".zip", "")
                )
                cprint("backup: %s path: %s name: %s" % (backup, path, name))
                if path != header:
                    self.list.append(("%s %s" % (_("Backup"), path),))
                    i += 1
                    header = path
                self.list.append(
                    getConfigListEntry(
                        name, config.plugins.alanturing.backups[i].action, backup
                    )
                )
                i += 1
            name = config.plugins.alanturing.debian.value
            if name != "none":
                self.list.append(
                    ("%s %s" % (_("Debian"), _("Installation")) + " - " + _("Slow"),)
                )
                i += 1
                self.list.append(
                    getConfigListEntry(
                        name, config.plugins.alanturing.backups[i].action, name
                    )
                )
                i += 1
            self["statustext"].setText(
                _("Select")
                + " "
                + _("Backup")
                + " "
                + _("Action")
                + " < "
                + _("Left")
                + " | "
                + _("Right")
                + " >"
            )
        else:  # ABOUT
            self.setTitle(
                at_title + " " + _("About") + " " + at_version + " " + at_boxtype
            )
            self["buttonred"].setText(_("Exit"))
            self["buttongreen"].setText(_("Images"))
            self["buttonyellow"].setText(_("Backup"))
            self["buttonblue"].setText(_("Setup"))
            self.list.append((at1,))
            self.list.append(getConfigListEntry(at2, config.plugins.alanturing.dummy))
            self.list.append(getConfigListEntry(at3, config.plugins.alanturing.dummy))
            self.list.append((at_title + " " + _("Help"),))
            if os_path.exists(
                "/usr/share/doc/enigma2-plugin-extensions-alanturing/README"
            ):
                h = open(
                    "/usr/share/doc/enigma2-plugin-extensions-alanturing/README", "r"
                )
                line = " "
                while line:
                    line = h.readline()
                    self.list.append(
                        getConfigListEntry(line, config.plugins.alanturing.dummy)
                    )
                h.close()
            self["statustext"].setText(at5)
        if first:
            self.menuList = ConfigList(self.list)
            self.menuList.list = self.list
            self.menuList.l.setList(self.list)
            self["config"] = self.menuList
            self["config"].onSelectionChanged.append(self.selectionChanged)
        else:
            self.menuList.list = self.list
            self.menuList.l.setList(self.list)

    def busyUpdate(self):
        self.busyTimer.stop()
        global at_progress
        global at_duration
        global at_file
        at_progress = "0"
        at_duration = 0
        if os_path.exists(at_busy):
            self["logo"].instance.setPixmapFromFile("%s/busy.png" % at_plugindir)
            if at_file is None:
                at_progress = gm.progress()
                at_duration = gm.duration()
            else:
                at_progress = gm.progress(at_file)
                at_duration = gm.duration(at_file)
            if int(at_progress) > 1024:
                self["slider"].setValue(int(int(at_progress) / 10))
            else:
                self["slider"].setValue(int(at_progress))
            if at_duration > 0:
                self["size"].setText("%sMB" % at_progress)
                self["duration"].setText("%ds" % at_duration)
            else:
                self["size"].setText("")
                self["duration"].setText("")
        else:
            if gm.fury():
                self["logo"].instance.setPixmapFromFile(
                    "%s/fury.png" % gutemine_plugindir
                )
            else:
                self["logo"].instance.setPixmapFromFile(
                    "%s/alanturing.png" % at_plugindir
                )
            at_file = None
        if int(at_progress) > 0 and at_duration > 0:
            cprint("progress %s duration %d" % (at_progress, at_duration))
        if int(at_progress) > 1024:
            self["slider"].setValue(int(int(at_progress) / 10))
        else:
            self["slider"].setValue(int(at_progress))
        if at_duration > 0:
            self["size"].setText("%sMB" % at_progress)
            self["duration"].setText("%ds" % at_duration)
        else:
            self["size"].setText("")
            self["duration"].setText("")
        # update LCD displayentry
        # cprint("=== onShow MainScreen")
        # print(self.session.summary)
        if self.session.summary is not None:
            #           if self.session.summary.has_key("titletext"):
            if "titletext" in self.session.summary:
                self.session.summary["titletext"].setText(at_title)
            #           if self.session.summary.has_key("displayentry"):
            if "displayentry" in self.session.summary:
                if config.plugins.alanturing.displayentry.value == "clock":
                    self.session.summary["displayentry"].setText(
                        time.strftime(
                            "%H:%M", time.localtime(self.session.summary.clock.time)
                        )
                    )
                    self.session.summary.ClockTimer.stop()
                    self.session.summary.ClockTimer.start(1000, True)
                elif config.plugins.alanturing.displayentry.value == "alanturing":
                    self.session.summary["displayentry"].setText(at_title)
                elif config.plugins.alanturing.displayentry.value == "nothing":
                    self.session.summary["displayentry"].setText("")
                elif config.plugins.alanturing.displayentry.value == "dreambox":
                    self.session.summary["displayentry"].setText(at_boxtype)
                else:
                    if not os_path.exists(at_busy):
                        self.session.summary["displayentry"].setText("")
        self.busyTimer.start(1000, True)

    def changedEntry(self):
        if self.screen == SETUP:
            choice = self["config"].getCurrent()
            if len(choice)>1:
                if choice[1] == config.plugins.alanturing.device:
                    if config.plugins.alanturing.device.value == "none":
                        config.plugins.alanturing.partition.value = "0"
                        config.plugins.alanturing.uboot.value = False
                    else:
                        config.plugins.alanturing.partition.value = "1"
                self.createSetup()

    def selectionChanged(self):
        cprint(">>> selectionChanged")
        choice = self["config"].getCurrent()
        cur_idx = self["config"].getCurrentIndex()
        self.name = choice[0]
        if len(choice) > 1:
            self.task = choice[1].value
        else:
            self.task = "none"
        cprint("name: %s task: %s" % (self.name, self.task))
        if self.screen == IMAGES:
            self.image = choice[2]
            for x in range(17):
                if x != (cur_idx - 1):
                    config.plugins.alanturing.images[x].action.value = "none"
                else:
                    cprint(">>> image: %s booted: %s" % (self.image, self.booted))
                    if self.image == self.booted:
                        cprint("BOOTED")
                        # skipping not sense making actions ...
                        if config.plugins.alanturing.images[x].action.value == "select":
                            config.plugins.alanturing.images[x].action.value = "backup"
                            self.task = "backup"
                        if config.plugins.alanturing.images[x].action.value == "rename":
                            config.plugins.alanturing.images[x].action.value = "copy"
                            self.task = "copy"
                        if config.plugins.alanturing.images[x].action.value == "remove":
                            config.plugins.alanturing.images[x].action.value = "purge"
                            self.task = "purge"
                    if self.task == "select":
                        self["buttongreen"].setText(_("Select"))
                    elif self.task == "backup":
                        self["buttongreen"].setText(_("Backup"))
                    elif self.task == "rename":
                        self["buttongreen"].setText(_("Rename"))
                    elif self.task == "remove":
                        self["buttongreen"].setText(_("Remove"))
                    elif self.task == "copy":
                        self["buttongreen"].setText(_("Copy"))
                    elif self.task == "update":
                        self["buttongreen"].setText(_("Update"))
                    elif self.task == "purge":
                        self["buttongreen"].setText(_("Reset"))
                    else:  # image = none
                        # cprint("Images task none ...")
                        self["buttongreen"].setText(_("Images"))

        elif self.screen == BACKUPS:
            for x in range(70):
                if x != (cur_idx):
                    config.plugins.alanturing.backups[x].action.value = "none"
                else:
                    if self.name == config.plugins.alanturing.debian.value:
                        cprint("DEBIAN")
                        # skipping not sense making actions ...
                        if (
                            config.plugins.alanturing.backups[x].action.value
                            != "restore"
                        ):
                            config.plugins.alanturing.backups[x].action.value = "none"
                            self.task = "none"
                    if self.task == "restore":
                        self["buttonyellow"].setText(_("Restore"))
                    elif self.task == "rename":
                        self["buttonyellow"].setText(_("Rename"))
                    elif self.task == "remove":
                        self["buttonyellow"].setText(_("Remove"))
                    elif self.task == "copy":
                        self["buttonyellow"].setText(_("Copy"))
                    else:  # backup = none
                        # 			cprint("Backups task none ...")
                        self["buttonyellow"].setText(_("Backup"))

        elif self.screen == SETUP:
            self["statustext"].setText(
                _("Select")
                + " "
                + _("Setup")
                + ": < "
                + _("Left")
                + " | "
                + _("Right")
                + " >"
            )
            self.refresh(False)
        else:  # INFO
            pass

    def setWindowTitle(self):
        self.setTitle(
            at_title + " " + _("Images") + " " + at_version + " " + at_boxtype
        )

    def byLayoutEnd(self):
        global at_progress
        if os_path.exists(at_busy):
            self["logo"].instance.setPixmapFromFile("%s/busy.png" % at_plugindir)
        else:
            if gm.fury():
                self["logo"].instance.setPixmapFromFile(
                    "%s/fury.png" % gutemine_plugindir
                )
            else:
                self["logo"].instance.setPixmapFromFile(
                    "%s/alanturing.png" % at_plugindir
                )
        self["menu"].instance.setPixmapFromFile(gm.getpicon("menu"))
        self["info"].instance.setPixmapFromFile(gm.getpicon("info"))
        self["text"].instance.setPixmapFromFile(gm.getpicon("text"))
        if int(at_progress) > 1024:
            self["slider"].setValue(int(int(at_progress) / 10))
        else:
            self["slider"].setValue(int(at_progress))

    def reset(self):
        self.imageselected = 0
        self["image"].setText(self.imagelist[self.imageselected][0])

    def forward(self):
        self.imageselected = self.imageselected + 1
        if self.imageselected > self.imagelistlength - 1:
            self.imageselected = 0
        self["image"].setText(self.imagelist[self.imageselected][0])

    def backward(self):
        self.imageselected = self.imageselected - 1
        if self.imageselected < 0:
            self.imageselected = self.imagelistlength - 1
        self["image"].setText(self.imagelist[self.imageselected][0])

    def green_key(self):
        if self.screen == SETUP:
            self.save()
        if self.screen == IMAGES:
            self.ok_key()
        else:
            for x in range(70):
                config.plugins.alanturing.backups[x].action.value = "none"
            self.screen = IMAGES
            self.createSetup()

    def yellow_key(self):
        if self.screen == SETUP:
            self.save()
        if self.screen == BACKUPS:
            self.ok_key()
        else:
            for x in range(17):
                config.plugins.alanturing.images[x].action.value = "none"
            self.screen = BACKUPS
            self.createSetup()

    def blue_key(self):
        if self.screen == SETUP:
            self.save()
            text = (
                _("Select")
                + " "
                + _("Menu")
                + "\n\n"
                + _("Background")
                + ":\t"
                + _("left")
                + " / "
                + _("right")
                + "\n"
                + _("Font")
                + ":\t"
                + _("up")
                + " / "
                + _("down")
                + "\n"
                + ("OK")
                + ":\t"
                + _("Save")
                + "\n"
                + _("EXIT")
                + ":\t"
                + _("Reset")
                + "\n"
                + _("[ ]")
                + ":\t"
                + _("Screenshot")
            )
            self.session.openWithCallback(self.chooseLogo, MessageBox, text)
        else:
            self.screen = SETUP
            self.createSetup()

    def audioPressed(self):
        audio2Help()

    def about(self):
        self.screen = ABOUT
        self.createSetup()

    def ok_key(self):
        choice = self["config"].getCurrent()
        cur_idx = self["config"].getCurrentIndex()
        print(cur_idx)
        if choice is not None and len(choice) > 1:
            self.task = choice[1].value
        else:
            self.task = "none"
        cprint("task: %s" % (self.task))
        if self.task == "none":
            self.createSetup()
            # 	    cprint("empty OK")
            return

        if self.screen == SETUP:
            if self.install == "update":
                text = _("Trying to download a new packetlist. Please wait...")
                self.session.open(MessageBox, text, MessageBox.TYPE_WARNING, timeout=3)
                return

            if choice[1] == config.plugins.alanturing.tar:
                self.install = "tar"
                cprint("install tar")
                if os_path.exists("/var/lib/dpkg/status"):
                    cmd = "apt-get -f -y install tar"
                else:
                    cmd = "opkg install tar"
                self.aptInstall.execute(cmd)
                return

            elif choice[1] == config.plugins.alanturing.xz:
                self.install = "xz"
                cprint("install xz")
                if os_path.exists("/var/lib/dpkg/status"):
                    cmd = "apt-get -f -y install xz"
                else:
                    cmd = "opkg install xz"
                self.aptInstall.execute(cmd)
                return

            elif choice[1] == config.plugins.alanturing.pixz:
                self.install = "pixz"
                cprint("install pixz")
                if os_path.exists("/var/lib/dpkg/status"):
                    cmd = "apt-get -f -y install pixz"
                else:
                    cmd = "opkg install pixz"
                self.aptInstall.execute(cmd)
                return

            elif choice[1] == config.plugins.alanturing.pigz:
                self.install = "pigz"
                cprint("install pigz")
                if os_path.exists("/var/lib/dpkg/status"):
                    cmd = "apt-get -f -y install pigz"
                else:
                    cmd = "opkg install pigz"
                self.aptInstall.execute(cmd)
                return

            elif choice[1] == config.plugins.alanturing.pbzip2:
                self.install = "pbzip2"
                cprint("install pbzip2")
                if os_path.exists("/var/lib/dpkg/status"):
                    cmd = "apt-get -f -y install pbzip2"
                else:
                    cmd = "opkg install pbzip2"
                self.aptInstall.execute(cmd)
                return

            elif choice[1] == config.plugins.alanturing.initialize:
                self.atDevice = config.plugins.alanturing.device.value
                cprint("initialize device %s ..." % self.atDevice)
                message = (
                    _(
                        "Do you really want to initialize this %(desc)s?\nAll data on this %(desc)s will be lost!"
                    )
                    % storagedevice_description
                )
                message += "\n\n" + _("Device") + ": " + self.atDevice
                self.session.openWithCallback(
                    self.doInitialize, MessageBox, message, MessageBox.TYPE_YESNO
                )
                return

            elif choice[1] == config.plugins.alanturing.erase:
                self.atDevice = config.plugins.alanturing.device.value
                if self.atDevice == "":
                    text = (
                        _("Device")
                        + " "
                        + _("Automatic")
                        + " "
                        + _("Reset")
                        + " "
                        + _("not supported")
                    )
                    text += "\n\nPlease select a device"
                    self.session.open(MessageBox, text, MessageBox.TYPE_INFO, timeout=5)
                    return
                cprint("erase device %s ..." % self.atDevice)
                message = (
                    _(
                        "Do you really want to initialize this %(desc)s?\nAll data on this %(desc)s will be lost!"
                    )
                    % storagedevice_description
                )
                message += "\n\n" + _("Device") + ": " + self.atDevice
                self.session.openWithCallback(
                    self.doErase, MessageBox, message, MessageBox.TYPE_YESNO
                )
                return

            elif choice[1] == config.plugins.alanturing.settingsbackup:
                cprint("settings backup ...")
                self.session.openWithCallback(self.refresh, AlanTuringSettingsBackup)
                return

            elif choice[1] == config.plugins.alanturing.settingsrestore:
                cprint("settings restore ...")
                self.session.openWithCallback(self.refresh, AlanTuringSettingsRestore)
                return
            else:
                return

        if self.screen == IMAGES:
            self.image = choice[0]
            self.full = choice[2]
            cprint("action on image: %s %s" % (self.image, self.full))
            if os_path.exists(at_busy):
                self["statustext"].setText(at_title + " " + _("working") + _("..."))
                return
            if self.task == "select":
                gm.selecting(self.full)
                if config.plugins.alanturing.confirm.value:
                    self.session.openWithCallback(
                        self.ImageBoot,
                        MessageBox,
                        _("Do you want to reboot your Dreambox?"),
                        MessageBox.TYPE_YESNO,
                    )
                else:
                    self.ImageBoot(True)
            elif self.task == "backup":
                if self.full == "Flash":
                    suggested_target = ""
                else:
                    suggested_target = self.full
                self.target = gm.trim(
                    suggested_target, self.maxlen, False, False, False
                )
                self.session.openWithCallback(
                    self.askForImageSave,
                    InputBox,
                    title=_("Enter") + " " + _("Backup") + " " + _("Name"),
                    text=self.target,
                    maxSize=True,
                    visible_width=self.maxlen,
                    type=Input.TEXT,
                )
            elif self.task == "copy":
                if self.full == "Flash":
                    suggested_target = ""
                else:
                    suggested_target = self.full
                self.target = gm.trim(
                    suggested_target, self.maxlen, False, False, False
                )
                self.session.openWithCallback(
                    self.askForImageCopy,
                    InputBox,
                    title=_("Enter") + " " + _("Copy") + " " + _("Name"),
                    text=self.target,
                    maxSize=True,
                    visible_width=self.maxlen,
                    type=Input.TEXT,
                )
            elif self.task == "rename":
                self.target = gm.trim(self.full, self.maxlen, False, False, False)
                self.session.openWithCallback(
                    self.askForImageRename,
                    InputBox,
                    title=_("Enter") + " " + _("Rename") + " " + _("Name"),
                    text=self.target,
                    maxSize=True,
                    visible_width=self.maxlen,
                    type=Input.TEXT,
                )
            elif self.task == "remove":
                if config.plugins.alanturing.confirm.value:
                    self.session.openWithCallback(
                        self.ImageRemove,
                        MessageBox,
                        _("Remove") + "\n\n%s ?" % (self.image),
                        MessageBox.TYPE_YESNO,
                    )
                else:
                    self.ImageRemove(True)
            elif self.task == "update":
                if config.plugins.alanturing.confirm.value:
                    self.session.openWithCallback(
                        self.ImageUpdate,
                        MessageBox,
                        _("Update") + "\n\n%s ?" % (self.image),
                        MessageBox.TYPE_YESNO,
                    )
                else:
                    self.ImageUpdate(True)
            elif self.task == "purge":
                if config.plugins.alanturing.confirm.value:
                    self.session.openWithCallback(
                        self.ImagePurge,
                        MessageBox,
                        _("Reset")
                        + " gutemine "
                        + _("Plugins")
                        + "\n\n%s ?" % (self.image),
                        MessageBox.TYPE_YESNO,
                    )
                else:
                    self.ImagePurge(True)
            else:
                cprint("Images action task none")
                if config.plugins.alanturing.confirm.value:
                    text = (
                        _("Select")
                        + " "
                        + _("Images")
                        + " "
                        + _("Action")
                        + " < "
                        + _("Left")
                        + " | "
                        + _("Right")
                        + " >"
                    )
                    self.session.open(MessageBox, text, MessageBox.TYPE_WARNING)

        elif self.screen == BACKUPS:
            self.backup = choice[0]
            self.full = choice[2]
            cprint("action on backup: %s %s" % (self.backup, self.full))
            if os_path.exists(at_busy):
                self["statustext"].setText(at_title + " " + _("working") + _("..."))
                return
            if self.task == "restore":
                self.target = gm.trim(
                    self.backup.replace("-" + at_boxtype, "")
                    .replace(at_boxtype + "-", "")
                    .replace("-dreambox", "")            
                    .replace("-one", "")
                    .replace("-two", "")
                    .replace(".rootfs", "")
                    .replace("-deb", "")
                    .replace("_mmc", "")
                    .replace("-bak", "")
                    .replace("-image", ""),
                    self.maxlen,
                    False,
                    False,
                    False,
                )
                if (
                    self.full == config.plugins.alanturing.debian.value
                    and gm.keyboard() > 0
                ):
                    text = _("Remove") + " " + _("Keyboard")
                    self.session.open(MessageBox, text, MessageBox.TYPE_ERROR)
                else:
                    self.session.openWithCallback(
                        self.askForBackupRestore,
                        InputBox,
                        title=_("Backup") + " " + _("Restore") + " " + _("Name"),
                        text=self.target,
                        maxSize=True,
                        visible_width=self.maxlen,
                        type=Input.TEXT,
                    )
            elif self.task == "copy":
                suggested_target = self.backup
                self.target = gm.trim(suggested_target, -at_maxlen)
                self.session.openWithCallback(
                    self.askForBackupCopy,
                    InputBox,
                    title=_("Backup") + " " + _("Copy") + " " + _("Name"),
                    text=self.target,
                    maxSize=True,
                    visible_width=at_maxlen,
                    type=Input.TEXT,
                )
            elif self.task == "rename":
                suggested_target = self.backup
                self.target = gm.trim(suggested_target, -at_maxlen)
                self.session.openWithCallback(
                    self.askForBackupRename,
                    InputBox,
                    title=_("Backup") + " " + _("Rename") + " " + _("Name"),
                    text=self.target,
                    maxSize=True,
                    visible_width=at_maxlen,
                    type=Input.TEXT,
                )
            elif self.task == "remove":
                self.target = self.backup
                if config.plugins.alanturing.confirm.value:
                    self.session.openWithCallback(
                        self.BackupRemove,
                        MessageBox,
                        _("Remove") + "\n\n%s ?" % self.backup,
                        MessageBox.TYPE_YESNO,
                    )
                else:
                    self.BackupRemove(True)
            else:
                cprint("Backups action task none")
                if config.plugins.alanturing.confirm.value:
                    text = (
                        _("Select")
                        + " "
                        + _("Backups")
                        + " "
                        + _("Action")
                        + " < "
                        + _("Left")
                        + " | "
                        + _("Right")
                        + " >"
                    )
                    self.session.open(MessageBox, text, MessageBox.TYPE_WARNING)
        else:  # nothing on SETUP - up to now
            pass

    # self.createSetup()

    def doInitialize(self, status):
        if status:
            cprint("init %s confirmed" % self.atDevice)
            self.gmInitialize = eTimer()
            if os_path.exists("/var/lib/dpkg/status"):
                self.gmInitalize_conn = self.gmInitialize.timeout.connect(
                    self.executeInitialize
                )
            else:
                self.gmInitialize.callback.append(self.executeInitialize)
            self.gmInitialize.start(100, True)

    def executeInitialize(self):
        gm.mount(self.atDevice)
        if self.atDevice == "":
            text = (
                _("Device")
                + " "
                + _("Automatic")
                + " "
                + _("Initialize")
                + " "
                + _("Finished")
            )
        else:
            text = (
                _("Device")
                + " "
                + self.atDevice
                + " "
                + _("Initialize")
                + " "
                + _("Finished")
            )
        self.session.open(MessageBox, text, MessageBox.TYPE_INFO, timeout=5)

    def doErase(self, status):
        if status:
            cprint("erase %s confirmed" % self.atDevice)
            self.gmErase = eTimer()
            if os_path.exists("/var/lib/dpkg/status"):
                self.gmErase_conn = self.gmErase.timeout.connect(self.executeErase)
            else:
                self.gmErase.callback.append(self.executeErase)
            self.gmErase.start(100, True)

    def executeErase(self):
        if self.atDevice == "":
            text = (
                _("Device")
                + " "
                + _("Automatic")
                + " "
                + _("Reset")
                + " "
                + _("not supported")
            )
        else:
            text = (
                _("Device")
                + " "
                + self.atDevice
                + " "
                + _("Reset")
                + " "
                + _("Finished")
            )
            gm.wipe(self.atDevice)
        self.session.open(MessageBox, text, MessageBox.TYPE_INFO, timeout=5)

    ##############################################################
    # Tasks on Images
    #############################################################

    def askForImageSave(self, target):
        if target is None:
            return
        else:
            self.target = "%s.%s" % (
                gm.trim(target),
                config.plugins.alanturing.backuptool.value,
            )
            if config.plugins.alanturing.backupdirselect.value:
                self.session.openWithCallback(
                    self.askForImageSaving,
                    ChoiceBox,
                    _("Choose backup location"),
                    self.getLocationList(),
                )
            else:
                self.askForImageSaving()

    def getLocationList(self):
        backups = []
        paths = gm.paths()
        for path in paths:
            backups.append((path, path))
        return backups

    def askForImageSaving(self, backup=None):
        if backup is None:
            path = at_backups
        else:
            path = backup[0]
        self.target = "%s/%s" % (path, self.target)
        if config.plugins.alanturing.confirm.value:
            self.session.openWithCallback(
                self.ImageSaving,
                MessageBox,
                _("Backup") + "\n\n%s -> %s ?" % (self.full, self.target),
                MessageBox.TYPE_YESNO,
            )
        else:
            self.ImageSaving(True)

    def askForImageCopy(self, target):
        if target is None:
            return
        else:
            self.target = gm.trim(target, 0, False, False, False)
            target = "%s/%s" % (at_images, self.target)
            if os_path.exists(target):
                text = _("The path %s already exists.") % target
                self.session.open(MessageBox, text, MessageBox.TYPE_ERROR)
            else:
                if config.plugins.alanturing.confirm.value:
                    self.session.openWithCallback(
                        self.ImageCopy,
                        MessageBox,
                        _("Copy") + "\n\n%s -> %s ?" % (self.image, self.target),
                        MessageBox.TYPE_YESNO,
                    )
                else:
                    self.ImageCopy(True)

    def askForImageRename(self, target):
        if target is None:
            return
        else:
            self.target = gm.trim(target, 0, False, False, False)
            target = "%s/%s" % (at_images, self.target)
            if os_path.exists(target):
                text = _("The path %s already exists.") % target
                self.session.open(MessageBox, text, MessageBox.TYPE_ERROR)
            else:
                if config.plugins.alanturing.confirm.value:
                    self.session.openWithCallback(
                        self.ImageRename,
                        MessageBox,
                        _("Rename") + "\n\n%s -> %s ?" % (self.image, self.target),
                        MessageBox.TYPE_YESNO,
                    )
                else:
                    self.ImageRename(True)

    def ImageBoot(self, answer):
        if answer is True:
            cprint("select %s" % self.full)
            self.session.open(TryQuitMainloop, 2)
            self.refresh()

    def ImageCopy(self, answer):
        if answer is None:
            return
        if answer is False:
            return
        else:
            cprint("copy %s -> %s" % (self.full, self.target))
            if os_path.exists(self.target):
                text = _("The path %s already exists.") % self.target
                self.session.open(MessageBox, text, MessageBox.TYPE_ERROR)
            else:
                self.busyTimer.stop()
                gm.copying(self.full, self.target)
                self.busyTimer.start(1000, True)
                self.refresh()

    def ImageRename(self, answer):
        if answer is None:
            return
        if answer is False:
            return
        else:
            cprint("rename %s -> %s" % (self.image, self.target))
            if os_path.exists(self.target):
                text = _("The path %s already exists.") % self.target
                self.session.open(MessageBox, text, MessageBox.TYPE_ERROR)
            else:
                self.busyTimer.stop()
                gm.renaming(self.image, self.target)
                self.busyTimer.start(1000, True)
                self.refresh()

    def ImageRemove(self, answer):
        if answer is None:
            return
        if answer is False:
            return
        else:
            cprint("remove %s" % (self.image))
            self.busyTimer.stop()
            gm.removing(self.image)
            self.busyTimer.start(1000, True)
            self.refresh()

    def ImageUpdate(self, answer):
        if answer is None:
            return
        if answer is False:
            return
        else:
            cprint("update %s" % (self.image))
            self.busyTimer.stop()
            if self.image.startswith("@") and self.image.endswith("@"):
                cprint("updating booted image")
                gm.update()
            else:
                cprint("updating %s image" % self.image)
                gm.update(self.image)
            self.busyTimer.start(1000, True)
            self.refresh()

    def ImagePurge(self, answer):
        if answer is None:
            return
        if answer is False:
            return
        else:
            cprint("purge %s" % (self.image))
            cprint("booted %s" % (self.booted))
            self.busyTimer.stop()
            if self.image.startswith("@") and self.image.endswith("@"):
                cprint("purging booted image")
                gm.purge()
            else:
                cprint("purging %s image" % self.image)
                gm.purge(self.image)
            self.refresh()

    def ImageSaving(self, answer):
        global at_file
        if answer is None:
            return
        if answer is False:
            return
        else:
            cprint("saving %s -> %s" % (self.full, self.target))
            at_file = self.target
            if os_path.exists(self.target):
                text = _("The path %s already exists.") % self.target
                self.session.open(MessageBox, text, MessageBox.TYPE_ERROR)
            else:
                self.busyTimer.stop()
                gm.saving(self.full,self.target)
                self.busyTimer.start(3000, True)
                self.refresh()

    ##############################################################
    # Tasks on Backups
    #############################################################

    def askForBackupRestore(self, target):
        if target is None:
            return
        else:
            self.target = gm.trim(target, 0, False, False, False)
            target = "%s/%s" % (at_images, self.target)
            if os_path.exists(target):
                text = _("The path %s already exists.") % target
                self.session.open(MessageBox, text, MessageBox.TYPE_ERROR)
                return
            if config.plugins.alanturing.confirm.value:
                self.session.openWithCallback(
                    self.BackupRestore,
                    MessageBox,
                    _("Restore") + "\n\n%s -> %s ?" % (self.backup, self.target),
                    MessageBox.TYPE_YESNO,
                )
            else:
                self.BackupRestore(True)

    def askForBackupRename(self, target):
        if target is None:
            return
        else:
            if target.find(at_boxtype) == -1:
                target = target + "-" + at_boxtype
            self.target = gm.trim(target, 0, False, False, False)
            path = os_path.dirname(self.full)
            target = "%s/%s.%s" % (
                path,
                gm.trim(self.target, at_maxlen).rstrip(),
                config.plugins.alanturing.backuptool.value,
            )
            if os_path.exists(target):
                text = _("The path %s already exists.") % target
                self.session.open(MessageBox, text, MessageBox.TYPE_ERROR)
                return
            if config.plugins.alanturing.confirm.value:
                self.session.openWithCallback(
                    self.BackupRename,
                    MessageBox,
                    _("Rename") + "\n\n%s -> %s ?" % (self.backup, self.target),
                    MessageBox.TYPE_YESNO,
                )
            else:
                self.BackupRename(True)

    def askForBackupCopy(self, target):
        if target is None:
            return
        else:
            if target.find(at_boxtype) == -1:
                target = target + "-" + at_boxtype
            self.target = gm.trim(target, 0, False, False, False)
            path = os_path.dirname(self.full)
            target = "%s/%s.%s" % (
                path,
                self.target,
                config.plugins.alanturing.backuptool.value,
            )
            if os_path.exists(target):
                text = _("The path %s already exists.") % target
                self.session.open(MessageBox, text, MessageBox.TYPE_ERROR)
                return
            if config.plugins.alanturing.confirm.value:
                self.session.openWithCallback(
                    self.BackupCopy,
                    MessageBox,
                    _("Copy") + "\n\n%s -> %s ?" % (self.backup, self.target),
                    MessageBox.TYPE_YESNO,
                )
            else:
                self.BackupCopy(True)

    def askForBackupRemove(self, target):
        if target is None:
            return
        else:
            if config.plugins.alanturing.confirm.value:
                self.session.openWithCallback(
                    self.BackupRemove,
                    MessageBox,
                    _("Remove") + "\n\n%s ?" % self.backup,
                    MessageBox.TYPE_YESNO,
                )
            else:
                self.BackupRemove(True)

    def BackupRestore(self, answer):
        if answer is None:
            return
        if answer is False:
            return
        else:
            self.busyTimer.stop()
            if self.full == config.plugins.alanturing.debian.value:
                cprint("debian %s -> %s" % (self.full, self.target))
                gm.debian(self.target)
            else:
                cprint("restore %s -> %s" % (self.full, self.target))
                gm.restoring(self.full, self.target)
            self.busyTimer.start(1000, True)
            self.refresh()

    def BackupRemove(self, answer):
        if answer is None:
            return
        if answer is False:
            return
        else:
            cprint("remove %s" % self.full)
            gm.removing(self.full)
            self.refresh()

    def BackupRename(self, answer):
        if answer is None:
            return
        if answer is False:
            return
        else:
            path = os_path.dirname(self.full)
            target = "%s/%s.%s" % (
                path,
                gm.trim(self.target),
                config.plugins.alanturing.backuptool.value,
            )
            cprint("rename %s -> %s" % (self.full, target))
            gm.renaming(self.full, target)
            self.refresh()

    def BackupCopy(self, answer):
        global at_file
        if answer is None:
            return
        if answer is False:
            return
        else:
            path = os_path.dirname(self.full)
            target = "%s/%s.%s" % (
                path,
                gm.trim(self.target),
                config.plugins.alanturing.backuptool.value,
            )
            cprint("copy %s -> %s" % (self.full, target))
            at_file = target
            self.busyTimer.stop()
            gm.copying(self.full, target)
            self.busyTimer.start(1000, True)
            self.refresh()

    def refresh(self, setup=True):
        if self.screen == BACKUPS:
            self.backups = gm.backups()
            for x in range(70):
                config.plugins.alanturing.backups[x].action.value = "none"
        if self.screen == IMAGES:
            self.images = gm.images()
            for x in range(17):
                config.plugins.alanturing.images[x].action.value = "none"
        if setup:
            self.createSetup()

    def chooseLogo(self, status):
        if status:
            self.session.open(AlanTuringSelectMenu)


class AlanTuringSelectMenu(Screen):
    if sz_w == 2560:
        skin = """
        <screen position="center,center" size="2560,1440" title="Alan Turing Select Menu" flags="wfNoBorder" backgroundColor="#FFFFFFFF">
        <widget name="osdshot" position="0,0" size="2560,1440" alphatest="on" />
        </screen>"""
    elif sz_w == 1920:
        skin = """
        <screen position="center,center" size="1920,1080" title="Alan Turing Select Menu" flags="wfNoBorder" backgroundColor="#FFFFFFFF">
        <widget name="osdshot" position="0,0" size="1920,1080" alphatest="on" />
        </screen>"""
    else:
        skin = """
        <screen position="center,center" size="1280,720" title="Alan Turing Select Menu" flags="wfNoBorder" backgroundColor="#FFFFFFFF">
        <widget name="osdshot" position="0,0" size="1280,720" alphatest="on" />
        </screen>"""

    def __init__(self, session):
        self.skin = AlanTuringSelectMenu.skin
        self.setup_title = at_title + " " + _("Select") + " " + _("Menu")
        Screen.__init__(self, session)
        # explizit check on every entry
        self.onChangedEntry = []
        self.onConfigEntryChanged = []
        self.session = session
        self.altservice = session.nav.getCurrentlyPlayingServiceReference()
        session.nav.stopService()

        self.atlogos = []
        self.atlogos = gm.logos()
        self.numberlogos = len(self.atlogos)
        self.currentlogo = 0
        i = 0
        for logo in self.atlogos:
            if logo == config.plugins.alanturing.logo.value:
                self.currentlogo = i
            i += 1
        cprint("logo id: %d" % self.currentlogo)

        self.atfonts = []
        self.atfonts = gm.fonts()
        self.numberfonts = len(self.atfonts)
        self.currentfont = 0
        i = 0
        for font in self.atfonts:
            if font == config.plugins.alanturing.font.value:
                self.currentfont = i
            i += 1
        cprint("font id: %d" % self.currentfont)

        self["osdshot"] = Pixmap()
#       self["buttonred"] = Label(_("Cancel"))
#       self["buttongreen"] = Label(_("OK"))
#       self["buttonyellow"] = Label(_("Skin"))
#       self["buttonblue"] = Label(_("Info"))
        self["actions"] = ActionMap(
            [
                "WizardActions",
                "SetupActions",
                "MovieSelectionActions",
                "InfobarTimeshiftActions",
            ],
            {
                "cancel": self.goBack,
                "back": self.goBack,
                "ok": self.saveLogoFont,
                "left": self.backward,
                "right": self.forward,
                "deleteForward": self.right,
                "deleteBackward": self.left,
                "up": self.up,
                "down": self.down,
                "showEventInfo": self.close,
                "timeshiftStop": self.osdShot,
            },
            -1,
        )
        self.onLayoutFinish.append(self.byLayoutEnd)

    def goBack(self):
        fbClass.getInstance().unlock()
        self.session.nav.playService(self.altservice)
        self.close()

    def backward(self):
        self.currentlogo = self.currentlogo - 1
        if self.currentlogo < 0:
            self.currentlogo = self.numberlogos - 1
        cprint("backward %i" % self.currentlogo)
        self.showManager(self.atlogos[self.currentlogo], self.atfonts[self.currentfont])

    def left(self):
        self.showManager(self.atlogos[self.currentlogo], self.atfonts[self.currentfont])

    def right(self):
        self.showManager(self.atlogos[self.currentlogo], self.atfonts[self.currentfont])

    def forward(self):
        self.currentlogo = self.currentlogo + 1
        if self.currentlogo >= self.numberlogos:
            self.currentlogo = 0
        cprint("forward %i" % self.currentlogo)
        self.showManager(self.atlogos[self.currentlogo], self.atfonts[self.currentfont])

    def down(self):
        self.currentfont = self.currentfont - 1
        if self.currentfont < 0:
            self.currentfont = self.numberfonts - 1
        cprint("down %i" % self.currentfont)
        self.showManager(self.atlogos[self.currentlogo], self.atfonts[self.currentfont])

    def up(self):
        self.currentfont = self.currentfont + 1
        if self.currentfont >= self.numberfonts:
            self.currentfont = 0
        cprint("up %i" % self.currentfont)
        self.showManager(self.atlogos[self.currentlogo], self.atfonts[self.currentfont])

    def byLayoutEnd(self):
        self.showManager(self.atlogos[self.currentlogo], self.atfonts[self.currentfont])

    def osdShot(self):
        cprint("osdshot")
        if os_path.exists("/tmp/osdshot.png"):
            os_remove("/tmp/osdshot.png")
        cprint("getting osdshot.png")
        gm.osdshot()

    def showManager(self, logo_file, font_file):
        fbClass.getInstance().lock()
        cprint("showing: %s %s" % (logo_file, font_file))
        #       self.setResolution()
        gm.menu(logo_file, font_file)

    def saveLogoFont(self):
        cprint("saving logo %s" % (self.atlogos[self.currentlogo]))
        config.plugins.alanturing.logo.value = self.atlogos[self.currentlogo]
        config.plugins.alanturing.logo.save()
        cprint("saving font %s" % (self.atfonts[self.currentfont]))
        config.plugins.alanturing.font.value = self.atfonts[self.currentfont]
        config.plugins.alanturing.font.save()
        #       self.setResolution()
        self.goBack()


#   def setResolution(self):
#       if config.plugins.alanturing.resize.value:
#           try:
#               gMainDC.getInstance().setResolution(sz_w, sz_h)
#               self.desktop.resize(eSize(sz_w, sz_h))
#           except:
#               pass


class AlanTuringSettingsBackup(Screen, ConfigListScreen):
    if sz_w == 2560:
        skin = """
		<screen position="270,188" size="700,620" title="Backup is running" >
		<widget name="config" position="20,20" size="660,500" transparent="1" scrollbarMode="showOnDemand" />
		</screen>"""
    elif sz_w == 1920:
        skin = """
		<screen position="200,210" size="500,420" title="Backup is running" >
		<widget name="config" position="15,15" size="480,360" transparent="1" scrollbarMode="showOnDemand" />
		</screen>"""
    else:
        skin = """
		<screen position="135,144" size="350,310" title="Backup is running" >
		<widget name="config" position="10,10" size="330,250" transparent="1" scrollbarMode="showOnDemand" />
		</screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self["actions"] = ActionMap(
            ["WizardActions", "DirectionActions"],
            {
                "ok": self.close,
                "back": self.close,
                "cancel": self.close,
            },
            -1,
        )
        self.finished_cb = None

        if config.plugins.alanturing.settingsprefix.value == "none":
            self.fullbackupfilename = "/data/backup/enigma2settingsbackup.tar.gz"
        else:
            self.fullbackupfilename = "/data/backup/%senigma2settingsbackup.tar.gz" % (
                config.plugins.alanturing.settingsprefix.value
            )
        self.list = []
        ConfigListScreen.__init__(self, self.list)
        self.onLayoutFinish.append(self.layoutFinished)
        self.onShown.append(self.doBackup)

    def layoutFinished(self):
        self.setWindowTitle()

    def setWindowTitle(self):
        self.setTitle(_("Backup is running..."))

    def doBackup(self):
        configfile.save()
        try:
            if (
                config.plugins.configurationbackup.backupdirs is None
                or len(config.plugins.configurationbackup.backupdirs.value) == 0
            ):
                self.backupdirs = "/etc/enigma2/ /etc/hostname"
            else:
                self.backupdirs = " ".join(
                    config.plugins.configurationbackup.backupdirs.value
                )
            at_backupdir = "%s/backup" % at_images
            if not os_path.exists(at_backupdir):
                os_mkdir(at_backupdir)
            if os_path.exists(self.fullbackupfilename):
                dt = str(date.fromtimestamp(os_stat(self.fullbackupfilename).st_ctime))
                if config.plugins.alanturing.settingsprefix.value == "none":
                    self.newfilename = (
                        "/data/backup/%s-enigma2settingsbackup.tar.gz" % (dt)
                    )
                else:
                    self.newfilename = (
                        "/data/backup/%s-%senigma2settingsbackup.tar.gz"
                        % (dt, config.plugins.alanturing.settingsprefix.value)
                    )
                if os_path.exists(self.newfilename):
                    os_remove(self.newfilename)
                os_rename(self.fullbackupfilename, self.newfilename)
            if self.finished_cb:
                self.session.openWithCallback(
                    self.finished_cb,
                    Console,
                    title=_("Backup is running..."),
                    cmdlist=[
                        "tar -czvf " + self.fullbackupfilename + " " + self.backupdirs
                    ],
                    finishedCallback=self.backupFinishedCB,
                    closeOnSuccess=True,
                )
            else:
                self.session.open(
                    Console,
                    title=_("Backup is running..."),
                    cmdlist=[
                        "tar -czvf " + self.fullbackupfilename + " " + self.backupdirs
                    ],
                    finishedCallback=self.backupFinishedCB,
                    closeOnSuccess=True,
                )
        except OSError:
            if self.finished_cb:
                self.session.openWithCallback(
                    self.finished_cb,
                    MessageBox,
                    _(
                        "Sorry your backup destination is not writeable.\nPlease choose an other one."
                    ),
                    MessageBox.TYPE_INFO,
                    timeout=10,
                )
            else:
                self.session.openWithCallback(
                    self.backupErrorCB,
                    MessageBox,
                    _(
                        "Sorry your backup destination is not writeable.\nPlease choose an other one."
                    ),
                    MessageBox.TYPE_INFO,
                    timeout=10,
                )

    def backupFinishedCB(self, retval=None):
        self.close(True)

    def backupErrorCB(self, retval=None):
        self.close(False)

    def runAsync(self, finished_cb):
        self.finished_cb = finished_cb
        self.doBackup()


class AlanTuringSettingsRestore(Screen, ConfigListScreen):
    if sz_w == 2560:
        skin = """
		<screen position="center,center" size="1240,640" title="Restore is running..." >
		<widget name="config" position="20,20" size="1200,600" transparent="1" scrollbarMode="showOnDemand" />
		</screen>"""
    elif sz_w == 1920:
        skin = """
		<screen position="center,center" size="930,480" title="Restore is running..." >
		<widget name="config" position="15,15" size="900,450" transparent="1" scrollbarMode="showOnDemand" />
		</screen>"""
    else:
        skin = """
		<screen position="center,center" size="620,320" title="Restore is running..." >
		<widget name="config" position="10,10" size="600,300" transparent="1" scrollbarMode="showOnDemand" />
		</screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self["actions"] = ActionMap(
            ["WizardActions", "DirectionActions"],
            {
                "ok": self.close,
                "back": self.close,
                "cancel": self.close,
            },
            -1,
        )
        self.finished_cb = None
        if config.plugins.alanturing.settingsprefix.value == "none":
            self.fullbackupfilename = "/data/backup/enigma2settingsbackup.tar.gz"
        else:
            self.fullbackupfilename = "/data/backup/%senigma2settingsbackup.tar.gz" % (
                config.plugins.alanturing.settingsprefix.value
            )
        self.list = []
        ConfigListScreen.__init__(self, self.list)
        self.onLayoutFinish.append(self.layoutFinished)
        self.onShown.append(self.doRestore)

    def layoutFinished(self):
        self.setWindowTitle()

    def setWindowTitle(self):
        self.setTitle(_("Restore is running..."))

    def doRestore(self):
        restorecmdlist = [
            "tar -xzvf " + self.fullbackupfilename + " -C /",
            "killall -9 enigma2",
        ]
        if self.finished_cb:
            self.session.openWithCallback(
                self.finished_cb,
                Console,
                title=_("Restore is running..."),
                cmdlist=restorecmdlist,
            )
        else:
            self.session.open(
                Console, title=_("Restore is running..."), cmdlist=restorecmdlist
            )

    def backupFinishedCB(self, retval=None):
        self.close(True)

    def backupErrorCB(self, retval=None):
        self.close(False)

    def runAsync(self, finished_cb):
        self.finished_cb = finished_cb
        self.doRestore()

class AlanTuringInformation(Screen):
    if sz_w == 2560:
        skin = """
        <screen position="160,1000" size="480,80" title="Alan Turing Information Menu" flags="wfNoBorder" backgroundColor="#ffffffff" zPosition="9">
	<widget name="lights" position="0,0" size="480,80"/>
        </screen>"""
    elif sz_w == 1920:
        skin = """
        <screen position="120,800" size="480,80" title="Alan Turing Information Menu" flags="wfNoBorder" backgroundColor="#ffffffff" zPosition="9">
	<widget name="lights" position="0,0" size="480,80"/>
        </screen>"""
    else:
        skin = """
        <screen position="80,500" size="480,80" title="Alan Turing Information Menu" flags="wfNoBorder" backgroundColor="#ffffffff" zPosition="9">
	<widget name="lights" position="0,0" size="480,80"/>
        </screen>"""

    def __init__(self, session):
        self.skin = AlanTuringInformation.skin
        self.setup_title = at_title + " " + _("Information")
        Screen.__init__(self, session)
        self["lights"] = Pixmap()
        # explizit check on every entry
        self.onChangedEntry = []
        self.onConfigEntryChanged = []
        self.session = session
        self["actions"] = ActionMap(
            ["SetupActions"],
            {"cancel": self.goBack, "back": self.goBack, "ok": self.goBack},
            -1,
        )
        self.onLayoutFinish.append(self.byLayoutEnd)

    def goBack(self):
        self.close()

    def byLayoutEnd(self):
        gm.fury()
        self["lights"].instance.setPixmapFromFile("/tmp/lights.svg")


class AlanTuringLog(Screen, HelpableScreen):
    if sz_w == 2560:
        skin = """
        <screen position="center,center" size="2240,1320" flags="wfNoBorder">
        <widget name="showlog" position="0,0" size="2240,1320" font="Regular;56" valign="left" halign="left" backgroundColor="black" foregroundColor="yellow">
        </widget>
        </screen>"""
    elif sz_w == 1920:
        skin = """
        <screen position="center,center" size="1860,1020" flags="wfNoBorder">
        <widget name="showlog" position="0,0" size="1860,1020" font="Regular;44" valign="left" halign="left" backgroundColor="black" foregroundColor="yellow">
        </widget>
        </screen>"""
    else:
        skin = """
        <screen position="center,center" size="1120,660" flags="wfNoBorder">
        <widget name="showlog" position="0,0" size="1120,660" font="Regular;28" valign="left" halign="left" backgroundColor="black" foregroundColor="yellow">
        </widget>
        </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        HelpableScreen.__init__(self)
        self.skin = AlanTuringLog.skin
        self["showlog"] = MultiColorLabel("\n")
        self.log_page = 1
        self.log_lines = 20
        self.last_page = int(self.logLines() // self.log_lines) + 1
        self.onShown.append(self.setWindowTitle)
        self["colorActions"] = HelpableActionMap(
            self,
            "ColorActions",
            {
                "green": (self.cancel, _("Exit")),
                "red": (self.cancel, _("Exit")),
                "yellow": (self.deleteLog, _("Delete")),
                "blue": (self.about, _("About")),
            },
        )
        self["okCancelActions"] = HelpableActionMap(
            self,
            "OkCancelActions",
            {
                "save": (self.save, _("Exit")),
                "cancel": (self.cancel, _("Exit")),
                "ok": (self.save, _("Exit")),
            },
        )
        self["teletextActions"] = HelpableActionMap(
            self,
            "InfobarTeletextActions",
            {
                "startTeletext": (self.save, _("Exit")),
            },
        )
        self["infobarChannelSelectAction"] = HelpableActionMap(
            self,
            "InfobarChannelSelection",
            {
                "switchChannelDown": (self.forward, _("Next")),
                "switchChannelUp": (self.backward, _("Prev")),
            },
        )
        self["channelSelectBaseActions"] = HelpableActionMap(
            self,
            "ChannelSelectBaseActions",
            {
                "prevBouquet": (self.forward, _("Next")),
                "nextBouquet": (self.backward, _("Prev")),
                "selectServiceDown": (self.forward, _("Next")),
                "selectServiceUp": (self.backward, _("Prev")),
                "selectServicePageDown": (self.end, _("End")),
                "selectServicePageUp": (self.begin, _("Begin")),
            },
        )
        self["channelSelectEPGActions"] = HelpableActionMap(
            self,
            "ChannelSelectEPGActions",
            {
                "showEPGList": (self.about, _("About")),
            },
        )
        # for new RC use Audio as Help key
        self["InfobarAudioSelectionActions"] = HelpableActionMap(
            self,
            "InfobarAudioSelectionActions",
            {
                "audioSelection": (self.audioPressed, _("Help")),
            },
            -3,
        )
        self.showLogPage()

    def audioPressed(self):
        audio2Help()

    # without border = just for skinners ...
    def setWindowTitle(self):
        self.setTitle(_("Log") + " " + _("Info") + ": " + at_logfile)

    def logLines(self):
        with open(at_logfile) as f:
            for i, l in enumerate(f):
                pass
        lines = i + 1
        cprint("Log %s has %d lines" % (at_logfile, lines))
        return lines

    def showLogPage(self):
        if os_path.exists(at_logfile):
            f = open(at_logfile, "r")
            logtext = ""
            for i in range(self.log_page * self.log_lines + 1):
                if i > (self.log_page - 1) * self.log_lines:
                    line = f.readline()
                    line = line.lstrip(".")
                    if len(line) > 80:
                        logtext = logtext + line[:80] + "\n"
                    else:
                        logtext = logtext + line
                else:
                    f.readline()
            f.close
            logtext = logtext + "\n"
            # tabs become 4 blanks
            logtext = logtext.replace("\t", "    ")
            self["showlog"].setText(logtext)
        else:
            cprint("not found")

    def save(self):
        self.close(True)

    def cancel(self):
        self.close(False)

    def begin(self):
        self.log_page = 1
        self.showLogPage()

    def end(self):
        self.log_page = self.last_page
        self.showLogPage()

    def backward(self):
        self.log_page = self.log_page - 1
        if self.log_page < 1:
            self.log_page = 1
        self.showLogPage()

    def forward(self):
        self.log_page = self.log_page + 1
        if self.log_page > self.last_page:
            self.log_page = self.last_page
        self.showLogPage()

    def about(self):
        self.session.open(
            MessageBox,
            alanturing_title
            + "\n\n"
            + _("Log")
            + " "
            + _("Info")
            + ":\n\n"
            + at_logfile,
            MessageBox.TYPE_INFO,
        )

    def deleteLog(self):
        cprint("delete: %s" % at_logfile)
        if not at_logfile.startswith("/tmp"):
            self.session.open(
                MessageBox,
                at_logfile + " " + _("You cannot delete this!"),
                MessageBox.TYPE_ERROR,
            )
        else:
            if os_path.exists(at_logfile):
                self.session.openWithCallback(
                    self.deleteLogConfirmed,
                    MessageBox,
                    _("Do you really want to delete %s?") % at_logfile,
                    MessageBox.TYPE_YESNO,
                )
            else:
                self.session.open(
                    MessageBox,
                    at_logfile + " " + _("Service not found!"),
                    MessageBox.TYPE_ERROR,
                )

    def deleteLogConfirmed(self, answer):
        if answer:
            os_remove(at_logfile)
            self.session.openWithCallback(
                self.close,
                MessageBox,
                at_logfile + " " + _("delete file") + " " + _("done!"),
                MessageBox.TYPE_INFO,
            )


###############################################################################
# Alan Turing Webinterface by gutemine
###############################################################################


class AlanTuringChild(resource.Resource):
    def __init__(self, session):
        self.session = session
        self.putChild("alanturing", AlanTuringWeb())


class AlanTuringWeb(resource.Resource):
    def render(self, req):
        images_string = _("Images")
        backups_string = _("Backup")
        execute_string = _("OK")
        reset_string = _("Reset")
        nowebif_string = _("Sorry, Alan Turing webinterface is currently disabled")
        maxlen = int(config.plugins.alanturing.maxlen.value)
        req.setHeader("Content-type", "text/html")
        req.setHeader("charset", "UTF-8")
        if (
            os_path.exists(
                "/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/web-data/img/alanturing.png"
            )
            is False
        ):
            if os_path.exists("%s/alanturing.png" % at_plugindir):
                os_symlink(
                    "%s/alanturing.png" % at_plugindir,
                    "/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/web-data/img/alanturing.png",
                )
        if (
            os_path.exists(
                "/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/web-data/img/busy.png"
            )
            is False
        ):
            if os_path.exists("%s/busy.png" % at_plugindir):
                os_symlink(
                    "%s/busy.png" % at_plugindir,
                    "/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/web-data/img/busy.png",
                )
        global at_progress
        global at_duration
        global at_file

        """ rendering server response """
        command = req.args.get("cmd", None)

        htmlimagetasks = '<option value="select" class="black">%s</option>\n' % _(
            "Select"
        )
        htmlimagetasks += '<option value="backuping" class="black">%s</option>\n' % _(
            "Backup"
        )
        htmlimagetasks += '<option value="renaming" class="black">%s</option>\n' % _(
            "Rename"
        )
        htmlimagetasks += '<option value="removing" class="black">%s</option>\n' % _(
            "Remove"
        )
        htmlimagetasks += '<option value="copying" class="black">%s</option>\n' % _(
            "Copy"
        )

        htmlimages = ""
        images = []
        images = gm.images()
        booted = gm.booted()
        for image in images:
            if image == booted:
                htmlimages += '<option value="%s">@ %s @</option>\n' % (image, image)
            else:
                htmlimages += '<option value="%s">%s</option>\n' % (image, image)

        htmlbackuptasks = '<option value="restore" class="black">%s</option>\n' % _(
            "Restore"
        )
        htmlbackuptasks += '<option value="rename" class="black">%s</option>\n' % _(
            "Rename"
        )
        htmlbackuptasks += '<option value="copy" class="black">%s</option>\n' % _(
            "Copy"
        )
        htmlbackuptasks += '<option value="remove" class="black">%s</option>\n' % _(
            "Remove"
        )
        htmlbackups = "<br>\n"
        backups = []
        backups = gm.backups()
        for backup in backups:
            htmlbackups += '<option value="%s" class="black">%s</option>\n' % (
                backup,
                backup,
            )
        mainmenu_string = at_title + " " + _("Mainmenu")
        mainmenurefresh_string = _("Refresh")
        booted = gm.booted()
        header_string = _("%s %s (c) gutemine 2022 %s %s %s @ %s @") % (
            at_title,
            _("Webinterface"),
            _("Version"),
            at_version,
            at_boxtype,
            booted,
        )
        new_image = gm.trim("", maxlen)
        help_string = _("Help")
        about_string = (
            _("About") + " " + at_title + " " + _("Version") + " " + at_version
        )
        checkinfo_string = _("Information") + " " + _("Results") + " " + _("Mainmenu")
        action_string = _("Start Webinterface")
        busy_string = at_title + " " + action_string + " " + _("In Progress")

        if command is None:
            html = (
                '<html>\n<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"\n             "http://www.w3.org/TR/html4/loose.dtd">\n<head>\n<title>%s</title>\n<link rel="shortcut icon" type="/web-data/image/x-icon" href="/web-data/img/favicon.ico">\n<meta content="text/html; charset=UTF-8" http-equiv="content-type">\n'
                % header_string
            )
            html += '<STYLE type="text/css">\n'
            html += "OPTION.blue{background-color:white; color:blue}"
            html += "OPTION.black{background-color:white; color:black}"
            html += "OPTION.green{background-color:white; color:green}"
            html += "</STYLE>\n"
            html += '</head>\n<body bgcolor="%s">\n' % at_background
            html += '<font face="Tahoma, Arial, Helvetica" color="black">\n'
            html += '<font size="3 " color="black">\n'
            html += "<hr>\n"
            html += "%s" % header_string
            html += "<hr>\n"
            no_reply=html + nowebif_string                 
            if not config.plugins.alanturing.webinterface.value:                       
                return no_reply.encode('utf-8')  
            if os_path.exists(at_busy):
                at_progress = gm.progress()
                at_duration = gm.duration()
                html += (
                    '<br><img src="/web-data/img/busy.png" alt="busy ..."/><br><br>\n'
                )
            else:
                at_progress = "0"
                at_duration = 0
                html += '<br><img src="/web-data/img/alanturing.png" alt="Alan Turing ..."/><br><br>\n'
            html += '<form method="GET">\n'
            html += '<input type="hidden" name="">\n'
            html += '<input type="submit" value="%s">\n' % mainmenurefresh_string
            html += "</select>\n"
            html += "</form>\n"
            if int(at_progress) > 0:
                html += "<b>%s MB" % (at_progress)
                html += "&nbsp;&nbsp;&nbsp;&nbsp;%d %s<br>" % (
                    at_duration,
                    _("seconds"),
                )
                html += (
                    '<div style="background-color:yellow;width:%spx;height:20px;border:1px solid #000"></div> '
                    % (int(at_progress))
                )
            html += "<hr>\n"
            html += "%s<br><br>\n" % images_string
            html += '<form method="GET">\n'
            html += '<select name="cmd">\n'
            html += "%s" % htmlimagetasks
            html += "</select>\n"
            html += '<select name="image">\n'
            html += "%s" % htmlimages
            html += (
                '<input name="backup" type="text" value="%s" size="%d" maxlength="%d">\n'
                % (new_image, maxlen, maxlen)
            )
            html += "<br><br>\n"
            html += '<input type="submit" size=="100px" value="%s">\n' % execute_string
            html += '<input type="reset" size="100px" value="%s">\n' % reset_string
            html += "</form>\n"
            html += "<hr>\n"
            html += "%s<br><br>\n" % backups_string
            html += '<form method="GET">\n'
            html += '<select name="cmd">\n'
            html += "%s" % htmlbackuptasks
            html += "</select>\n"
            html += '<select name="backup">\n'
            html += "%s" % htmlbackups
            html += (
                '<input name="image" type="text" value="%s" size="%d" maxlength="%d">\n'
                % (new_image, maxlen, maxlen)
            )
            html += "<br>\n<br>\n"
            html += '<input type="submit" size=="100px" value="%s">\n' % execute_string
            html += '<input type="reset" size="100px" value="%s">\n' % reset_string
            html += "</form>\n"
            html += "<hr>\n"
            html += "%s<br><br>" % help_string
            html += '<form method="GET">\n'
            html += '<input type="hidden" name="cmd" value="about">\n'
            html += '<input type="submit" value="%s">\n' % about_string
            html += "</select>\n"
            html += "</form>\n"
            html += "<hr>\n"
            html += "</body>\n"
            html += "</html>\n"
        elif command[0] == "about":
            html = (
                '<html>\n<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"\n             "http://www.w3.org/TR/html4/loose.dtd">\n<head>\n<title>about %s</title>\n<link rel="shortcut icon" type="/web-data/image/x-icon" href="/web-data/img/favicon.ico">\n<meta content="text/html; charset=UTF-8" http-equiv="content-type">\n</head>\n<body bgcolor="%s">\n'
                % (header_string, at_background)
            )
            html += '<font face="Tahoma, Arial, Helvetica" color="black">\n'
            html += '<font size="3 " color="black">\n'
            html += "<b>%s</b>\n" % at4
            html += "<hr>\n"
            free = gm.free()
            freeMB = "{:n}".format(free)
            atDevice = gm.device()
            html += "<b>%s %s: %s</b>\n" % (at_title, _("Device"), atDevice)
            html += "<hr>\n"
            html += "<b>%s %s MB</b><br>\n" % (_("Free"), freeMB)
            html += (
                '<div style="background-color:yellow;width:%spx;height:20px;border:1px solid #000"></div> '
                % (free / 100)
            )
            html += "<hr>\n"
            html += "<b>%s</b>\n" % at1
            html += "<hr>\n"
            html += "%s<br>\n" % at2
            html += "%s<br>\n" % at3
            html += "<hr>\n"
            html += "<b>%s</b>" % at5
            html += "<hr>\n"
            html += '<form method="GET">\n'
            html += '<input type="hidden" name="">\n'
            html += '<input type="submit" value="%s">\n' % mainmenu_string
            html += "</select>\n"
            html += "</form>\n"
            html += "<hr>\n"
            html += "<b>%s %s</b>\n" % (at_title, _("Help"))
            html += "<hr>\n"
            if os_path.exists(
                "/usr/share/doc/enigma2-plugin-extensions-alanturing/README"
            ):
                h = open(
                    "/usr/share/doc/enigma2-plugin-extensions-alanturing/README", "r"
                )
                line = " "
                while line:
                    line = h.readline()
                    html += "%s<br>\n" % line
                h.close()
            html += "</body>\n"
            html += "</html>\n"
        else:
            arguments = (
                req.args.get("arguments", " ")[0]
                .rstrip()
                .replace(" ", "")
                .replace("|", "")
                .replace(">\n", "")
                .replace("<", "")
            )
            imagename = (
                req.args.get("image", " ")[0]
                .rstrip()
                .replace(" ", "")
                .replace("|", "")
                .replace(">\n", "")
                .replace("<", "")
            )
            backupname = (
                req.args.get("backup", " ")[0]
                .rstrip()
                .replace(" ", "")
                .replace("|", "")
                .replace(">\n", "")
                .replace("<", "")
            )
            if os_path.exists(at_busy):
                html = (
                    '<html>\n<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"\n             "http://www.w3.org/TR/html4/loose.dtd">\n<head>\n<title>%s</title>\n<link rel="shortcut icon" type="/web-data/image/x-icon" href="/web-data/img/favicon.ico">\n<meta content="text/html; charset=UTF-8" http-equiv="content-type">\n</head>\n<body bgcolor="%s">\n'
                    % (header_string, at_background)
                )
                html += '<font face="Tahoma, Arial, Helvetica" color="black">\n'
                html += '<font size="3 " color="black">\n'
                html += "<hr>\n"
                html += "%s" % busy_string
                html += "<hr>\n"
                html += "%s" % checkinfo_string
                html += "<hr>\n"
                html += '<form method="GET">\n'
                html += '<input type="hidden" name="">\n'
                html += '<input type="submit" value="%s">\n' % mainmenu_string
                html += "</select>\n"
                html += "</form>\n"
                return html.encode('utf-8')
            else:
                executing_string = _("Alan Turing Version %s %s %s %s %s") % (
                    at_version,
                    _("Start Webinterface"),
                    command[0],
                    imagename,
                    backupname,
                )
                html = (
                    '<html>\n<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"\n             "http://www.w3.org/TR/html4/loose.dtd">\n<head>\n<title>%s</title>\n<link rel="shortcut icon" type="/web-data/image/x-icon" href="/web-data/img/favicon.ico">\n<meta content="text/html; charset=UTF-8" http-equiv="content-type">\n</head>\n<body bgcolor="%s">\n'
                    % (header_string, at_background)
                )
                html += '<font face="Tahoma, Arial, Helvetica" color="black">\n'
                html += '<font size="3 " color="black">\n'
                html += "<hr>\n"
                html += "%s" % executing_string
                html += "<hr>\n"
                html += "</body>\n</html>\n"
            if command[0] == "restore":
                sourcename = backupname
                targetname = gm.trim(imagename)
                if os_path.exists(targetname):
                    html += _("The path %s already exists.") % targetname
                else:
                    html += "%s %s %s -> %s" % (
                        backups_string,
                        _("Restore"),
                        sourcename,
                        targetname,
                    )
                    cprint("restore %s -> %s" % (sourcename, targetname))
                    gm.restoring(sourcename, targetname)
                html += "<hr>\n"
                html += "%s" % checkinfo_string
                html += "<hr>\n"
                html += '<form method="GET">\n'
                html += '<input type="hidden" name="">\n'
                html += '<input type="submit" value="%s">\n' % mainmenu_string
                html += "</select>\n"
                html += "</form>\n"
            elif command[0] == "rename":
                sourcename = backupname
                if sourcename.endswith(".tar.gz"):
                    extension = "tar.gz"
                if sourcename.endswith(".tar.gz"):
                    extension = "tar.xz"
                if sourcename.endswith(".tar.bz2"):
                    extension = "tar.bz2"
                if sourcename.endswith(".zip"):
                    extension = "zip"
                path = os_path.dirname(sourcename)
                name = gm.trim(os_path.basename(imagename), 0)
                targetname = "%s/%s.%s" % (path, name, extension)
                if os_path.exists(targetname):
                    html += _("The path %s already exists.") % targetname
                else:
                    html += "%s %s %s -> %s" % (
                        backups_string,
                        _("Rename"),
                        sourcename,
                        targetname,
                    )
                    cprint("rename %s -> %s" % (sourcename, targetname))
                    gm.renaming(sourcename, targetname)
                html += "<hr>\n"
                html += "%s" % checkinfo_string
                html += "<hr>\n"
                html += '<form method="GET">\n'
                html += '<input type="hidden" name="">\n'
                html += '<input type="submit" value="%s">\n' % mainmenu_string
                html += "</select>\n"
                html += "</form>\n"
            elif command[0] == "copy":
                sourcename = backupname
                if sourcename.endswith(".tar.gz"):
                    extension = "tar.gz"
                if sourcename.endswith(".tar.gz"):
                    extension = "tar.xz"
                if sourcename.endswith(".tar.bz2"):
                    extension = "tar.bz2"
                if sourcename.endswith(".zip"):
                    extension = "zip"
                path = os_path.dirname(sourcename)
                name = gm.trim(os_path.basename(imagename), 0, False, False, False)
                targetname = "%s/%s.%s" % (path, name, extensions)
                if os_path.exists(targetname):
                    html += _("The path %s already exists.") % targetname
                else:
                    html += "%s %s %s -> %s" % (
                        backups_string,
                        _("Copy"),
                        sourcename,
                        targetname,
                    )
                    cprint("copy %s -> %s" % (sourcename, targetname))
                    gm.copying(sourcename, targetname)
                html += "<hr>\n"
                html += "%s" % checkinfo_string
                html += "<hr>\n"
                html += '<form method="GET">\n'
                html += '<input type="hidden" name="">\n'
                html += '<input type="submit" value="%s">\n' % mainmenu_string
                html += "</select>\n"
                html += "</form>\n"
            elif command[0] == "remove":
                sourcename = backupname
                html += "%s %s %s" % (backups_string, _("Remove"), sourcename)
                html += "<hr>\n"
                html += "%s" % checkinfo_string
                html += "<hr>\n"
                html += '<form method="GET">\n'
                html += '<input type="hidden" name="">\n'
                html += '<input type="submit" value="%s">\n' % mainmenu_string
                html += "</select>\n"
                html += "</form>\n"
                cprint("remove %s" % sourcename)
                gm.removing(sourcename)
            elif command[0] == "select":
                sourcename = imagename
                html += "%s %s %s" % (images_string, _("Select"), sourcename)
                html += "<hr>\n"
                html += "%s" % checkinfo_string
                html += "<hr>\n"
                html += '<form method="GET">\n'
                html += '<input type="hidden" name="">\n'
                html += '<input type="submit" value="%s">\n' % mainmenu_string
                html += "</select>\n"
                html += "</form>\n"
                cprint("selecting %s" % sourcename)
                gm.selecting(sourcename)
                from API import session

                session.open(TryQuitMainloop, 2)
            elif command[0] == "backuping":
                sourcename = imagename
                name = gm.trim(
                    backupname.replace(".tar.gz", "")
                    .replace(".tar.xz", "")
                    .replace(".tar.bz2", ""),
                    0,
                    False,
                    False,
                    False,
                )
                targetname = "%s/%s.%s" % (
                    at_backups,
                    name,
                    config.plugins.alanturing.backuptool.value,
                )
                if os_path.exists(targetname):
                    html += _("The path %s already exists.") % targetname
                else:
                    cprint("saving %s -> %s" % (sourcename, targetname))
                    at_file = sourcename
                    gm.saving(sourcename,targetname)
                html += "%s %s %s -> %s" % (
                    images_string,
                    _("Backup"),
                    sourcename,
                    targetname,
                )
                html += "<hr>\n"
                html += "%s" % checkinfo_string
                html += "<hr>\n"
                html += '<form method="GET">\n'
                html += '<input type="hidden" name="">\n'
                html += '<input type="submit" value="%s">\n' % mainmenu_string
                html += "</select>\n"
                html += "</form>\n"
            elif command[0] == "renaming":
                sourcename = imagename
                targetname = gm.trim(
                    backupname.replace(".tar.gz", "")
                    .replace(".tar.xz", "")
                    .replace(".tar.bz2", "")
                    .replace(".zip", ""),
                    0,
                    False,
                    False,
                    False,
                )
                if sourcename == "Flash":
                    html += "%s %s %s -> %s = %s" % (
                        images_string,
                        _("Rename"),
                        sourcename,
                        targetname,
                        _("No, do nothing.").replace(".", "!"),
                    )
                else:
                    target = "%s/%s" % (at_images, targetname)
                    if os_path.exists(target):
                        html += _("The path %s already exists.") % targetname
                    else:
                        html += "%s %s %s -> %s" % (
                            images_string,
                            _("Rename"),
                            sourcename,
                            targetname,
                        )
                        cprint("renaming %s -> %s" % (sourcename, targetname))
                        gm.renaming(sourcename, targetname)
                html += "<hr>\n"
                html += "%s" % checkinfo_string
                html += "<hr>\n"
                html += '<form method="GET">\n'
                html += '<input type="hidden" name="">\n'
                html += '<input type="submit" value="%s">\n' % mainmenu_string
                html += "</select>\n"
                html += "</form>\n"
            elif command[0] == "removing":
                sourcename = imagename
                if sourcename == "Flash":
                    html += "%s %s %s = %s" % (
                        images_string,
                        _("Remove"),
                        sourcename,
                        _("No, do nothing.").replace(".", "!"),
                    )
                else:
                    html += "%s %s %s" % (images_string, _("Remove"), sourcename)
                html += "<hr>\n"
                html += "%s" % checkinfo_string
                html += "<hr>\n"
                html += '<form method="GET">\n'
                html += '<input type="hidden" name="">\n'
                html += '<input type="submit" value="%s">\n' % mainmenu_string
                html += "</select>\n"
                html += "</form>\n"
                cprint("removing %s" % sourcename)
                gm.removing(sourcename)
            elif command[0] == "copying":
                sourcename = imagename
                targetname = gm.trim(
                    backupname.replace(".tar.gz", "")
                    .replace(".tar.xz", "")
                    .replace(".tar.bz2", "")
                    .replace(".zip", ""),
                    0,
                    False,
                    False,
                    False,
                )
                html += "%s %s %s -> %s" % (
                    images_string,
                    _("Copy"),
                    sourcename,
                    targetname,
                )
                target = "%s/%s" % (at_images, targetname)
                if os_path.exists(target):
                    html += _("The path %s already exists.") % targetname
                else:
                    html += "%s %s %s -> %s" % (
                        images_string,
                        _("Copy"),
                        sourcename,
                        targetname,
                    )
                    cprint("copying %s -> %s" % (sourcename, targetname))
                    gm.copying(sourcename, targetname)
                html += "<hr>\n"
                html += "%s" % checkinfo_string
                html += "<hr>\n"
                html += '<form method="GET">\n'
                html += '<input type="hidden" name="">\n'
                html += '<input type="submit" value="%s">\n' % mainmenu_string
                html += "</select>\n"
                html += "</form>\n"
            else:
                pass
        req.setHeader("Content-type", "text/html")
        return html.encode('utf-8')

