# # -*- coding: utf-8 -*-
# code by emanuel@ihad.tv

from Screens.Screen import Screen

from Components.ActionMap import ActionMap
from Components.FileList import FileList
from Components.ConfigList import ConfigListScreen
from Components.config import config, ConfigSubsection, ConfigDirectory
from Components.Label import Label
from Components.Sources.StaticText import StaticText
from enigma import getDesktop

from Tools.Directories import pathExists, createDir, SCOPE_HDD, SCOPE_PLUGINS, resolveFilename

from skin import loadSkin

sz_w = getDesktop(0).size().width()

loadSkin(resolveFilename(SCOPE_PLUGINS, "SystemPlugins/DisplaySkin/skin.xml"))

config.plugins.displayskin = ConfigSubsection()
config.plugins.displayskin.oledpiconlocation = ConfigDirectory(default="/media/")
config.plugins.displayskin.progresslocation = ConfigDirectory(default="/usr/share/enigma2/skin_oled/bars/Progressbar/")
config.plugins.displayskin.linelocation = ConfigDirectory(default="/usr/share/enigma2/skin_oled/bars/Line/")
config.plugins.displayskin.idlelocation = ConfigDirectory(default="/usr/share/enigma2/skin_oled/standby/")
config.plugins.displayskin.renderlocation = ConfigDirectory(default="/usr/share/enigma2/skin_oled/render/")

#-----------------------------------------------------------------------------------

class DisplaySkinBrowserSummary(Screen):
	def __init__(self, session, parent):
		Screen.__init__(self, session, parent = parent)
		self.skinName = ["DisplaySkinBrowserSummary"]

#-----------------------------------------------------------------------------------

class DisplaySkinBrowser(Screen):
	def __init__(self, session):
		Screen.__init__(self, session)
		if sz_w == 1920:
			self.skinName = ["DisplaySkinBrowser_FHD"]
		else:
			self.skinName = ["DisplaySkinBrowser"]
		self["title"] = StaticText("Display Skin Browser")
		self["lcdinfo"] = StaticText()
		self.filelist = FileList(config.plugins.displayskin.oledpiconlocation.value, showDirectories = True, showFiles = False)

		self["filelist"] = self.filelist
		self["buttonred"] = Label(_("Cancel"))
		self["buttongreen"] = Label(_("Select"))
		self["info"] = Label("")
		self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "ShortcutActions", "DirectionActions"],
		{
			"ok": self.KeyOk,
			"cancel": self.KeyCancel,
			"green": self.KeyGreen,
			"red": self.KeyRed,
			"up": self.KeyUp,
			"upRepeated": self.KeyUp,
			"downRepeated": self.KeyDown,
			"down": self.KeyDown,
			"left": self.KeyLeft,
			"right": self.KeyRight
		}, -1)

		self.onShown.append(self.__setInfo)
		self.onShown.append(self.__setTitle)

	def __setTitle(self):
		self.setTitle(_("Select a display skin"))

	def __setInfo(self):
		self["info"].setText(self["filelist"].getCurrentDirectory())
		self["lcdinfo"].setText(self["filelist"].getCurrent()[1][7])

	def createSummary(self):
		return DisplaySkinBrowserSummary

	def KeyUp(self):
		self["filelist"].up()
		self.__setInfo()

	def KeyDown(self):
		self["filelist"].down()
		self.__setInfo()

	def KeyRight(self):
		self["filelist"].pageDown()
		self.__setInfo()

	def KeyLeft(self):
		self["filelist"].pageUp()
		self.__setInfo()

	def KeyGreen(self):
		if self["filelist"].getSelection()[0] <> "/autofs/" and self["filelist"].canDescent(): # isDir
			config.plugins.displayskin.oledpiconlocation.value = self["filelist"].getCurrentDirectory()
			config.plugins.displayskin.oledpiconlocation.save()
			if self["filelist"].getCurrentDirectory().endswith("/"):
				dir = self["filelist"].getCurrentDirectory()
			else:
				dir = self["filelist"].getCurrentDirectory() + "/"
			self.close(self["filelist"].getSelection()[0])

	def KeyOk(self):
		if self["filelist"].getSelection()[0] <> "/autofs/":
			if self["filelist"].canDescent(): # isDir
				self["filelist"].descent()
				self.__setInfo()

	def KeyRed(self):
		self.KeyCancel()

	def KeyCancel(self):
		self.close(None)


#-----------------------------------------------------------------------------------

class DisplaySkinProgressBrowser(DisplaySkinBrowser):
	def __init__(self, session):
		DisplaySkinBrowser.__init__(self, session)
		if sz_w == 1920:
			self.skinName = ["DisplaySkinBrowser_FHD"]
		else:
			self.skinName = ["DisplaySkinBrowser"]
		self["title"] = StaticText("Select a Display Progressbar")
		self.filelist = FileList(config.plugins.displayskin.progresslocation.value, showDirectories = True, showFiles = True, matchingPattern = "^.*\.(png|PNG)")
		self["filelist"] = self.filelist

	def KeyGreen(self):
		if self["filelist"].getSelection()[0].endswith(".png"):
			config.plugins.displayskin.progresslocation.value = self["filelist"].getCurrentDirectory().rsplit('/', 2)[0] + "/"
			config.plugins.displayskin.progresslocation.save()
			self.close(self["filelist"].getCurrentDirectory() + self["filelist"].getSelection()[0])

#-----------------------------------------------------------------------------------

class DisplaySkinLineBrowser(DisplaySkinBrowser):
	def __init__(self, session):
		DisplaySkinBrowser.__init__(self, session)
		if sz_w == 1920:
			self.skinName = ["DisplaySkinBrowser_FHD"]
		else:
			self.skinName = ["DisplaySkinBrowser"]
		self["title"] = StaticText("Select a Display Line")
		self.filelist = FileList(config.plugins.displayskin.linelocation.value, showDirectories = True, showFiles = True, matchingPattern = "^.*\.(png|PNG)")
		self["filelist"] = self.filelist

	def KeyGreen(self):
		if self["filelist"].getSelection()[0].endswith(".png"):
			config.plugins.displayskin.linelocation.value = self["filelist"].getCurrentDirectory().rsplit('/', 2)[0] + "/"
			config.plugins.displayskin.linelocation.save()
			self.close(self["filelist"].getCurrentDirectory() + self["filelist"].getSelection()[0])

#-----------------------------------------------------------------------------------

class DisplaySkinIdleBrowser(DisplaySkinBrowser):
	def __init__(self, session):
		DisplaySkinBrowser.__init__(self, session)
		if sz_w == 1920:
			self.skinName = ["DisplaySkinBrowser_FHD"]
		else:
			self.skinName = ["DisplaySkinBrowser"]
		self["title"] = StaticText("Select a Display Standby Picture")
		self.filelist = FileList(config.plugins.displayskin.idlelocation.value, showDirectories = True, showFiles = True, matchingPattern = "^.*\.(png|PNG)")
		self["filelist"] = self.filelist

	def KeyGreen(self):
		if self["filelist"].getSelection()[0].endswith(".png"):
			config.plugins.displayskin.idlelocation.value = self["filelist"].getCurrentDirectory() + "/"
			config.plugins.displayskin.idlelocation.save()
			self.close(self["filelist"].getCurrentDirectory() + self["filelist"].getSelection()[0])

#-----------------------------------------------------------------------------------

class DisplaySkinRenderBrowser(DisplaySkinBrowser):
	def __init__(self, session):
		DisplaySkinBrowser.__init__(self, session)
		if sz_w == 1920:
			self.skinName = ["DisplaySkinBrowser_FHD"]
		else:
			self.skinName = ["DisplaySkinBrowser"]
		self["title"] = StaticText("Select a Display Renderer")
		self.filelist = FileList(config.plugins.displayskin.renderlocation.value, showDirectories = True, showFiles = True, matchingPattern = "^.*\.(py|PY)")
		self["filelist"] = self.filelist

	def KeyGreen(self):
		if self["filelist"].getSelection()[0].endswith(".py"):
			config.plugins.displayskin.renderlocation.value = self["filelist"].getCurrentDirectory() + "/"
			config.plugins.displayskin.renderlocation.save()
			self.close(self["filelist"].getCurrentDirectory() + self["filelist"].getSelection()[0])


