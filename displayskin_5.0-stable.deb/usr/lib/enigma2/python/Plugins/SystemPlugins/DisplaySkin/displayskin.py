# (c) 2016 jogi29 (Thanks to emanuel, LukaNoah and JackDaniel)
#
#  The plugin is developed on the basis from a lot of single plugins (thx for the code @ all)
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#
from Screens.Console import Console
from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Components.ActionMap import NumberActionMap
from Components.Pixmap import Pixmap
from Components.Sources.StaticText import StaticText
from Components.MenuList import MenuList
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_CONFIG
from Components.config import config, ConfigText, ConfigSubsection
from About import DisplaySkinAbout
import gettext
from enigma import getDesktop
from os import path, walk
from os import environ as os_environ
import os
import gettext
from Components.Language import language

from skin import loadSkin

sz_w = getDesktop(0).size().width()

loadSkin(resolveFilename(SCOPE_PLUGINS, "SystemPlugins/DisplaySkin/skin.xml"))

def localeInit():
	lang = language.getLanguage()[:2]
	os_environ["LANGUAGE"] = lang
	print "[DisplaySkin] found LANGUAGE=", lang
	gettext.bindtextdomain("DisplaySkin", resolveFilename(SCOPE_PLUGINS, "SystemPlugins/DisplaySkin/locale"))

def _(txt):
	t = gettext.dgettext("DisplaySkin", txt)
	if t == txt:
		print "[DisplaySkin] fallback to default translation for", txt
		t = gettext.gettext(txt)
	return t

localeInit()
language.addCallback(localeInit)

config.plugins.displayskin = ConfigSubsection()
config.plugins.displayskin.skinusertmp = ConfigText(default = '/usr/share/enigma2/skin_user/01_Default')

class DisplaySkinSummary(Screen):
	def __init__(self, session, parent):
		Screen.__init__(self, session, parent = parent)
		self.skinName = ["DisplaySkinSummary"]

class DisplaySkin(Screen):
	skinuserlist = []
	root = "/usr/share/enigma2/"

	def __init__(self, session, args = None):
		Screen.__init__(self, session)
		if sz_w == 1920:
			self.skinName = ["DisplaySkin_FHD"]
		else:
			self.skinName = ["DisplaySkin"]
		self.skinuserlist = []
		self.previewPath = ""
		self.path = ""
		path.walk(self.root, self.find, "")

		self["title"] = StaticText("Display Skin")
		self["lcdinfo"] = StaticText()
		self["key_red"] = StaticText(_("Close"))
		self["key_green"] = StaticText(_("delete skin_user_display.xml"))
		self["key_yellow"] = StaticText(_("Settings"))
		self["key_blue"] = StaticText(_("About"))
		self["introduction1"] = StaticText(_("1. Select with YELLOW the oled-picon path and the other settings."))
		self["introduction2"] = StaticText(_("2. Choose your display skin.\nPress OK to activate the selected skin."))
		self.skinuserlist.sort()
		self["SkinuserList"] = MenuList(self.skinuserlist)
		self["Preview"] = Pixmap()

		self["actions"] = NumberActionMap(["WizardActions", "ColorActions", "InputActions", "EPGSelectActions"],
		{
			"ok": self.KeyOk,
			"back": self.close,
			"red": self.close,
			"green": self.delete,
			"blue": self.KeyInfo,
			"yellow": self.KeyYellow,
			"up": self.KeyUp,
			"down": self.KeyDown,
			"left": self.KeyLeft,
			"right": self.KeyRight,
		}, -1)
		self.onShown.append(self.__setTitle)
		self.onShown.append(self.__setInfo)

	def __setTitle(self):
		self.setTitle(_("Display Skin"))

	def __setInfo(self):
		pngpath = self.root+"skin_user/prev.png"
		if self["SkinuserList"].getCurrent() == "Default":
			pngpath = self.root+"skin_user/prev.png"

		elif self["SkinuserList"].getCurrent() is not None:
			pngpath = self.root+self["SkinuserList"].getCurrent()+"/prev.png"

		if not path.exists(pngpath):
			pngpath = resolveFilename(SCOPE_PLUGINS, "SystemPlugins/DisplaySkin/noprev.png")

		if self.previewPath != pngpath:
			self.previewPath = pngpath

		self["Preview"].instance.setPixmapFromFile(self.previewPath)

		if self["SkinuserList"].getCurrent() is not None:
			self["lcdinfo"].setText(self["SkinuserList"].getCurrent())

	def layoutFinished(self):
		tmp = config.plugins.displayskin.skinusertmp.value.find('/skin_user_display.xml')
		if tmp != -1:
			tmp = config.plugins.displayskin.skinusertmp.value[:tmp]
			idx = 0
			for skin in self.skinuserlist:
				if skin == tmp:
					break
				idx += 1
			if idx < len(self.skinuserlist):
				self["SkinuserList"].moveToIndex(idx)
		self.loadPreview()

	def calllink(self, path):
		if path is not None:
			self.path = path[:-1]
			self.session.openWithCallback(self.dolink, MessageBox,_("Do you want to remove\n/usr/share/enigma2/picon_oled\nan link new to\n%s?") %path, MessageBox.TYPE_YESNO)

	def dolink(self, val):
		if val:
			from os import system as os_system
			com = "rm -rf /usr/share/enigma2/picon_oled; ln -snf '%s' /usr/share/enigma2/picon_oled" %self.path
			#print ">>>>>>",com
			os_system(com)

	def KeyYellow(self):
		menu = [(_("Select the oled-picon path"),0),
			("--", "--"),
			(_("Progressbar"), 1),
			(_("Progressbar") + " " + _("(03_Kompakt)"), 2),
			("--", "--"),
			(_("Line "), 3),
			(_("Line ") + " " + _("(Service/Event)"), 4),
			("--", "--"),
			(_("Idle-Background"), 5),
			("--", "--"),
			(_("Font, colors and time format"), 6),
			("--", "--"),
			(_("RunningText yes/no"), 7)
			]

		self.session.openWithCallback(self.menuCallback, ChoiceBox, titlebartext = _("Settings"), list = menu)

	def menuCallback(self, val):
		if val == None:
			return
		else:
			value = val[1]

		if value == 0:
			from browser import DisplaySkinBrowser
			self.session.openWithCallback(self.calllink, DisplaySkinBrowser)
		elif value == 1:
			from browser import DisplaySkinProgressBrowser
			self.session.openWithCallback(self.progressCallback, DisplaySkinProgressBrowser)
		elif value == 2:
			from browser import DisplaySkinProgressBrowser
			self.session.openWithCallback(self.progressCallback2, DisplaySkinProgressBrowser)
		elif value == 3:
			from browser import DisplaySkinLineBrowser
			self.session.openWithCallback(self.lineCallback, DisplaySkinLineBrowser)
		elif value == 4:
			from browser import DisplaySkinLineBrowser
			self.session.openWithCallback(self.lineCallback2, DisplaySkinLineBrowser)
		elif value == 5:
			from browser import DisplaySkinIdleBrowser
			self.session.openWithCallback(self.IdleCallback, DisplaySkinIdleBrowser)
		elif value == 6:
			from confColor import DisplaySkinColorSet
			self.session.openWithCallback(self.ColorCallback, DisplaySkinColorSet)
		elif value == 7:
			from browser import DisplaySkinRenderBrowser
			self.session.openWithCallback(self.RenderCallback, DisplaySkinRenderBrowser)
		else:
			return

	def progressCallback(self, source):
		if source is None:
			return
		target = "/usr/share/enigma2/skin_oled/progress-lcd.png"
		self.session.open(Console, title = _("Copying progress-lcd.png"), cmdlist = ["cp \""+source+"\" \""+target+"\""],finishedCallback = self.message)

	def progressCallback2(self, source):
		if source is None:
			return
		target = "/usr/share/enigma2/skin_oled/progress-lcd-03_kompakt.png"
		self.session.open(Console, title = _("Copying progress-lcd-03_kompakt.png"), cmdlist = ["cp \""+source+"\" \""+target+"\""],finishedCallback = self.message)

	def lineCallback(self, source):
		if source is None:
			return
		target = "/usr/share/enigma2/skin_oled/line-lcd.png"
		self.session.open(Console, title = _("Copying line-lcd.png"), cmdlist = ["cp \""+source+"\" \""+target+"\""])

	def lineCallback2(self, source):
		if source is None:
			return
		target = "/usr/share/enigma2/skin_oled/line-lcd-service.png"
		self.session.open(Console, title = _("Copying line-lcd-service.png"), cmdlist = ["cp \""+source+"\" \""+target+"\""])

	def IdleCallback(self, source):
		if source is None:
			return
		target = "/usr/share/enigma2/skin_oled/icon_standby.png"
		self.session.open(Console, title = _("Copying icon_standby.png"), cmdlist = ["cp \""+source+"\" \""+target+"\""])

	def RenderCallback(self, source):
		if source is None:
			return
		target = "/usr/lib/enigma2/python/Components/Renderer/Oled_RunningText.py"
		self.session.open(Console, title = _("Copying Oled_RunningText.py"), cmdlist = ["cp \""+source+"\" \""+target+"\""],finishedCallback = self.message)

	def ColorCallback(self, edit):
		if edit is None:
			return
		else:
			self.message()

	def KeyUp(self):
		self["SkinuserList"].up()
		self.__setInfo()

	def KeyDown(self):
		self["SkinuserList"].down()
		self.__setInfo()

	def KeyLeft(self):
		self["SkinuserList"].pageUp()
		self.__setInfo()

	def KeyRight(self):
		self["SkinuserList"].pageDown()
		self.__setInfo()

	def KeyInfo(self):
		self.session.open(DisplaySkinAbout)

	def find(self, arg, dirname, names):
		for x in names:
			if x == "skin_user_display.xml":
				if dirname <> self.root:
					subdir = dirname[19:]
					self.skinuserlist.append(subdir)
				else:
					subdir = "Default"
					self.skinuserlist.append(subdir)

	def KeyOk(self):
		if self["SkinuserList"].getCurrent() is None:
			self.session.open(MessageBox, _("empty list"), MessageBox.TYPE_INFO, timeout=5)
			return
		sourceDir = self.root+self["SkinuserList"].getCurrent()+"/skin_user_display.xml"
		targetDir = "/etc/enigma2/"
		self.session.open(Console, title = _("Copying skin_user_display.xml"), cmdlist = ["cp \""+sourceDir+"\" \""+targetDir+"\""],finishedCallback = self.message)

	def message(self):
		restartbox = self.session.openWithCallback(self.restartGUI,MessageBox,_("Enigma2 needs a restart to apply the new display look.\nDo you want to restart Enigma2 now?"), MessageBox.TYPE_YESNO)

	def restartGUI(self, answer):
		if answer is True:
			self.session.open(TryQuitMainloop, 3)

	def delete(self):
		self.session.open(Console, title = _("Deleting skin_user_display.xml"), cmdlist = ["rm /etc/enigma2/skin_user_display.xml"],finishedCallback = self.message)

	def createSummary(self):
		return DisplaySkinSummary

