# (c) 2016 jogi29 (Thanks to emanuel and LukaNoah)
#
#  The plugin is developed on the basis from a lot of single plugins (thx for the code @ all)
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.Setup import SetupSummary
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from Tools.Directories import pathExists, resolveFilename, SCOPE_PLUGINS, SCOPE_CONFIG
from Components.config import config, ConfigText, ConfigSubsection, ConfigSelection, getConfigListEntry
from Components.ConfigList import ConfigList, ConfigListScreen
import gettext
from enigma import getDesktop
from os import environ as os_environ
import gettext
from Components.Language import language

from skin import loadSkin

sz_w = getDesktop(0).size().width()

import xml.etree.ElementTree as ET

loadSkin(resolveFilename(SCOPE_PLUGINS, "SystemPlugins/DisplaySkin/skin.xml"))

#--------------------------------------------------------------------------------------------

def localeInit():
	lang = language.getLanguage()[:2]
	os_environ["LANGUAGE"] = lang
	print "[DisplaySkin] found LANGUAGE=", lang
	gettext.bindtextdomain("DisplaySkin", resolveFilename(SCOPE_PLUGINS, "SystemPlugins/DisplaySkin/locale"))

def _(txt):
	t = gettext.dgettext("DisplaySkin", txt)
	if t == txt:
		print "[DisplaySkin] fallback to default translation for", txt
		t = gettext.gettext(txt)
	return t

localeInit()
language.addCallback(localeInit)

#--------------------------------------------------------------------------------------------

colors=[
	("#ffffff", _("white")),
	("#adff2f", _("rainbow")),
	("#ffff00", _("yellow")),
	("#f8deba", _("sand")),
	("#d9d978", _("beige")),
	("#00cd00", _("green")),
	("#a4c400", _("lime green")),
	("#1874cd", _("blue")),
	("#1ba1e2", _("cyan")),
	("#ff6347", _("red")),
	("#ffb347", _("orange")),
	("#ff69b4", _("pink")),
	("#ff00ff", _("magenta")),
	("#ee82ee", _("violett")),
	("#000000", _("black"))
	]

strclock=[
	("1", _("HH:MM")),
	("2", _("HH:MM:SS"))
	]

strfont=[
	("1", _("LoSoS")),
	("2", _("nmsbd")),
	("3", _("Roboto-Medium"))
	]

config.plugins.displayskin = ConfigSubsection()
config.plugins.displayskin.color_oled1 = ConfigSelection(default="#adff2f",  choices = colors)
config.plugins.displayskin.color_oled2 = ConfigSelection(default="#ffffff",  choices = colors)
config.plugins.displayskin.color_oled3 = ConfigSelection(default="#adff2f",  choices = colors)
config.plugins.displayskin.color_oled4 = ConfigSelection(default="#adff2f",  choices = colors)
config.plugins.displayskin.color_oled5 = ConfigSelection(default="#ffffff",  choices = colors)
config.plugins.displayskin.oled_clock = ConfigSelection(default="2", choices = strclock)
config.plugins.displayskin.oled_font = ConfigSelection(default="1", choices = strfont)

#--------------------------------------------------------------------------------------------

class DisplaySkinColorSet(Screen, ConfigListScreen):

	def __init__(self, session, args = None):
		Screen.__init__(self, session)
		if sz_w == 1920:
			self.skinName = ["DisplaySkinColorSet_FHD"]
		else:
			self.skinName = ["DisplaySkinColorSet"]
		self["title"] = StaticText("Display Skin")
		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("Save"))
		self["introduction"] = StaticText(_("Select with left / right your favourite colors."))

		self.skinTree = None
		self.path = resolveFilename(SCOPE_CONFIG, "skin_user_display.xml")

		self.list = []
		self.list.append(getConfigListEntry(_("color menu"), config.plugins.displayskin.color_oled1))
		self.list.append(getConfigListEntry(_("color text"), config.plugins.displayskin.color_oled2))
		self.list.append(getConfigListEntry(_("color clock"), config.plugins.displayskin.color_oled3))
		self.list.append(getConfigListEntry(_("color service"), config.plugins.displayskin.color_oled4))
		self.list.append(getConfigListEntry(_("color event"), config.plugins.displayskin.color_oled5))
		self.list.append(getConfigListEntry(_("Font"), config.plugins.displayskin.oled_font))
		self.list.append(getConfigListEntry(_("Format clock"), config.plugins.displayskin.oled_clock))

		ConfigListScreen.__init__(self, self.list, session)

		self["actions"] = ActionMap(["SetupActions", "ColorActions"],
		{
			"green": self.KeySave,
			"red": self.KeyExit,
			"cancel": self.KeyExit,
			"ok": self.KeySave,
		}, -2)

		self.onShown.append(self.__Shown)

	def __Shown(self):
		if not pathExists(self.path):
			self.session.open(MessageBox, _("file not found: ") + self.path, MessageBox.TYPE_ERROR, timeout=5)
			self.close(None)
			return
		else:
			self.skinTree = DisplaySkinTree(path=self.path)
			self.setTitle(_("Display Skin - Colorselection"))

	def createSummary(self):
		return SetupSummary

	def KeySave(self):
		for x in self["config"].list:
			x[1].save()

		self.skinTree.setColors(config.plugins.displayskin.color_oled1.value, config.plugins.displayskin.color_oled2.value, config.plugins.displayskin.color_oled3.value, config.plugins.displayskin.color_oled4.value, config.plugins.displayskin.color_oled5.value)
		self.skinTree.setFont(config.plugins.displayskin.oled_font.value)
		self.skinTree.save()
		self.close(True)

	def KeyExit(self):
		for x in self["config"].list:
			x[1].cancel()
		self.close(None)

#--------------------------------------------------------------------------------------------

class PCParser(ET.XMLTreeBuilder):

   def __init__(self):
       ET.XMLTreeBuilder.__init__(self)
       self._parser.CommentHandler = self.handle_comment

   def handle_comment(self, data):
       self._target.start(ET.Comment, {})
       self._target.data(data)
       self._target.end(ET.Comment)

parser = PCParser()

#--------------------------------------------------------------------------------------------

class DisplaySkinTree(object):

	def __init__(self, path):
		self.path = path
		self.tree = ET.parse(path, parser=parser)
		self.root = self.tree.getroot()

	def save(self):
		self.tree.write(self.path)

	def setColors(self, color_oled1, color_oled2, color_oled3, color_oled4, color_oled5):
		for color in self.root.findall("./colors/color"):
			if color.get("name") == "oled1":
				color.set('value', color_oled1)
			elif color.get("name") == "oled2":
				color.set('value', color_oled2)
			elif color.get("name") == "oled3":
				color.set('value', color_oled3)
			elif color.get("name") == "oled4":
				color.set('value', color_oled4)
			elif color.get("name") == "oled5":
				color.set('value', color_oled5)

	def setFont(self, toset):
		for font in self.root.findall("./fonts/font"):
			if font.get("name") == "LCD1":
				if toset == "2":
					font.set('filename', 'nmsbd.ttf')
					font.set('scale','88')
				elif toset == "3":
					font.set('filename', '/usr/share/enigma2/skin_oled/fonts/roboto.light.ttf')
					font.set('scale','92')
				else:
					font.set('filename', '/usr/share/enigma2/skin_oled/fonts/LoSoS.ttf')
					font.set('scale','92')
