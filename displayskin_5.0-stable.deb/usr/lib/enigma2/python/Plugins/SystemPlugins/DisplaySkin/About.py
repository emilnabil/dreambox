from Screens.Screen import Screen
from Components.Sources.StaticText import StaticText
from Tools.Directories import *
import os
from Components.Label import Label
from Components.Pixmap import Pixmap
#from Components.Button import Button
from Components.ActionMap import ActionMap
from enigma import getDesktop
from os import environ as os_environ
import gettext
from Components.Language import language

sz_w = getDesktop(0).size().width()

def localeInit():
    lang = language.getLanguage()[:2]
    os_environ["LANGUAGE"] = lang
    print "[DisplaySkin] found LANGUAGE=", lang
    gettext.bindtextdomain("DisplaySkin", resolveFilename(SCOPE_PLUGINS, "SystemPlugins/DisplaySkin/locale"))

def _(txt):
    t = gettext.dgettext("DisplaySkin", txt)
    if t == txt:
        print "[DisplaySkin] fallback to default translation for", txt
        t = gettext.gettext(txt)
    return t

localeInit()
language.addCallback(localeInit)

class DisplaySkinAbout(Screen):
    if sz_w == 1920:
        skin = """
        <screen name="DisplaySkinAbout" position="center,center" size="700,280" title="About Display Skin">
		<ePixmap pixmap="Default-FHD/skin_default/buttons/red.svg" position="10,0" size="300,70"/>
		<widget source="key_red" render="Label" position="10,0" size="300,70" zPosition="1" font="Regular;29" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" />
		<eLabel position="10,80" size="680,1" backgroundColor="grey" />
		<widget source="version" render="Label" position="10,95" size="400,80" font="Regular;34" halign="center" valign="center" />
		<widget source="author" render="Label" position="10,195" size="400,40" font="Regular;34" halign="center" valign="center" />
		<ePixmap pixmap="%s" position="460,90" size="160,160"/>
    	</screen>""" % ( resolveFilename(SCOPE_PLUGINS, "SystemPlugins/DisplaySkin/g3icon_displayskin.png" ))
    else:
        skin = """
        <screen name="DisplaySkinAbout" position="center,center" size="500,200" title="About Display Skin">
		<ePixmap pixmap="skin_default/buttons/red.png" position="10,0" size="260,50"/>
		<widget source="key_red" render="Label" position="10,0" size="260,50" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" />
		<eLabel position="10,55" size="480,1" backgroundColor="grey" />
		<widget source="version" render="Label" position="0,70" size="340,70" font="Regular;24" halign="center" valign="center" />
		<widget source="author" render="Label" position="0,150" size="340,30" font="Regular;24" halign="center" valign="center" />
		<ePixmap pixmap="%s" position="340,80" size="100,100"/>
    	</screen>""" % ( resolveFilename(SCOPE_PLUGINS, "SystemPlugins/DisplaySkin/g3icon_displayskin.png" ))

    def __init__(self, session):
        Screen.__init__(self, session)
        self["aboutActions"] = ActionMap(["ShortcutActions", "WizardActions", "InfobarEPGActions"],
        {
            "red": self.exit,
            "back": self.exit,
            "ok": self.exit,
        }, -1)
        self["version"] = StaticText(_("Display Skin\n") + 'Version 5.0')
        self["author"] = StaticText(_("by") + ' jogi29')
        self["key_red"] = StaticText(_("Close"))
        self["red"] = Pixmap()
        self.onLayoutFinish.append(self.setWindowTitle)

    def setWindowTitle(self):
        self.setTitle(_("About Display Skin"))

    def exit(self):
        self.close()
