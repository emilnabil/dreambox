#!/usr/bin/env python
# -*- coding: iso-8859-1 -*-
from Components.config import config, configfile, ConfigSubsection, ConfigText, ConfigBoolean, ConfigInteger, ConfigSelection, getConfigListEntry
from Components.ConfigList import ConfigListScreen, ConfigList
from Components.config import KEY_OK, KEY_NUMBERS
from Plugins.Plugin import PluginDescriptor
import UserScripts
from os import path as os_path
from os import mkdir as os_mkdir
from os import rmdir as os_rmdir
from os import environ as os_environ
import gettext
from Components.Harddisk import HarddiskManager as HarddiskManager
from Components.Harddisk import BlockDevice as BlockDevice

userscripts_plugindir="/usr/lib/enigma2/python/Plugins/Extensions/UserScripts" 

os_environ['LANGUAGE']='en'
userscripts_language='en'
REDC =  '\033[31m'                
ENDC = '\033[m'                   
                                    
def cprint(text):                       
        print REDC+text+ENDC  

if os_path.exists("/etc/enigma2/settings") == True:
   f = open("/etc/enigma2/settings")
   line = f.readline()
   while (line):
	line = f.readline().replace("\n","")
	sp = line.split("=")
	if (sp[0] == "config.osd.language"):
	   sp2 = sp[1].split("_")
           userscripts_language = sp2[0]
           if os_path.exists("%s/locale/%s" % (userscripts_plugindir, userscripts_language)) == True:
              os_environ["LANGUAGE"] = sp[1]
           else:
              os_environ['LANGUAGE']='en'
   f.close

_=gettext.Catalog('userscripts', '%s/locale' % userscripts_plugindir).gettext

yes_no_descriptions = {False: _("no"), True: _("yes")}

config.plugins.userscripts = ConfigSubsection()                                                                                 
userscript_inactivity_options = []
userscript_inactivity_options.append(( "standby",_("Standby") ))
userscript_inactivity_options.append(( "idlemode",_("Idle Mode") ))
config.usage.inactivity_action = ConfigSelection(default = "standby", choices = userscript_inactivity_options)
config.plugins.userscripts.confirm = ConfigBoolean(default = False, descriptions=yes_no_descriptions)
config.plugins.userscripts.scriptsave = ConfigBoolean(default = False, descriptions=yes_no_descriptions)
userscriptlist_options = []
userscriptlist_options.append(( "none",_("none") ))
userscriptlist_options.append(( "execute",_("Execute") ))
userscriptlist_options.append(( "install",_("Install") ))
userscriptlist_options.append(( "both",_("Execute")+" & "+_("Install") ))
config.plugins.userscripts.list = ConfigSelection(default = "none", choices = userscriptlist_options)
userscriptshow_options = []
userscriptshow_options.append(( "plugin",_("Pluginlist") ))
userscriptshow_options.append(( "extension",_("Extension") ))
userscriptshow_options.append(( "both",_("Pluginlist")+" & "+_("Extension") ))
config.plugins.userscripts.show = ConfigSelection(default = "both", choices = userscriptshow_options)
config.plugins.userscripts.startupdelay = ConfigInteger(default = 2, limits = (0, 60))
config.plugins.userscripts.sdcard = ConfigBoolean(default = False, descriptions=yes_no_descriptions)

blockDeviceEvenetori=HarddiskManager.blockDeviceEvent

def setit(val):
    val.pop() 
    val.append(0)

def UserScripts_blockDeviceEvent(self, data):
	action = data.get('ACTION')
	devname = data.get('DEVNAME')
	devpath = data.get('DEVPATH')
	devtype = data.get('DEVTYPE')
	if not (action and devname and devpath and devtype):
		return
	blkdev = BlockDevice(devname)
#	replacement for if __isBlacklisted(data):
	major = int(data.get('MAJOR', '0'))                             
	minor = int(data.get('MINOR', '0'))                             
	name = blkdev.name().rstrip('0123456789')  
        if config.plugins.userscripts.sdcard.value: 	
		f=open("/proc/stb/info/model")         
		boxtype=f.read()               
		f.close()                        
		boxtype=boxtype.replace("\n","").replace("\l","")
	        if (major == 179): 	
			# mmcblk only blocked if internal Flash
			if boxtype == "dm900" or boxtype == "dm920":               
	        		if (minor > 7):                     
					cprint("[USERSCRIPTS] ignoring event for %s (blacklisted)" % devpath)
	        			return      
			if boxtype == "one":               
	        		if (minor < 97):                     
					cprint("[USERSCRIPTS] ignoring event for %s (blacklisted)" % devpath)
	        			return       
			if boxtype == "dm7080":               
				if (minor < 17):
					cprint("[USERSCRIPTS] ignoring event for %s (blacklisted)" % devpath)
	        			return
		else:                              
			if name in ['zram'] or major in (1, 7, 9, 31, 179): # ram, loop, md, mtdblock, mmcblk
				cprint("[USERSCRIPTS] ignoring event for %s (blacklisted)" % devpath)
				return
	else: 	# normal blocking behaviour
		if name in ['zram'] or major in (1, 7, 9, 31, 179): # ram, loop, md, mtdblock, mmcblk
			cprint("[USERSCRIPTS] ignoring event for %s (blacklisted)" % devpath)
			return

	if action in ("add", "change"):
		#enable PVR features when a internal harddisc is detected
		device = blkdev.name()
		physdev = blkdev.sysfsPath('device', physdev=True)[4:]
		description = self.getUserfriendlyDeviceName(device, physdev)
		if description.startswith(_("SATA")) and config.misc.recording_allowed.value == False:
			config.misc.recording_allowed.value = True
			config.misc.recording_allowed.save()
			configfile.save()

	# dirty Hack to be able to call private Methods from original class
	if action == "add":
		HarddiskManager._HarddiskManager__addHotplugDevice(self,blkdev, data)
	elif action == "change":
		HarddiskManager._HarddiskManager__changeHotplugPartition(self,blkdev, data)
	elif action == "remove":
		HarddiskManager._HarddiskManager__removeHotplugPartition(self,blkdev, data)

# rename on startup
HarddiskManager.blockDeviceEvent=UserScripts_blockDeviceEvent

def main(session,**kwargs):
	if not os_path.exists("%s/UserScripts.pyo" % userscripts_plugindir):
		reload(UserScripts)
    	session.open(UserScripts.UserScriptsPlugin)

def autostart(reason,**kwargs):
    if kwargs.has_key("session") and reason == 0:                               
        session = kwargs["session"]                                             
	cprint("[USERSCRIPTS] autostart")
	try:
		if config.plugins.userscripts.sdcard.value:
			if not os_path.exists("/media/sdcard"):
				os_mkdir("/media/sdcard")
			if not os_path.exists("/media/hdd"):
				os_mkdir("/media/hdd")
		else:
			if os_path.exists("/media/sdcard"):
				os_rmdir("/media/sdcard")
	except:
		pass
	if not os_path.exists("%s/UserScripts.pyo" % userscripts_plugindir):
		reload(UserScripts)
        session.open(UserScripts.UserScriptsStartup)       

def Plugins(**kwargs):
    if config.plugins.userscripts.show.value=="plugin":
	    return [PluginDescriptor(where = [PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc = autostart),
	    	    PluginDescriptor(name=_("User Scripts"), description=_("OoZooN's User Script Plugin"), where = PluginDescriptor.WHERE_PLUGINMENU, icon="userscripts.png", fnc=main)]
    elif config.plugins.userscripts.show.value=="extension":
	    return [PluginDescriptor(where = [PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc = autostart),
	            PluginDescriptor(name=_("User Scripts"), description=_("OoZooN's User Script Plugin"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, icon="userscripts.png", fnc=main)]
    elif config.plugins.userscripts.show.value=="both":
	    return [PluginDescriptor(where = [PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc = autostart),
	            PluginDescriptor(name=_("User Scripts"), description=_("OoZooN's User Script Plugin"), where = PluginDescriptor.WHERE_PLUGINMENU, icon="userscripts.png", fnc=main),
		    PluginDescriptor(name=_("User Scripts"), description=_("OoZooN's User Script Plugin"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, icon="userscripts.png", fnc=main)]

