#!/usr/bin/python
# -*- coding: utf-8 -*-

__version__ = "1.1"
__date__ = "2018.09.11"
__branch__ = ""
__revision__ = "2205"
__build_version__ = "2.7.12 (v2.7.12:d33e0cf91556, Jun 27 2016, 15:19:22) [MSC v.1500 32 bit (Intel)]"
__build_platform__ = "win32"
