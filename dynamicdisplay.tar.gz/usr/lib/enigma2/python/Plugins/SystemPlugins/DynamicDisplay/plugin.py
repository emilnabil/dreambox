# -*- coding: utf-8 -*-
# Dynamic Display
#
# Coded by dre (c) 2023
# Support: board.dreamboxtools.de
# E-Mail: dre@dreamboxtools.de
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Property.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license, get my approval and inform me about the modifications by mail.

from preview import PreviewScreen
from Components.ActionMap import HelpableActionMap
from Components.ConfigList import ConfigListScreen
from Components.config import config, ConfigOnOff, ConfigSubsection, ConfigSelection, ConfigInteger, getConfigListEntry, NoSave, ConfigText, ConfigNumber, ConfigSubList, ConfigSubDict, configfile, ConfigSlider
from Components.Label import Label
from Components.Pixmap import Pixmap
from Screens.HelpMenu import HelpableScreen
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.SimpleSummary import SimpleSummary
from Screens.Standby import TryQuitMainloop
from Plugins.Plugin import PluginDescriptor
from Tools.Directories import resolveFilename, fileExists, SCOPE_CURRENT_SKIN, pathExists, SCOPE_CONFIG
from Tools.BoundFunction import boundFunction
from enigma import eTimer, getDesktop, quitMainloop
from os import listdir as os_listdir, walk as os_walk
from skin import readSkin, SkinError
from sys import stdout
from traceback import print_exc
import xml.etree.cElementTree as Tree
import re

from . import _


isMerlin = True

try:
	from merlin.emerlin import eMerlin
except:
	isMerlin = False

config.plugins.dynamicdisplay = ConfigSubsection()
config.plugins.dynamicdisplay.activate = ConfigOnOff(default=False)
#config.plugins.dynamicdisplay.mode = ConfigSelection(default="off", choices= [("off", _("off")),("overwrite", _("Overwrite")), ("add", _("Add only"))])
config.plugins.dynamicdisplay.addsummary = ConfigOnOff(default=False)
config.plugins.dynamicdisplay.infobar = ConfigOnOff(default=False)
config.plugins.dynamicdisplay.movieplayer = ConfigOnOff(default=False)
config.plugins.dynamicdisplay.standby = ConfigOnOff(default=False)
config.plugins.dynamicdisplay.interval = ConfigNumber(3)
config.plugins.dynamicdisplay.skins = ConfigSubDict()
config.plugins.dynamicdisplay.count = ConfigInteger(0)

# get the skin's name
def getSkinName():
	activeskinconfig = config.skin.primary_skin.value
	skindata = activeskinconfig.split("/")
	skinname="default"
	if len(skindata) == 2:
		skinname = skindata[0]
	
	skinname = re.sub('[^a-zA-Z0-9]', '_', skinname)
	return skinname

# init element in ConfigSubList
def initScreenConfig(skin):
	s = ConfigSubsection()
	s.name = ConfigText(default="")
	s.active = ConfigOnOff(default=False)
	
	config.plugins.dynamicdisplay.skins[skin].screens.append(s)
	return s

# init ConfigSubList for current active skin
def initConfig(skin):
	count = config.plugins.dynamicdisplay.skins[skin].count.value
	config.plugins.dynamicdisplay.skins[skin].screens = ConfigSubList()
	if count != 0:
		i = 0
		while i < count:
			initScreenConfig(skin)
			i += 1

# read all skins
def getAllSkins():
	skindirs = []
	for root, dirs, files in os_walk('/usr/share/enigma2'):
		# don't consider skin.xml in 'root' directory
		if root == '/usr/share/enigma2':
			continue
		if 'skin.xml' in files:
			slashpos = root.rfind('/')
			if slashpos != -1:
				modifieddir = root[slashpos+1:]
			modifieddir = re.sub('[^a-zA-Z0-9]', '_', modifieddir)
			skindirs.append(modifieddir)
	return skindirs

# init ConfigSubDict for all skins. This is a must to not lose configuration on skin change
def initSkinConfig():
	skins = getAllSkins()
	
	for skinname in skins:	
		config.plugins.dynamicdisplay.skins["%s" %(skinname)] = ConfigSubsection()
		config.plugins.dynamicdisplay.skins["%s" %(skinname)].count = ConfigInteger(0)
	
		initConfig(skinname)

# init the config - very important ;-)
initSkinConfig()

# the global variables
baseInfoBarSummarySupportCreateSummary = None
baseInfoBarMoviePlayerSummarySupportCreateSummary = None
baseStandbyCreateSummary = None
baseGenericCreateSummary = None
baseExecBegin = None
baseExecEnd = None
baseDoInstantiateDialog = None
global_session = None

# overwrite Session functions with our own
def DynamicDisplay_Session():
	global baseExecBegin
	global baseExecEnd
	global baseDoInstantiateDialog
	
	if baseExecBegin is None:
		baseExecBegin = global_session.execBegin

	if baseExecEnd is None:
		baseExecEnd = global_session.execEnd
		
	if baseDoInstantiateDialog is None:
		baseDoInstantiateDialog = global_session.doInstantiateDialog
		
	global_session.changeSummary = changeSummary
	global_session.summarytimer = None
	global_session.summaryScreenTimerDict = {}
		
	global_session.execBegin = DynamicDisplay_ExecBegin
	global_session.execEnd = DynamicDisplay_ExecEnd
	global_session.doInstantiateDialog = DynamicDisplay_DoInstantiateDialog

# our own execBegin considering plugin settings
def DynamicDisplay_ExecBegin(first=True, do_show=True):
	self = global_session
	
	self.summarytimer = None

	if config.plugins.dynamicdisplay.activate.value:	
		screenclass = self.current_dialog.__class__.__name__
		assert not self.in_exec
		self.in_exec = True
		c = self.current_dialog
		self.currentsummary = 0
		self.summarytimer = eTimer()
		self.summarytimer_conn = self.summarytimer.timeout.connect(boundFunction(boundFunction(changeSummary, self), c))
					
		# when this is an execbegin after a execend of a "higher" dialog,
		# popSummary already did the right thing.
		if first:
			self.pushSummary()
			
			summary = c.createSummary()
			if summary is None:
				# use our createSummary for all screens except for InfoBar and MoviePlayer
				if screenclass not in ("InfoBar", "MoviePlayer", "Standby"):
					# might not be necessary but also shouldn't hurt
					self.current_dialog.createSummary = DynamicDisplay_CreateSummary
					# it's important to call the function to actually get the summary (or SimpleSummary)
					summary = DynamicDisplay_CreateSummary(c)
			
			# if screen provided a list of summaries we have to instantiate multiple dialogs
			if isinstance(summary, list):
				# only if there's more then one element in the list we have the required data
				if len(summary) > 1 and isinstance(summary[1], list):
					for s in summary[1]:
						# instantiate the generic summary dialog
						x = self.instantiateSummaryDialog(summary[0], c, summaryskin=s)
						if x:
							# and add it to summaries of screen
							c.addSummary(x)
					
					self.summary = c.summaries[0]
					self.summary.neverAnimate()
					self.summary.show()
					
				# only if we have more then one summary a timer must be started
				if len(summary)>1:
					# this is a safety net in case there should be more than one summary but plugin is not installed...this is actually not really likely but better safe than sorry
					try:
						duration = config.plugins.dynamicdisplay.interval.value
						# screen has duration defined
						if len(summary)>2 and isinstance(summary[2], list):
							duration = int(summary[2][0])
						self.summarytimer.startLongTimer(duration)
					except:
						self.summarytimer = None
				# else we just show the summary
				else:
					self.summarytimer = None

			# screen provided a single summary
			else:
				self.summarytimer = None
				if summary is not None:
					self.summary = self.instantiateSummaryDialog(summary, c)

					if self.summary:
						self.summary.neverAnimate()
						self.summary.show()
						c.addSummary(self.summary)
		else:
			# ensure timer is restarted when screen is accessed for a second time (e.g. InfoBar)
			if len(c.summaries)>1:
				# this is a safety net in case there should be more than one summary but plugin is not installed...this is actually not really likely but better safe than sorry
				try:
					duration = config.plugins.dynamicdisplay.interval.value
					if len(global_session.summaryScreenTimerDict.get(screenclass, [])):
						timerList = global_session.summaryScreenTimerDict.get(screenclass, [])
						duration = int(timerList[self.currentsummary])
					self.summarytimer.startLongTimer(duration)
				except:
					self.summarytimer = None
			else:
				self.summarytimer = None

		c.saveKeyboardMode()
		c.enable(do_show) # we must pass the "do_show" boolean to enable because "show" also can be called from within the enable function
		c.execBegin()

		# when execBegin opened a new dialog, don't bother showing the old one.
		if c == self.current_dialog and do_show:
			c.show()
	# use the standard execBegin when plugin is not active
	else:
		baseExecBegin(first=first, do_show=do_show)

# our own execEnd considering plugin settings
def DynamicDisplay_ExecEnd(last=True, is_dialog=False):
	self = global_session
	# only use when plugin is active
	if config.plugins.dynamicdisplay.activate.value:
		assert self.in_exec
		self.in_exec = False
	
		# stop the timer
		if self.summarytimer is not None:
			self.summarytimer.stop()
		self.current_dialog.execEnd()
		self.current_dialog.restoreKeyboardMode()
		if is_dialog:
			self.current_dialog.disable()
		else:
			self.current_dialog.hide()

		if last and self.summary:
			# it's important to process summaries in reverse order else not all would be removed
			for i in range(len(self.current_dialog.summaries)-1, -1, -1):
				self.current_dialog.removeSummary(self.current_dialog.summaries[i])
			# popSummary() must only be called for the currently shown summary
			self.popSummary()
	# use the standard execEnd when plugin is not active
	else:
		baseExecEnd(last=last, is_dialog=is_dialog)

# our own doInstantiateDialog considering plugin settings
def DynamicDisplay_DoInstantiateDialog(screen, arguments, kwargs, desktop):
	self = global_session

	# only use when plugin is active
	if config.plugins.dynamicdisplay.activate.value:
		# create dialog
		z = None
		dlg = None
		summaryskinname = None
		if "zPosition" in kwargs:
			z = kwargs["zPosition"]
			del kwargs["zPosition"]
		if "summaryskin" in kwargs:
			summaryskinname = kwargs["summaryskin"]
			del kwargs["summaryskin"]
		try:
			dlg = self.create(screen, arguments, **kwargs)
		except Exception as e:
			print 'EXCEPTION IN DIALOG INIT CODE, ABORTING:'
			print '-'*60
			print_exc(file=stdout)
			if isinstance(e, SkinError):
				print "SKIN ERROR", e
				print "defaulting to standard skin..."
				config.skin.primary_skin.value = "skin.xml"
				config.skin.primary_skin.save()
				configfile.save()
			quitMainloop(5)
			print '-'*60

		if dlg is None:
			return

		# read skin data
		if summaryskinname is not None:
			dlg.skinName = summaryskinname
			print "[DynamicDisplay] - set skinname to", dlg.skinName

		readSkin(dlg, None, dlg.skinName, desktop)

		# create GUI view of this dialog
		assert desktop is not None
		if z != None:
			dlg.setZPosition(z)
		dlg.setDesktop(desktop)
		dlg.applySkin()

		return dlg
	# use the standard execEnd when plugin is not active
	else:
		return baseDoInstantiateDialog(screen, arguments, kwargs, desktop)
	
# change to next summary screen
def changeSummary(self, c):
	# hide the current summary	
	if self.summary is not None:	
		self.summary.hide()
		# reset or increase counter
		if self.currentsummary == len(c.summaries)-1:
			self.currentsummary = 0
		else:
			self.currentsummary+=1
		# set self.summary to current summary
		self.summary = c.summaries[self.currentsummary]
		self.summary.neverAnimate()
		# show the new summary
		self.summary.show()
		# restart the timer
		duration = config.plugins.dynamicdisplay.interval.value
		# if there's a value per screen then we must use it
		screenclass = c.__class__.__name__
		if len(global_session.summaryScreenTimerDict.get(screenclass, [])):
			timerList = global_session.summaryScreenTimerDict.get(screenclass, [])
			duration = int(timerList[self.currentsummary])
		self.summarytimer.startLongTimer(duration)
	else:
		# stop the timer
		if self.summarytimer is not None:
			self.summarytimer.stop()

# mode: add
def DynamicDisplay_Generic_createSummary():
	global baseGenericCreateSummary
	
	from Components.GUISkin import GUISkin
	if baseGenericCreateSummary is None:
		baseGenericCreateSummary = GUISkin.createSummary
		
	GUISkin.createSummary = DynamicDisplay_CreateSummary

# infobar overwrite
def DynamicDisplay_InfoBarSummarySupport_createSummary():
	global baseInfoBarSummarySupportCreateSummary
	
	from Screens.InfoBarGenerics import InfoBarSummarySupport
	if baseInfoBarSummarySupportCreateSummary is None:
		baseInfoBarSummarySupportCreateSummary = InfoBarSummarySupport.createSummary
		
	InfoBarSummarySupport.createSummary = DynamicDisplay_CreateSummary

# movieplayer overwrite
def DynamicDisplay_InfoBarMoviePlayerSummarySupport_createSummary():
	global baseInfoBarMoviePlayerSummarySupportCreateSummary
	
	from Screens.InfoBarGenerics import InfoBarMoviePlayerSummarySupport
	if baseInfoBarMoviePlayerSummarySupportCreateSummary is None:
		baseInfoBarMoviePlayerSummarySupportCreateSummary = InfoBarMoviePlayerSummarySupport.createSummary
		
	InfoBarMoviePlayerSummarySupport.createSummary = DynamicDisplay_CreateSummary

# standby overwrite
def DynamicDisplay_Standby_createSummary():
	global baseStandbyCreateSummary
	
	from Screens.Standby import Standby
	if baseStandbyCreateSummary is None:
		baseStandbyCreateSummary = Standby.createSummary
		
	Standby.createSummary = DynamicDisplay_CreateSummary

# our own createSummary considering plugin settings	
def DynamicDisplay_CreateSummary(self=None):
	screenclass = self.__class__.__name__
	print "[DynamicDisplay] - use the following name for xml-file to provide your own summaries: ", screenclass
	if config.plugins.dynamicdisplay.activate.value and ((screenclass == 'InfoBar' and config.plugins.dynamicdisplay.infobar.value) or (screenclass == 'MoviePlayer' and config.plugins.dynamicdisplay.movieplayer.value) or (screenclass == 'Standby' and config.plugins.dynamicdisplay.standby.value) or (screenclass not in ('InfoBar', 'MoviePlayer', 'Standby') and config.plugins.dynamicdisplay.addsummary.value)):
		print "[DynamicDisplay] - Getting summaries for ", screenclass
		skinname = getSkinName()
		count = 0
		if config.plugins.dynamicdisplay.skins.get("%s" %(skinname)) is not None:
			count = config.plugins.dynamicdisplay.skins["%s" %(skinname)].count.value
		summaryScreenList = []
		summaryScreenTimerList = []
		if count != 0:
			for i in range(0, count):
				if config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].name.value == screenclass and config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].active.value:
					summaryfile = None
					if fileExists("%ssummaries/%s.xml" %(resolveFilename(SCOPE_CURRENT_SKIN), config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].name.value)):
						summaryfile = "%ssummaries/%s.xml" %(resolveFilename(SCOPE_CURRENT_SKIN), config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].name.value)
					if fileExists("%sDynamicDisplay/%s/summaries/%s.xml" %(resolveFilename(SCOPE_CONFIG), skinname, config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].name.value)):
						summaryfile = "%sDynamicDisplay/%s/summaries/%s.xml" %(resolveFilename(SCOPE_CONFIG), skinname, config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].name.value)
					if summaryfile is not None:
						xmlFile = Tree.ElementTree(file=summaryfile)
						root=xmlFile.getroot()
						for screen in root.findall('.//screen[@name][@id="%d"][@active="1"]' %(getDesktop(1).getStyleID())):
							summaryScreenList.append(screen.get('name'))
							summaryScreenTimerList.append(screen.get('duration', config.plugins.dynamicdisplay.interval.value))
						break
		if len(summaryScreenList):
			global_session.summaryScreenTimerDict[screenclass] = summaryScreenTimerList
			from genericSummary import GenericSummaryScreen
			# this is a hack...element 0 is the screen and element 1 are the different skins
			return [GenericSummaryScreen, summaryScreenList]
		else:
			if screenclass == 'InfoBar':
				return baseInfoBarSummarySupportCreateSummary(self)
			elif screenclass == 'MoviePlayer':
				return baseInfoBarMoviePlayerSummarySupportCreateSummary(self)
			elif screenclass == 'Standby':
				return baseStandbyCreateSummary(self)
			else:
				return baseGenericCreateSummary(self) or SimpleSummary
	else:
		print "[DynamicDisplay] - Plugin is not activated or disabled for this screen"
		if screenclass == 'InfoBar':
			return baseInfoBarSummarySupportCreateSummary(self)
		elif screenclass == 'MoviePlayer':
			return baseInfoBarMoviePlayerSummarySupportCreateSummary(self)
		elif screenclass == 'Standby':
			return baseStandbyCreateSummary(self)
		else:
			return baseGenericCreateSummary(self) or SimpleSummary

# load skins
def loadSkins(reason, **kwargs):
	if reason == 0 and kwargs.has_key("session"):
		session = kwargs['session']
		global global_session
		global_session = kwargs['session']
		
		from skin import SkinError, loadSkin
		
		skinname = getSkinName()

		# read summaries from config
		count = 0
		if config.plugins.dynamicdisplay.skins.get("%s" %(skinname)) is not None:
			count = config.plugins.dynamicdisplay.skins["%s" %(skinname)].count.value
		summariesdir = "%ssummaries" %(resolveFilename(SCOPE_CURRENT_SKIN))
		usersummariesdir = "%sDynamicDisplay/%s/summaries" %(resolveFilename(SCOPE_CONFIG), skinname)
		if count != 0:
			for i in range(0, count):
				if config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].active.value:
					useUserDir = False
					if fileExists("%s/%s.xml" %(usersummariesdir, config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].name.value)):
						useUserDir = True
					if fileExists("%s/%s.xml" %(summariesdir, config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].name.value)) or useUserDir:
						# load skin
						try:
							print ("loading summaries for %s" %(config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].name.value))
							if useUserDir:
								loadSkin("%s/%s.xml" %(usersummariesdir, config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].name.value), "")
							else:
								loadSkin("%s/%s.xml" %(summariesdir, config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].name.value), "")
						except (SkinError, IOError, AssertionError) as err:
							print("not loading summaries for %s...: " %(config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].name.value), err)

# overwrite functions							
def overwriteFunctions(reason, **kwargs):
	if "session" in kwargs:
		session = kwargs["session"]
		global global_session
		global_session = session
		
		try:
			print "[DynamicDisplay]: Trying to overwrite infobar createSummary()"
			DynamicDisplay_InfoBarSummarySupport_createSummary()
		except:
			print "[DynamicDisplay]: Could not overwrite infbar createSummary()"
			pass

		try:
			print "[DynamicDisplay]: Trying to overwrite movieplayer createSummary()"
			DynamicDisplay_InfoBarMoviePlayerSummarySupport_createSummary()
		except:
			print "[DynamicDisplay]: Could not overwrite movieplayer createSummary()"
			pass

		try:
			print "[DynamicDisplay]: Trying to overwrite standby createSummary()"
			DynamicDisplay_Standby_createSummary()
		except:
			print "[DynamicDisplay]: Could not overwrite standby createSummary()"
			pass

		try:
			print "[DynamicDisplay]: Trying to overwrite generic createSummary()"
			DynamicDisplay_Generic_createSummary()
		except:
			print "[DynamicDisplay]: Could not overwrite generic createSummary()"
			pass
		
		try:
			print "[DynamicDisplay]: Trying to overwrite Session functions"
			DynamicDisplay_Session()
		except:
			print "[DynamicDisplay]: Could not overwrite Session functions"
			pass

# open the plugin settings
def main(session, **kwargs):
	session.open(DynamicDisplay)

# show plugin entry in Merlin menu	
def startSetup(menuid):
	if (menuid != "merlin" and isMerlin) or (menuid != "osd_video_audio" and not isMerlin): # show setup only in system level menu
		return []
	return [(_("Dynamic Display"), main, "DynamicDisplay", 66)]
				
def Plugins(**kwargs):
	list = []
	list.append(PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc = loadSkins))
	list.append(PluginDescriptor(where = PluginDescriptor.WHERE_SESSIONSTART, fnc = overwriteFunctions))
	list.append(PluginDescriptor(name=_("Dynamic Display"), description=_("Settings for Dynamic Display"),where = PluginDescriptor.WHERE_MENU, fnc=startSetup, icon="DynamicDisplay.svg"))
	return list
	
class DynamicDisplay(Screen, HelpableScreen, ConfigListScreen):
	skin = """
		<screen  size="1200,925" position="center,100" title="Dynamic Display">
			<widget name="config" position="10,10" size="1180,680" scrollbarMode="showOnDemand" />
			<widget name="Help" position="10,730" size="1180,100" zPosition="1" font="Regular;25" halign="center" valign="top" backgroundColor="#9f1313" transparent="0" />
		    <widget name="ButtonRed" pixmap="skin_default/buttons/red.png" position="20,895" size="225,3" alphatest="on" scale="width" />
    		<widget name="ButtonGreen" pixmap="skin_default/buttons/green.png" position="265,895" size="225,3" alphatest="on" scale="width" />
	    	<widget name="ButtonYellow" pixmap="skin_default/buttons/yellow.png" position="510,895" size="225,3" alphatest="on" scale="width" />
	     	<widget name="ButtonBlue" pixmap="skin_default/buttons/blue.png" position="755,895" size="225,3" alphatest="on" scale="width" />
	     	<widget name="ButtonOk" font="Regular;27" position="1000,895" size="60,3" transparent="0" valign="center" halign="center" backgroundColor="#787878" />
	    	<widget name="ButtonRedText" position="20,850" size="225,40" zPosition="1" font="Regular;27" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" />
	    	<widget name="ButtonGreenText" position="265,850" size="225,40" zPosition="1" font="Regular;27" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" />
    		<widget name="ButtonYellowText" position="510,850" size="225,40" zPosition="1" font="Regular;27" halign="center" valign="center" backgroundColor="#a08500" transparent="1" />
	    	<widget name="ButtonBlueText" position="755,850" size="225,40" zPosition="1" font="Regular;27" halign="center" valign="center" backgroundColor="#18188b" transparent="1" />
	    	<widget name="ButtonOkText" font="Regular;27" position="1000,850" size="60,40" transparent="1" valign="center" halign="center" backgroundColor="#787878" />
		</screen>
	"""
	
	def __init__(self, session):
		self.session = session
		Screen.__init__(self, session)
		HelpableScreen.__init__(self)
		
		self["OkCancelActions"] = HelpableActionMap(self, "OkCancelActions",
			{
				"ok":		(self.configSummaryScreen,_("Open screen configuration")),
				"cancel":	(self.keyCancel, _("Close without saving")),
			}, -1)

		self["ColorActions"] = HelpableActionMap(self, "ColorActions",
			{
				"green":	(self.keySave, _("Close and save")),
				"red":		(self.keyCancel, _("Close without saving")),
			}, -1)
			
		self["ButtonRed"] = Pixmap()
		self["ButtonRedText"] = Label(_("Cancel"))		
		self["ButtonGreen"] = Pixmap()
		self["ButtonGreenText"] = Label(_("Save"))
		self["ButtonYellow"] = Pixmap()
		self["ButtonYellowText"] = Label()
		self["ButtonBlue"] = Pixmap()
		self["ButtonBlueText"] = Label()
		self["ButtonOk"] = Label()
		self["ButtonOk"].hide()
		self["ButtonOkText"] = Label("OK")
		self["ButtonOkText"].hide()
		self["Help"] = Label()
			
		self.list = []
		
		self.screenConfigChanged = False

		ConfigListScreen.__init__(self, self.list)
		
		self.onShown.append(self.readSummaries)
		self["config"].onSelectionChanged.append(self.updateHelp)
		self.onShown.append(self.setWindowTitle)
		
	def setWindowTitle(self):
		self.setTitle(_("Dynamic Display - Configuration"))

	def keyLeft(self):
		ConfigListScreen.keyLeft(self)
		self.onKeyChange()

	def keyRight(self):
		ConfigListScreen.keyRight(self)
		self.onKeyChange()

	def onKeyChange(self):
		cur = self["config"].getCurrent()
		if cur and cur[1] == config.plugins.dynamicdisplay.activate:
			self.readSummaries()

	def updateHelp(self):
		cur = self["config"].getCurrent()
		if cur and len(cur) == 3:
			self["Help"].setText(cur[2])
		else:
			self["Help"].setText("")
			
		if self["config"].getCurrentIndex() > 7:
			self["ButtonOk"].show()
			self["ButtonOkText"].show()
		else:
			self["ButtonOk"].hide()
			self["ButtonOkText"].hide()

	def configSummaryScreen(self):
		cur = self["config"].getCurrent()
		
		if cur is not None:
			if cur[0] not in (_("Activate Dynamic Display"), _("Display Change Interval")):
				self.session.openWithCallback(self.setRestart, DisplayScreenSettings, cur[0])

	def setRestart(self, restartNeeded=False):
		if restartNeeded:
			self.screenConfigChanged = True
		else:
			if not self.screenConfigChanged:
				self.screenConfigChanged = restartNeeded

	def readSummaries(self):
		self.list = []

		self.list.append(getConfigListEntry(_("Activate Dynamic Display"), config.plugins.dynamicdisplay.activate, _("Activate to use features of the plugin")))
		if config.plugins.dynamicdisplay.activate.value:
			self.list.append(getConfigListEntry(_("Change display screen after (in seconds)"), config.plugins.dynamicdisplay.interval, _("Seconds between change of display screen when more than one display screen is defined. This is the default value. Individual values can be defined per screen by adding attribute duration in screen definition.")))
			self.list.append(getConfigListEntry(_("Settings for Main Display Screens"),))
			self.list.append(getConfigListEntry(_("InfoBar"), config.plugins.dynamicdisplay.infobar, _("Replace display screen for InfoBar")))
			self.list.append(getConfigListEntry(_("MoviePlayer"), config.plugins.dynamicdisplay.movieplayer, _("Replace display screen for MoviePlayer")))
			self.list.append(getConfigListEntry(_("Standby"), config.plugins.dynamicdisplay.standby, _("Replace display screen for Standby")))
			self.list.append(getConfigListEntry(_("Settings for other Display Screens"),))
			self.list.append(getConfigListEntry(_("Add Display screen"), config.plugins.dynamicdisplay.addsummary, _("Adds a display screen when none is defined. Requires a skin file for the screen.")))
			self.list.append(getConfigListEntry(_("Available Display Screens"),))
		
			skinname = getSkinName()
			# set directory for current skin
			summariesdir = "%ssummaries" %(resolveFilename(SCOPE_CURRENT_SKIN))
			usersummariesdir = "%sDynamicDisplay/%s/summaries" %(resolveFilename(SCOPE_CONFIG), skinname)
		
			# check if skin provides summaries
			if pathExists(summariesdir):
			
				currentList = []

				# read summaries from config
				count = 0
				if config.plugins.dynamicdisplay.skins.get("%s" %(skinname)) is not None:
					count = config.plugins.dynamicdisplay.skins["%s" %(skinname)].count.value
				if count != 0:
					for i in range(0, count):
						currentList.append(config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].name.value)	
		
				# read summary files
				skinsummaries = os_listdir(summariesdir)
				userskinsummaries = []
				addeduserskins = []
				if pathExists(usersummariesdir):
					userskinsummaries = os_listdir(usersummariesdir)
				for file in skinsummaries + userskinsummaries:
					fileData = file.split(".")
				
					# check for xml file
					if len(fileData) == 2 and fileData[1] == 'xml':
						# add config entry if current summary is not in config
						if fileData[0] not in currentList:
							newEntry = initScreenConfig(skinname)
							newEntry.name.value = fileData[0]
							newEntry.save()
							config.plugins.dynamicdisplay.skins["%s" %(skinname)].count.value += 1
							config.plugins.dynamicdisplay.skins["%s" %(skinname)].count.save()
							config.plugins.dynamicdisplay.skins["%s" %(skinname)].save()
							configfile.save()
						# remove from list if already in config
						else:
							currentList.remove(fileData[0])
			
				# check if there's any entry left in currentList	
				# left over entries are in config but no file could be found
				if len(currentList):
					for removedItem in currentList:
						count =	config.plugins.dynamicdisplay.skins["%s" %(skinname)].count.value
						for i in range(0, count):
							# remove config entry
							if config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].name.value == removedItem:
								config.plugins.dynamicdisplay.skins["%s" %(skinname)].count.value -= 1
								del config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i]
								config.plugins.dynamicdisplay.skins["%s" %(skinname)].count.save()
								config.plugins.dynamicdisplay.skins["%s" %(skinname)].save()
								configfile.save()
								break
		
				# build the entries for the UI
				count = 0
				if config.plugins.dynamicdisplay.skins.get("%s" %(skinname)) is not None:
					count = config.plugins.dynamicdisplay.skins["%s" %(skinname)].count.value
				self.list.append(getConfigListEntry(_("Skin Summaries"),))
				tempList = []
				tempList.append(getConfigListEntry(_("User Skin Summaries"),))
				if count != 0:
				
					for i in range(0, count):
						if "%s.xml" %(config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].name.value) in userskinsummaries:
							if not config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].name.value in addeduserskins:
								tempList.append(getConfigListEntry("%s" %(config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].name.value), config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].active, _("Configure display screens for %s. Push OK to select screens to use.") %(config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].name.value)))
								addeduserskins.append(config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].name.value)
						else:
							self.list.append(getConfigListEntry("%s" %(config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].name.value), config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].active, _("Configure display screens for %s. Push OK to select screens to use.") %(config.plugins.dynamicdisplay.skins["%s" %(skinname)].screens[i].name.value)))
				
				for entry in tempList:
					self.list.append(entry)
		
		self["config"].setList(self.list)				
	
	def keySave(self):
		if self["config"].isChanged() or self.screenConfigChanged:
			self.saveAll()
			self.restartYesNo()
		else:
			self.close()
			
	def keyCancel(self):
		if self.screenConfigChanged:
			self.restartYesNo()
		else:
			self.close()

	def restartYesNo(self):
		restartbox = self.session.openWithCallback(self.restartGUI,MessageBox,_("Changes will only be applied after enigma2 was restarted. Restart now?"), MessageBox.TYPE_YESNO)
		restartbox.setTitle(_("Restart now?"))
		
	def restartGUI(self, answer):
		if answer is True:
			self.session.open(TryQuitMainloop, 3)
		else:
			self.close()
			
class DisplayScreenSettings(Screen, HelpableScreen, ConfigListScreen):
	skin = """
		<screen position="center,100" size="1200,925" title="Display Settings">
			<widget name="config" position="10,10" size="1180,700" scrollbarMode="showOnDemand" />
			<widget name="Help" position="10,730" size="1180,70" zPosition="1" font="Regular;25" halign="center" valign="top" backgroundColor="#9f1313" transparent="0" />
			<widget name="Duration" position="10,800" size="1180,30" zPosition="1" font="Regular;25" halign="center" valign="top" backgroundColor="#9f1313" transparent="0" />
		    <widget name="ButtonRed" pixmap="skin_default/buttons/red.png" position="20,895" size="225,3" alphatest="on" scale="width" />
    		<widget name="ButtonGreen" pixmap="skin_default/buttons/green.png" position="265,895" size="225,3" alphatest="on" scale="width" />
	    	<widget name="ButtonYellow" pixmap="skin_default/buttons/yellow.png" position="510,895" size="225,3" alphatest="on" scale="width" />
	     	<widget name="ButtonBlue" pixmap="skin_default/buttons/blue.png" position="755,895" size="225,3" alphatest="on" scale="width" />
	     	<widget name="ButtonInfo" font="Regular;27" position="1000,895" size="60,3" transparent="0" valign="center" halign="center" backgroundColor="#787878" />
	    	<widget name="ButtonRedText" position="20,850" size="225,40" zPosition="1" font="Regular;27" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" />
	    	<widget name="ButtonGreenText" position="265,850" size="225,40" zPosition="1" font="Regular;27" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" />
    		<widget name="ButtonYellowText" position="510,850" size="225,40" zPosition="1" font="Regular;27" halign="center" valign="center" backgroundColor="#a08500" transparent="1" />
	    	<widget name="ButtonBlueText" position="755,850" size="225,40" zPosition="1" font="Regular;27" halign="center" valign="center" backgroundColor="#18188b" transparent="1" />
	    	<widget name="ButtonInfoText" font="Regular;27" position="1000,850" size="60,40" transparent="1" valign="center" halign="center" backgroundColor="#787878" />
		</screen>
	"""
	
	def __init__(self, session, screenname):
		self.session = session
		self.screenname = screenname
		self.summaryfile = "%ssummaries/%s.xml" %(resolveFilename(SCOPE_CURRENT_SKIN), self.screenname)
		skinname = getSkinName()
		if fileExists("%sDynamicDisplay/%s/summaries/%s.xml" %(resolveFilename(SCOPE_CONFIG), skinname, self.screenname)):
			self.summaryfile = "%sDynamicDisplay/%s/summaries/%s.xml" %(resolveFilename(SCOPE_CONFIG), skinname, self.screenname)
		Screen.__init__(self, session)
		HelpableScreen.__init__(self)
		
		self["OkCancelActions"] = HelpableActionMap(self,"OkCancelActions",
			{
				"ok":		(self.keySave, _("Close and save")),
				"cancel": 	(self.keyCancel, _("Close without saving")),
			}, -1)

		self["ColorActions"] = HelpableActionMap(self,"ColorActions",
			{
				"green":	(self.keySave, _("Close and save")),
				"red":		(self.keyCancel, _("Close without saving")),
			}, -1)
			
		self["ChannelSelectEPGActions"] = HelpableActionMap(self, "ChannelSelectEPGActions",
			{
				"showEPGList":	(self.openPreview, _("Show preview")),
			}, -1)

		self["ButtonRed"] = Pixmap()
		self["ButtonRedText"] = Label(_("Cancel"))		
		self["ButtonGreen"] = Pixmap()
		self["ButtonGreenText"] = Label(_("Save"))
		self["ButtonYellow"] = Pixmap()
		self["ButtonYellowText"] = Label()
		self["ButtonBlue"] = Pixmap()
		self["ButtonBlueText"] = Label()
		self["ButtonInfo"] = Label()
		self["ButtonInfo"].hide()
		self["ButtonInfoText"] = Label("INFO")
		self["ButtonInfoText"].hide()
		self["Help"] = Label()
		self["Duration"] = Label()
		self["Duration"].hide()
			
		self.list = []	
		ConfigListScreen.__init__(self, self.list)
		
		self.onShown.append(self.setScreenTitle)
		
		self.onShown.append(self.getSummaries)
		
		self["config"].onSelectionChanged.append(self.updateHelp)
		self.onShown.append(self.setWindowTitle)
		
	def setWindowTitle(self):
		self.setTitle(_("Dynamic Display - Screen Settings: %s") %(self.screenname))

	def keyLeft(self):
		ConfigListScreen.keyLeft(self)	
		if self["config"].getCurrent()[0] == _("Duration"):
			self["Duration"].setText(_("Current value: %d") %(self["config"].getCurrent()[1].value))
	
	def keyRight(self):
		ConfigListScreen.keyRight(self)
		if self["config"].getCurrent()[0] == _("Duration"):
			self["Duration"].setText(_("Current value: %d") %(self["config"].getCurrent()[1].value))

	def openPreview(self):
		index = self["config"].getCurrentIndex()
		headerIndex = index//3
		newIndex = self["config"]._headers[headerIndex]
		cur = self["config"].list[newIndex]
		if cur is not None:
			self.session.open(PreviewScreen, self.summaryfile, cur[0])
		
	def setScreenTitle(self):
		self.setTitle(self.screenname)

	def getSummaries(self):
		self.list = []
		if fileExists(self.summaryfile):

			xmlFile = Tree.ElementTree(file=self.summaryfile)
			root=xmlFile.getroot()
					
			for screen in root.findall('.//screen[@name][@id="%d"]' %(getDesktop(1).getStyleID())):
				currentscreen = screen.get('name')
				currentstate = screen.get('active')
				if currentstate == '1':
					active=True
				else:
					active=False
				currentEntry = NoSave(ConfigOnOff(default=active))
				
				duration = int(screen.get('duration', 0))
				durationtext = _("Screen will be shown for: ")
				
				currentDuration = NoSave(ConfigSlider(default=duration, increment=1, limits= (0, 15)))
				
				self.list.append(getConfigListEntry(currentscreen,))
				self.list.append(getConfigListEntry(_("Activated"), currentEntry, _("Define whether screen should be used.")))
				self.list.append(getConfigListEntry(_("Duration"), currentDuration, _("By default a screen is shown for the number of seconds defined in the general setting but a deviating duration can be defined per screen. Set to 0 to use default.")))
			
			if len(self.list):
				self["ButtonInfo"].show()
				self["ButtonInfoText"].show()			
			self["config"].setList(self.list)

	def keySave(self):
		if self["config"].isChanged():
			xmlFile = Tree.ElementTree(file=self.summaryfile)
			root=xmlFile.getroot()

			for x in self["config"].list:
				if len(x) > 1:
					if x[0] == _("Activated"):
						for screen in root.findall('.//screen[@name="%s"][@id="%d"]' %(currentscreen, getDesktop(1).getStyleID())):
							if screen.get('active') == '1' and not x[1].value:
								screen.set('active', '0')
							elif screen.get('active') == '0' and x[1].value:
								screen.set('active', '1')
							elif screen.get('active') is None:
								if x[1].value:
									screen.set('active', '1')
								elif not x[1].value:
									screen.set('active', '0')
					elif x[0] == _("Duration"):
						for screen in root.findall('.//screen[@name="%s"][@id="%d"]' %(currentscreen, getDesktop(1).getStyleID())):
							if x[1].value == 0:
								if screen.get('duration') is not None:
									del screen.attrib['duration']
							else:
								if screen.get('duration') != str(x[1].value):
									screen.set('duration', str(x[1].value))
				
				elif len(x) == 1:
					currentscreen = x[0]

			xmlFile.write(self.summaryfile)
			self.close(True)
		else:
			self.close(False)

	def updateHelp(self):
		cur = self["config"].getCurrent()
		if cur and len(cur) == 3:
			self["Help"].setText(cur[2])
		else:
			self["Help"].setText("")
			
		if cur and cur[0] == _("Duration"):
			self["Duration"].setText(_("Current value: %d") %(cur[1].value))
			self["Duration"].show()
		else:
			self["Duration"].hide()

class GenericSummaryScreen:
	def __init__(self, **kwargs):
		self.skinName = kwargs["skinName"]