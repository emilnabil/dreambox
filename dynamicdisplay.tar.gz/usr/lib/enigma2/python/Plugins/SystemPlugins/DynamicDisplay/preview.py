# -*- coding: utf-8 -*-
# Dynamic Display
#
# Coded by dre (c) 2023
# Support: board.dreamboxtools.de
# E-Mail: dre@dreamboxtools.de
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Property.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license, get my approval and inform me about the modifications by mail.

from Components.ActionMap import HelpableActionMap
from Components.Label import Label
from Screens.HelpMenu import HelpableScreen
from Screens.Screen import Screen
from Tools.Directories import fileExists
from enigma import eServiceCenter, getDesktop
import xml.etree.cElementTree as Tree
import re

from . import _

# imports for preview
from Components.Sources.ServiceEvent import ServiceEvent
from Components.Sources.Event import Event

from ServiceReference import ServiceReference

class PreviewScreen(Screen, HelpableScreen):
	skin = """
			<screen name="PreviewScreen" position="center,center" size="700,250" title="Dynamic Display - Preview">
				<widget font="Regular;35" halign="center" position="0,0" render="Label" size="700,155" valign="center" name="info" />
				<widget name="ButtonExit" font="Regular;27" position="320,220" size="60,3" transparent="0" valign="center" halign="center" backgroundColor="#787878" />
				<widget name="ButtonExitText" font="Regular;27" position="320,175" size="60,40" transparent="1" valign="center" halign="center" backgroundColor="#787878" />
			</screen>
			"""
	
	def __init__(self, session, filename, screen, args = None):
		self.session = session
		self.filename = filename
		self.screen = screen
		
		service = session.nav.getCurrentlyPlayingServiceReference()
		session.CurrentService = service
		
		Screen.__init__(self, session)
		HelpableScreen.__init__(self)
		
		self["OkCancelActions"] = HelpableActionMap(self, "OkCancelActions",
		{
			"cancel":	(self.close, _("Close")),
		}, -1)
		
		self["info"] = Label(_("See display for preview of %s") %(self.screen))
		self["ButtonExit"] = Label()
		self["ButtonExitText"] = Label("Exit")
		# only when using onLayoutFinish the picon is actually shown!	
		self["Service"] = ServiceEvent()
		self["ServiceInfo"] = ServiceEvent()
		self["ServiceEvent"] = ServiceEvent()
		self["Event"] = Event()
		
		self.onLayoutFinish.append(self.onCreate)
		self.onShown.append(self.setWindowTitle)
		
	def setWindowTitle(self):
		self.setTitle(_("Dynamic Display - Preview"))

	def createSummary(self):
		return PreviewScreenSummary
		
	def onCreate(self):
		service = self.session.nav.getCurrentlyPlayingServiceReference()
		self.session.CurrentService = service
		# set the service to the currently running channel
		self["Service"].newService(service)
		self["ServiceInfo"].newService(service)
		self["ServiceEvent"].newService(service)
		
		# get the current event
		info = service and eServiceCenter.getInstance().info(service)
		event = info and info.getEvent(service)
		# set the event to the current event of the currently running channel
		self["Event"].newEvent(event)
		
class PreviewScreenSummary(Screen):
	skin = (
	"""	<screen name="PreviewScreenSummary" position="0,0" size="132,64" id="1">
		</screen>""",
	"""	<screen name="PreviewScreenSummary" position="0,0" size="96,64" id="2">
		</screen>""",
	"""	<screen name="PreviewScreenSummary" position="0,0" size="400,240" id="3">
		</screen>""",
	"""	<screen name="PreviewScreenSummary" position="0,0" size="240,80" id="100">
		</screen>"""
		 )
				
	def __init__(self, session, parent):
		self.session = session

		# only when using onLayoutFinish the picon is actually shown!	
		self["Service"] = ServiceEvent()
		self["ServiceInfo"] = ServiceEvent()
		self["ServiceEvent"] = ServiceEvent()
		self["Event"] = Event()
		
	
		skinstring = ""
		if fileExists(parent.filename):
			xmlFile = Tree.ElementTree(file=parent.filename)
			root=xmlFile.getroot()
					
			for screen in root.findall('.//screen[@name="%s"][@id="%d"]' %(parent.screen, getDesktop(1).getStyleID())):
				skinstring =  Tree.tostring(screen)
				break		

		self.skinName = [parent.screen]
		
		# this is a hack because session.CurrentService does not work
		skinstring = re.sub('.*?<widget(.*?)render=\"(Picon|Cover)\"(.*?)>.*?', self.replaceCurrentService, skinstring)
		
		self.skin = skinstring
		
		Screen.__init__(self, session, parent=parent)
		
		self.onLayoutFinish.append(self.onCreate)

	def replaceCurrentService(self, match_obj):
		if match_obj.group(2) is not None:
			if match_obj.group(2).find('session.CurrentService') != -1 or match_obj.group(3).find('session.CurrentService') != -1:
				return match_obj.group().replace('session.CurrentService', 'Service')
		return match_obj.group()

	def onCreate(self):
		service = self.session.nav.getCurrentlyPlayingServiceReference()
		self.session.CurrentService = service
		# set the service to the currently running channel
		self["Service"].newService(service)
		self["ServiceInfo"].newService(service)
		self["ServiceEvent"].newService(service)
		
		# get the current event
		info = service and eServiceCenter.getInstance().info(service)
		event = info and info.getEvent(service)
		# set the event to the current event of the currently running channel
		self["Event"].newEvent(event)