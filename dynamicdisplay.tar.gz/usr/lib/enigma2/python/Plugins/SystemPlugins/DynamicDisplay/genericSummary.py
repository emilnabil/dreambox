# -*- coding: utf-8 -*-
# Dynamic Display
#
# Coded by dre (c) 2023
# Support: board.dreamboxtools.de
# E-Mail: dre@dreamboxtools.de
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Property.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license, get my approval and inform me about the modifications by mail.

from Screens.Screen import Screen

class GenericSummaryScreen(Screen):
	skin = (
		"""<screen active="1" flags="wfNoBorder" id="3" title="parent.title" name="GenericSummaryScreen" position="0,0" size="400,240">
		</screen>""",
		"""<screen active="1" flags="wfNoBorder" id="1" title="parent.title" name="GenericSummaryScreen" position="0,0" size="132,64" >
		</screen>""",
		"""<screen active="1" flags="wfNoBorder" id="2" title="parent.title" name="GenericSummaryScreen" position="0,0" size="96,64" >
		</screen>""",
		"""<screen active="1" flags="wfNoBorder" id="100" title="parent.title" name="GenericSummaryScreen" position="0,0" size="240,80" >
		</screen>""",	
	)
	
	def __init__(self, session, parent):
		print "init GenericSummaryScreen with parent", parent
		Screen.__init__(self, session, parent=parent)
	
	def setSkin(self, skinname):
		self.skinName = skinname
		print "skinName", self.skinName
		print "parent", parent.skinName