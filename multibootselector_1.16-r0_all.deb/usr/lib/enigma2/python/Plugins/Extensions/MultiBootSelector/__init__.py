# -*- coding: utf-8 -*-
PV = "1.16"
PN = "MultiBoot Selector"
PD = "Select a slot to boot from"
