# -*- coing: utf-8 -*-
#
# InfoBarHide Plugin (c) gutemine
#
ibh_version="0.9"
#
from Components.ActionMap import ActionMap
from Components.config import config, configfile, ConfigSubsection, ConfigInteger, ConfigSelection,  ConfigSubList, getConfigListEntry, ConfigYesNo
from Plugins.Plugin import PluginDescriptor
from Components.ConfigList import ConfigListScreen
from Screens.Screen import Screen
from enigma import eTimer, eActionMap
from enigma import getDesktop
from Screens.InfoBarGenerics import InfoBarShowHide, InfoBarMenu   
from Components.Lcd import LCD
from Components.Label import Label 
from Screens.MessageBox import MessageBox

import os

config.plugins.infobar_hide = ConfigSubsection()
config.plugins.infobar_hide.timeout = ConfigSelection(default = "3", choices = [
		("0", _("no timeout")), ("1", "1 " + _("second")), ("2", "2 " + _("seconds")), ("3", "3 " + _("seconds")),
		("4", "4 " + _("seconds")), ("5", "5 " + _("seconds")), ("6", "6 " + _("seconds")), ("7", "7 " + _("seconds")),
		("8", "8 " + _("seconds")), ("9", "9 " + _("seconds")), ("10", "10 " + _("seconds"))])
config.plugins.infobar_hide.oled = ConfigYesNo(default=True)
config.plugins.infobar_hide.toggle = ConfigYesNo(default=False)
config.plugins.infobar_hide.volumetimeout = ConfigSelection(default = "3", choices = [
		("0", _("no timeout")), ("1", "1 " + _("second")), ("2", "2 " + _("seconds")), ("3", "3 " + _("seconds")),
		("4", "4 " + _("seconds")), ("5", "5 " + _("seconds")), ("6", "6 " + _("seconds")), ("7", "7 " + _("seconds")),
		("8", "8 " + _("seconds")), ("9", "9 " + _("seconds")), ("10", "10 " + _("seconds"))])
config.plugins.infobar_hide.mutetimeout = ConfigSelection(default = "0", choices = [
		("0", _("no timeout")), ("1", "1 " + _("second")), ("2", "2 " + _("seconds")), ("3", "3 " + _("seconds")),
		("4", "4 " + _("seconds")), ("5", "5 " + _("seconds")), ("6", "6 " + _("seconds")), ("7", "7 " + _("seconds")),
		("8", "8 " + _("seconds")), ("9", "9 " + _("seconds")), ("10", "10 " + _("seconds"))])

ibh_plugin=_("Info Bar Hide")
ibh_config=ibh_plugin+" "+_("Configuration")

import Components.VolumeControl
VolumeControl_ori_volMute=Components.VolumeControl.VolumeControl.volMute      

def volMuteIBH(self, showMuteSymbol=True, force=False):                    
	VolumeControl_ori_volMute(self,showMuteSymbol,force)
	if self.volctrl.isMuted():    
		print "[InfoBarTimerHide] >>>>>>>>>> volMute is muted"
		if int(config.plugins.infobar_hide.mutetimeout.value) > 0:
			self.muteTimer = eTimer()
			self.muteTimer_con = self.muteTimer.timeout.connect(self.doMute)
			timeout=int(config.plugins.infobar_hide.mutetimeout.value)*1000
			self.muteTimer.start(timeout, True)

def doMuteIBH(self):                    
	print "[InfoBarTimerHide] >>>>>>>>>> volMute hides"
	self.muteDialog.hide() 	

def setVolumeIBH(self, direction):
	print "[InfoBarTimerHide] >>>>>>>>>> setVolume"
	if direction > 0:
		val = config.audio.volume_stepsize.value
		self.volctrl.volumeUp(val, val)
	else:
		val = config.audio.volume_stepsize.value
		self.volctrl.volumeDown(val, val)
	is_muted = self.volctrl.isMuted()
	vol = self.volctrl.getVolume()
	self.volumeDialog.show()
	if is_muted:
		self.volMute() # unmute
	elif not vol:
		self.volMute(False, True) # mute but dont show mute symbol
	if self.volctrl.isMuted():
		self.volumeDialog.setValue(0)
	else:
		self.volumeDialog.setValue(self.volctrl.getVolume())
	self.volSave()
	timeout=int(config.plugins.infobar_hide.volumetimeout.value)*1000
	self.hideVolTimer.start(timeout, True)

def setDiscreteVolumeIBH(self, vol):
	print "[InfoBarTimerHide] >>>>>>>>>> setDiscreteVolume"
	self.volctrl.setVolume(vol, vol)
	is_muted = self.volctrl.isMuted()
	vol = self.volctrl.getVolume()
	self.volumeDialog.show()
	if is_muted or not vol:
		self.volMute()
	if self.volctrl.isMuted():
		self.volumeDialog.setValue(0)
	else:
		self.volumeDialog.setValue(vol)
	self.volSave()
	timeout=int(config.plugins.infobar_hide.volumetimeout.value)*1000
	self.hideVolTimer.start(timeout, True)

# rename on startup
Components.VolumeControl.VolumeControl.volMute=volMuteIBH
Components.VolumeControl.VolumeControl.setVolume=setVolumeIBH
Components.VolumeControl.VolumeControl.setDiscreteVolume=setDiscreteVolumeIBH
Components.VolumeControl.VolumeControl.doMute=doMuteIBH

def InfoBarHide_startHideTimer(self):                                 
	print "[InfoBarTimerHide] >>>>>>>>>> startHideTimer"
	if self._InfoBarShowHide__state == self.STATE_SHOWN and not self._InfoBarShowHide__locked:
		idt = config.plugins.infobar_hide.timeout.index          
		if idt:                                           
			self.DimmingTimer = eTimer()
			self.DimmingTimer.stop()
		        self.steps=idt*10
		        self.dimmed=self.steps
			# set transparency back to original
			f=open("/proc/stb/video/alpha","w")
			f.write("%i" % (config.av.osd_alpha.value))
			f.close()
		idx = config.usage.infobar_timeout.index          
		if idx:                                           
			self.hideTimer.start(idx*1000, True)      
		else:
			idt = config.plugins.infobar_hide.timeout.index          
			if idt:                                           
				self.hideTimer.start(100, True)      

def InfoBarHide_doDimming(self):
	self.dimmed=self.dimmed-1
	self.DimmingTimer.stop()
        if self._InfoBarShowHide__state != self.STATE_HIDDEN:
        	f=open("/proc/stb/video/alpha","w")
        	f.write("%i" % (config.av.osd_alpha.value*self.dimmed/self.steps))
        	f.close()
		if config.plugins.infobar_hide.oled.value and os.path.exists("/proc/stb/lcd/oled_brightness"):        
			c=open("/proc/stb/lcd/oled_brightness","w")
	        	c.write("%i" % (25*config.lcd.bright.value*self.dimmed/self.steps))
			c.close()
                if self.dimmed > 0:
			self.DimmingTimer.start(100, True)
                else:
	     		self.DimmingTimer.stop()
	 		if self._InfoBarShowHide__state == self.STATE_SHOWN:
				self.hide()

def InfoBarHide_unDimming(self):
	self.unDimmingTimer.stop()
	# set transparency back to original
	f=open("/proc/stb/video/alpha","w")
	f.write("%i" % (config.av.osd_alpha.value))
	f.close()

def InfoBarHide__onHide(self):
	print "[InfoBarTimerHide] >>>>>>>>>>> __onHide"
	self._InfoBarShowHide__state = self.STATE_HIDDEN
	idt = config.plugins.infobar_hide.timeout.index          
	if idt:                                           
		self.unDimmingTimer = eTimer()
		self.unDimmingTimer_con = self.unDimmingTimer.timeout.connect(self.unDimming)
		self.unDimmingTimer.start(300, True)
	if config.plugins.infobar_hide.oled.value:
		self.oledDimmingTimer = eTimer()
		self.oledDimmingTimer_con = self.oledDimmingTimer.timeout.connect(self.oledDimming)
		self.oledDimmingTimer.start(300, True)

def InfoBarHide_oledDimming(self):
	if os.path.exists("/proc/stb/lcd/oled_brightness"):        
		c=open("/proc/stb/lcd/oled_brightness","w")
		c.write("%i" % (0))
		c.close()

def doInfoBarHideTimerHide(self):
	print "[InfoBarTimerHide] >>>>>>>>>> doTimerHide"
	self.hideTimer.stop()
	idt = config.plugins.infobar_hide.timeout.index          
	if idt:                                           
			self.DimmingTimer = eTimer()
			self.DimmingTimer_con = self.DimmingTimer.timeout.connect(self.doDimming)
			self.DimmingTimer.start(100, True)
		        self.steps=idt*10
		        self.dimmed=self.steps
			# set transparency back to original
			f=open("/proc/stb/video/alpha","w")
			f.write("%i" % (config.av.osd_alpha.value))
			f.close()
	else:
		if self._InfoBarShowHide__state == self.STATE_SHOWN:
			self.hide()

def InfoBarHide_mainMenuClosed(self, *val):                                         
	print "[InfoBarMenu] >>>>>>>>>> mainMenuClosed"
	if config.plugins.infobar_hide.oled.value:        
		orig=int(config.lcd.bright.value)
		current=0
		if os.path.exists("/proc/stb/lcd/oled_brightness"):
			c=open("/proc/stb/lcd/oled_brightness","r")
			cb=c.readline()
			c.close()
			current=int(cb)/25
		#
		# undimming on every keypress if dimmed
		#
		if current != orig:
			print "[InfoBarHide] undimming OLED"
			ilcd = LCD() 
			ilcd.setBright(orig)
	self.session.infobar = None   

def InfoBarHide_toggleShow(self):                                                   
	print "[InfoBarShow] >>>>>>>>>> toggleShow"
        if self._InfoBarShowHide__state == self.STATE_SHOWN:
	        self.hide()                                     
		print "[InfoBarTimerHide] >>>>>>>>>> stopHideTimer"
                self.hideTimer.stop()
        elif self._InfoBarShowHide__state == self.STATE_HIDDEN:
                self.show() 
                # Thanks Dr.Best !
                if config.plugins.infobar_hide.toggle.value:
			print "[InfoBarTimerHide] >>>>>>>>>> stopHideTimer"
                	self.hideTimer.stop()                    

# rename on startup
InfoBarShowHide.doTimerHide=doInfoBarHideTimerHide
InfoBarShowHide.doDimming=InfoBarHide_doDimming
InfoBarShowHide.unDimming=InfoBarHide_unDimming
InfoBarShowHide.toggleShow=InfoBarHide_toggleShow
InfoBarShowHide._InfoBarShowHide__onHide=InfoBarHide__onHide
InfoBarShowHide.startHideTimer=InfoBarHide_startHideTimer
InfoBarMenu.mainMenuClosed=InfoBarHide_mainMenuClosed
InfoBarMenu.oledDimming=InfoBarHide_oledDimming

sz_w = getDesktop(0).size().width()   

class InfoBarHide(Screen, ConfigListScreen):
	if sz_w == 1920: 
		skin = """
	        <screen position="center,center" size="1200,370" title="Info Bar Hide" >
		<widget backgroundColor="#9f1313" font="Regular;30" halign="center" name="buttonred" position="20,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="280,60" valign="center" />
		<widget backgroundColor="#1f771f" font="Regular;30" halign="center" name="buttongreen" position="315,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="280,60" valign="center" />
		<widget backgroundColor="#a08500" font="Regular;30" halign="center" name="buttonyellow" position="610,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="280,60" valign="center" />
		<widget backgroundColor="#18188b" font="Regular;30" halign="center" name="buttonblue" position="905,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="280,60" valign="center" />
                <eLabel backgroundColor="grey" position="15,80" size="1170,1" />
	    	<widget enableWrapAround="1" name="config" position="20,90" scrollbarMode="showOnDemand" size="1160,270" />
	        </screen>"""
	else:
		skin = """
	        <screen position="center,center" size="820,270"  title="Info Bar Hide" >
		<widget backgroundColor="#9f1313" font="Regular;19" halign="center" name="buttonred" position="15,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center" />
		<widget backgroundColor="#1f771f" font="Regular;19" halign="center" name="buttongreen" position="215,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center" />
		<widget backgroundColor="#a08500" font="Regular;19" halign="center" name="buttonyellow" position="415,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center" />
		<widget backgroundColor="#18188b" font="Regular;19" halign="center" name="buttonblue" position="615,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="190,40" valign="center" />
                <eLabel backgroundColor="grey" position="15,60" size="790,1" />
		<widget name="config" position="10,70" size="800,180" enableWrapAround="1" scrollbarMode="showOnDemand" />
	        </screen>"""

	def __init__(self, session, args = 0):
		Screen.__init__(self, session)
		self.skin=InfoBarHide.skin
		self["buttonred"] = Label(_("Exit"))
		self["buttongreen"] = Label(_("Save"))
		self["buttonyellow"] = Label(_("-"))
		self["buttonblue"] = Label(_("About"))
		self.list=[]
	        self.list.append(getConfigListEntry(_("Infobar timeout")+" "+_("standard").lower(), config.usage.infobar_timeout))
	        self.list.append(getConfigListEntry(_("Infobar timeout")+" "+_("Simple fade").lower(), config.plugins.infobar_hide.timeout))
	        self.list.append(getConfigListEntry(_("Infobar")+"-"+_("manual"), config.plugins.infobar_hide.toggle))
		if os.path.exists("/proc/stb/lcd/oled_brightness"):        
	        	self.list.append(getConfigListEntry(_("Infobar timeout")+" "+_("Simple fade").lower()+" "+_("OLED"), config.plugins.infobar_hide.oled))
	        self.list.append(getConfigListEntry(_("Infobar timeout").replace("Infobar",_("Volume")), config.plugins.infobar_hide.volumetimeout))
	        self.list.append(getConfigListEntry(_("Infobar timeout").replace("Infobar",_("Mute")), config.plugins.infobar_hide.mutetimeout))

	        self.onShown.append(self.setWindowTitle)
	       	ConfigListScreen.__init__(self, self.list)
	        # explizit check on every entry
		self.onChangedEntry = []

		self["setupActions"] = ActionMap([ "SetupActions", "ColorActions" ],
			{
			"green": self.save,
			"ok": self.save,
			"save": self.save,
			"red": self.cancel,
			"blue": self.about,
			"cancel": self.cancel,
       			}, -1)       

	def setWindowTitle(self):
		self.setTitle(ibh_config)

	def save(self):
		for x in self["config"].list:
			x[1].save()
	        self.close(True)

	def cancel(self):
		for x in self["config"].list:
			x[1].cancel()
		self.close(False)

	def about(self):
		self.session.open(MessageBox, ibh_plugin+" "+_("Version")+" "+ibh_version+" "+_("(c) gutemine"),  MessageBox.TYPE_INFO)

def startInfoBarHide(session, **kwargs):
	session.open(InfoBarHide)   

def mainconf(menuid):                        
	if menuid != "osd_video_audio":            
		return [ ]            
	return [(ibh_plugin, startInfoBarHide, "infobarhide", None)]

def autostart(reason,**kwargs):                                                 
    if kwargs.has_key("session") and reason == 0:
       session = kwargs["session"]                      
       session.open(CheckInfoBarHide)     

def Plugins(**kwargs):
    return [PluginDescriptor(where = [PluginDescriptor.WHERE_SESSIONSTART], fnc = autostart),
	    PluginDescriptor(name=ibh_plugin, description=ibh_config, where=PluginDescriptor.WHERE_MENU, fnc=mainconf)]

class CheckInfoBarHide(Screen):
    def __init__(self,session):
   	Screen.__init__(self,session)

	self.session = session
	self.highPrioActionSlot = eActionMap.getInstance().bindAction('', -0x7FFFFFFF, self.keyPressed)

    def keyPressed(self, key, flag):                                          
	if flag == 1 and config.plugins.infobar_hide.oled.value:        
		orig=int(config.lcd.bright.value)
		current=0
		if os.path.exists("/proc/stb/lcd/oled_brightness"):
			c=open("/proc/stb/lcd/oled_brightness","r")
			cb=c.readline()
			c.close()
			current=int(cb)/25
		#
		# undimming on every keypress if dimmed
		#
		if current != orig:
			print "[InfoBarHide] undimming OLED"
			ilcd = LCD() 
			ilcd.setBright(orig)
	return 0
