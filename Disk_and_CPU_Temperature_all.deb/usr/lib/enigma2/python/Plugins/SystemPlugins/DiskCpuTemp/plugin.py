# -*- coding: utf-8 -*-
from __future__ import print_function, division
import os
import sys
import subprocess
import re
import time
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.config import config, ConfigSubsection, ConfigSelection
from enigma import eTimer, getDesktop, gRGB
from Plugins.Plugin import PluginDescriptor

# Add the script folder path to sys.path
plugin_dir = os.path.dirname(os.path.realpath(__file__))
if plugin_dir not in sys.path:
    sys.path.insert(0, plugin_dir)

# Import from our other modules
try:
    from temp_utilities import *
    from ui_screen import *
except ImportError as e:
    print("[DiskCpuTemp] Error importing modules: %s" % str(e))
    # Try to import the functions we need directly if the modules are not found
    # This is a fallback and might not work if the modules are essential
    # You might need to define fallback functions here or handle the error appropriately.

# Global variables
log_file = "/tmp/diskcputemp.log"

# HDD Warning thresholds
HDD_FIRST_WARNING_TEMP = 45
HDD_SECOND_WARNING_TEMP = 50
HDD_FINAL_WARNING_TEMP = 55

# CPU Warning thresholds
CPU_FIRST_WARNING_TEMP = 75
CPU_SECOND_WARNING_TEMP = 80
CPU_FINAL_WARNING_TEMP = 85

# Configuration setup
config.plugins.DiskCpuTemp = ConfigSubsection()
config.plugins.DiskCpuTemp.warning_duration = ConfigSelection(
    choices=[
        ("5000", "5 seconds"),
        ("10000", "10 seconds"),
        ("15000", "15 seconds"),
        ("20000", "20 seconds")
    ],
    default="5000"
)

# Save last chosen skin so it persists after restart
config.plugins.DiskCpuTemp.last_skin = ConfigSelection(
    choices=[
        ("Fhd1", "Fhd1"),
        ("Fhd2", "Fhd2")
    ],
    default="Fhd2"
)

# --------- Version from file ---------
plugin_path = os.path.dirname(os.path.realpath(__file__))
version_file = os.path.join(plugin_path, "version.txt")
plugin_version = "Unknown"
try:
    with open(version_file, "r") as f:
        plugin_version = f.read().strip()
        if not plugin_version:
            plugin_version = "Unknown"
except Exception as e:
    print("[Plugin] Error reading version.txt: %s" % str(e))
    plugin_version = "Unknown"

# Warning system variables
warning_active = False
warning_level = {"CPU": 0, "/dev/sda": 0, "/dev/sdb": 0}
warning_timer = None
warnings_enabled = True  # Global variable to control warning display

def log_message(message):
    try:
        with open(log_file, "a") as f:
            timestamp = time.strftime("%H:%M:%S")
            f.write("[%s] %s\n" % (timestamp, message))
    except:
        pass

def clear_log():
    try:
        with open(log_file, "w") as f:
            f.write("")
        log_message("Log file cleared")
    except:
        pass

# --- Main Screen Class ---
class DiskCpuTempScreen(Screen, UIScreenMethods):
    instance = None

    def __init__(self, session):
        self.session = session

        # detect screen resolution
        desktop_size = getDesktop(0).size()
        width = desktop_size.width()
        height = desktop_size.height()

        # Choose skin based on saved preference (persisted in config)
        try:
            skin_choice = config.plugins.DiskCpuTemp.last_skin.value
        except Exception:
            skin_choice = "Fhd2"

        if skin_choice == "Fhd1":
            skin = self._skin_fhd1()
        else:
            skin = self._skin_fhd2()

        self.skin = skin
        Screen.__init__(self, session)
        DiskCpuTempScreen.instance = self

        # Get warning duration from configuration
        try:
            warning_duration = int(config.plugins.DiskCpuTemp.warning_duration.value)
        except Exception:
            warning_duration = 5000
        log_message("Warning duration set to %d seconds" % (warning_duration / 1000))

        # Initialize header
        self["plugin_name"] = Label("Disk & CPU Temperature by Iet5")
        self["version"] = Label("v" + plugin_version)
        self["warning_bar"] = Label("")  # Initialize warning bar

        # Initialize other widgets
        self["cpu_label"] = Label("CPU Temp: Loading...")
        self["hdd1_label"] = Label("")
        self["hdd2_label"] = Label("")
        self["hdd3_label"] = Label("")
        self["hdd4_label"] = Label("")
        self["update_label"] = Label("Update every 5 Seconds")
        self["settings_label"] = Label("Warning Duration: %d seconds" % (warning_duration / 1000))
        self["settings_hint"] = Label("Press UP/DOWN to change warning duration")
        self["exit_button"] = Label("Exit")
        self["save_button"] = Label("Save")
        self["change_skin_button"] = Label("Change Skin")
        self["stop_warning_button"] = Label("Stop Warning")

        # Action map
        self["actions"] = ActionMap(
            ["SetupActions", "OkCancelActions", "ChannelSelectActions",
             "InfobarChannelSelection", "DirectionActions", "NumberActions", "ColorActions"], {
                "ok": self.close,
                "cancel": self.close,
                "red": self.exit_plugin,
                "green": self.save_only,
                "yellow": self.change_skin,
                "blue": self.toggle_warnings,
                "up": self.increase_duration,
                "down": self.decrease_duration
            }, -1
        )

        # Timer setup
        self.updateTimer = eTimer()
        try:
            # Try to connect both possible interfaces (compatibility)
            self.updateTimer_conn = self.updateTimer.timeout.connect(self.updateTemps)
        except:
            try:
                self.updateTimer.callback.append(self.updateTemps)
            except:
                log_message("Failed to connect timer to updateTemps")
                self.updateTimer = None

        log_message("Initializing DiskCpuTempScreen")
        self.onShown.append(self.startTimer)
        self.onHide.append(self.stopTimer)

        log_message("Screen initialization complete")

    def __del__(self):
        # Clean up resources
        try:
            if hasattr(self, 'updateTimer') and self.updateTimer is not None:
                self.updateTimer.stop()
                self.updateTimer = None
        except:
            pass

        # Clear instance reference
        if DiskCpuTempScreen.instance == self:
            DiskCpuTempScreen.instance = None

    # --- Temperature update --- 
    def get_cpu_temp(self):
        try:
            if not os.path.exists("/sys/class/thermal/thermal_zone0/temp"):
                return "N/A"
            with open("/sys/class/thermal/thermal_zone0/temp", "r") as f:
                raw = f.read().strip()
                try:
                    temp = int(raw)
                    # if value looks like millidegree
                    if temp > 1000:
                        temp = temp / 1000.0
                    else:
                        temp = float(temp)
                    return "%.1f C" % temp
                except:
                    return "N/A"
        except:
            return "N/A"

    def updateTemps(self):
        """Update temperature displays - THIS IS THE MAIN FUNCTION THAT DISPLAYS DATA"""
        try:
            # Get CPU temperature
            cpu_temp = self.get_cpu_temp()
            cpu_color = temp_to_color(cpu_temp, "CPU")
            self["cpu_label"].setText("CPU : %s" % cpu_temp)
            self["cpu_label"].instance.setForegroundColor(cpu_color)
            
            # Check CPU temperature warnings
            check_temperature_warnings("CPU", "CPU", cpu_temp)

            # Get storage temperatures with NEW FORMAT
            try:
                from temp_utilities import get_formatted_drive_temps
                drive_temps = get_formatted_drive_temps()
            except Exception as e:
                log_message("Error getting formatted drive temps: %s" % str(e))
                drive_temps = []

            # Clear all HDD labels first
            for i in range(1, 5):
                self["hdd%d_label" % i].setText("")

            # Display storage temperatures in new format
            for i, (display_name, temp) in enumerate(drive_temps):
                if i >= 4:  # Only show up to 4 drives
                    break
                    
                # Set text with new format: "HDD1–SATA–sda : 35 C"
                label_text = "%s : %s" % (display_name, temp)
                self["hdd%d_label" % (i+1)].setText(label_text)
                
                # Set color based on temperature
                hdd_color = temp_to_color(temp, "HDD")
                self["hdd%d_label" % (i+1)].instance.setForegroundColor(hdd_color)
                
                # Check HDD temperature warnings
                check_temperature_warnings("HDD", display_name, temp)

            # Update timestamp
            timestamp = time.strftime("%H:%M:%S")
            self["update_label"].setText("Last update: %s" % timestamp)

        except Exception as e:
            log_message("Error in updateTemps: %s" % str(e))
            self["cpu_label"].setText("CPU : Error")
            for i in range(1, 5):
                self["hdd%d_label" % i].setText("Error reading temp")

    def startTimer(self):
        """Start the update timer"""
        try:
            if self.updateTimer:
                self.updateTimer.start(5000)  # Update every 5 seconds
                log_message("Update timer started")
                # Do initial update immediately
                self.updateTemps()
        except Exception as e:
            log_message("Error starting timer: %s" % str(e))

    def stopTimer(self):
        """Stop the update timer"""
        try:
            if self.updateTimer:
                self.updateTimer.stop()
                log_message("Update timer stopped")
        except Exception as e:
            log_message("Error stopping timer: %s" % str(e))

    def show_warning_bar(self, text):
        """Show warning banner on screen"""
        try:
            self["warning_bar"].setText(text)
            # You can also set background color to red for visibility
            self["warning_bar"].instance.setForegroundColor(gRGB(255, 0, 0))
        except Exception as e:
            log_message("Error showing warning bar: %s" % str(e))

    def clear_warning_bar(self):
        """Clear warning banner"""
        try:
            self["warning_bar"].setText("")
            # Reset to default color
            self["warning_bar"].instance.setForegroundColor(gRGB(255, 255, 255))
        except Exception as e:
            log_message("Error clearing warning bar: %s" % str(e))

    def exit_plugin(self):
        """Exit the plugin"""
        self.close()

    def save_only(self):
        """Save settings"""
        try:
            config.plugins.DiskCpuTemp.save()
            self["settings_label"].setText("Settings saved!")
            log_message("Settings saved")
        except Exception as e:
            log_message("Error saving settings: %s" % str(e))
            self["settings_label"].setText("Error saving settings!")

    def change_skin(self):
        """Toggle between skins"""
        try:
            current_skin = config.plugins.DiskCpuTemp.last_skin.value
            new_skin = "Fhd1" if current_skin == "Fhd2" else "Fhd2"
            config.plugins.DiskCpuTemp.last_skin.value = new_skin
            config.plugins.DiskCpuTemp.save()
            
            # Show message and restart plugin
            self.session.openWithCallback(
                self.restart_plugin,
                MessageBox,
                "Skin changed to %s. Plugin will restart." % new_skin,
                type=MessageBox.TYPE_INFO,
                timeout=3
            )
        except Exception as e:
            log_message("Error changing skin: %s" % str(e))

    def restart_plugin(self, result=None):
        """Restart the plugin with new skin"""
        try:
            self.close()
            # Reopen the plugin
            from enigma import eTimer
            restart_timer = eTimer()
            restart_timer.callback.append(lambda: main(self.session))
            restart_timer.start(100, True)  # Single shot after 100ms
        except Exception as e:
            log_message("Error restarting plugin: %s" % str(e))

    def toggle_warnings(self):
        """Toggle warnings on/off"""
        global warnings_enabled
        warnings_enabled = not warnings_enabled
        status = "ENABLED" if warnings_enabled else "DISABLED"
        self["stop_warning_button"].setText("Warnings: %s" % status)
        log_message("Warnings %s" % status)

    def increase_duration(self):
        """Increase warning duration"""
        try:
            current = int(config.plugins.DiskCpuTemp.warning_duration.value)
            choices = ["5000", "10000", "15000", "20000"]
            current_index = choices.index(str(current))
            if current_index < len(choices) - 1:
                new_duration = choices[current_index + 1]
                config.plugins.DiskCpuTemp.warning_duration.value = new_duration
                seconds = int(new_duration) / 1000
                self["settings_label"].setText("Warning Duration: %d seconds" % seconds)
                log_message("Warning duration increased to %d seconds" % seconds)
        except Exception as e:
            log_message("Error increasing duration: %s" % str(e))

    def decrease_duration(self):
        """Decrease warning duration"""
        try:
            current = int(config.plugins.DiskCpuTemp.warning_duration.value)
            choices = ["5000", "10000", "15000", "20000"]
            current_index = choices.index(str(current))
            if current_index > 0:
                new_duration = choices[current_index - 1]
                config.plugins.DiskCpuTemp.warning_duration.value = new_duration
                seconds = int(new_duration) / 1000
                self["settings_label"].setText("Warning Duration: %d seconds" % seconds)
                log_message("Warning duration decreased to %d seconds" % seconds)
        except Exception as e:
            log_message("Error decreasing duration: %s" % str(e))

# --- Main Functions ---
def main(session, **kwargs):
    try:
        clear_log()
        log_message("Plugin started - opening screen")
        session.open(DiskCpuTempScreen)
        log_message("Screen opened successfully")
    except Exception as e:
        log_message("Error opening screen: %s" % str(e))

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Disk & CPU Temperature by Iet5",
            description="Show CPU and HDD/SSD/NVMe temperatures",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main
        )
    ]