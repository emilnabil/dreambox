#!/usr/bin/python
# -*- coding: utf-8 -*-

from Plugins.Plugin import PluginDescriptor
from Components.ActionMap import ActionMap
from Screens.Screen import Screen
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigYesNo, getConfigListEntry, NoSave, ConfigSelection, ConfigSelectionNumber
from Screens.MessageBox import MessageBox
from Components.Sources.StaticText import StaticText
from Tools.Directories import fileExists, pathExists
from Components.FileList import FileList
from enigma import getDesktop
import os
import subprocess, threading

sz_w = getDesktop(0).size().width()

bootvideo_version = "0.3-r3"

bootvideo_volume = NoSave(ConfigSelectionNumber(0, 10, 1, default = 10))
bootvideo_mp4 = NoSave(ConfigSelection(choices=[(" "," ")], default = " ")) #set Values in screen_init
bootvideo_video = NoSave(ConfigYesNo(default = False))
bootvideo_logo = NoSave(ConfigYesNo(default = False))

if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/GoldenPanel/plugin.pyo"):
        os.remove("/usr/lib/enigma2/python/Plugins/Extensions/GoldenPanel/plugin.pyo")
if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/GoldenFeed/plugin.pyo"):
        os.remove("/usr/lib/enigma2/python/Plugins/Extensions/GoldenFeed/plugin.pyo")
if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions(PersianDreambox/plugin.pyo"):
        os.remove("/usr/lib/enigma2/python/Plugins/Extensions/PersianDreambox/plugin.pyo")
if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/PersianDreambox/plugin.py"):
        os.remove("/usr/lib/enigma2/python/Plugins/Extensions/PersianDreambox/plugin.py")
if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/DreamOSatDownloader/plugin.pyo"):
        os.remove("/usr/lib/enigma2/python/Plugins/Extensions/DreamOSatDownloader/plugin.pyo")

try:
	f = open("/proc/stb/info/model", "r")
	boxmodel = ''.join(f.readlines()).strip()
except:
	boxmodel = ''

class BootvideoBrowser(Screen):
	if sz_w == 1920:
		skin = """
		<screen name="BootVideoBrowser" position="center,170" size="1200,820" title="Bootvideo Browser">
			<ePixmap pixmap="Default-FHD/skin_default/buttons/red.svg" position="10,5" size="300,70" />
			<ePixmap pixmap="Default-FHD/skin_default/buttons/green.svg" position="310,5" size="300,70" />
			<widget backgroundColor="#9f1313" font="Regular;30" halign="center" position="10,5" render="Label" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="300,70" source="key_red" transparent="1" valign="center" zPosition="1" />
			<widget backgroundColor="#1f771f" font="Regular;30" halign="center" position="310,5" render="Label" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="300,70" source="key_green" transparent="1" valign="center" zPosition="1" />
			<eLabel backgroundColor="grey" position="10,80" size="1180,1" />
			<widget enableWrapAround="1" name="filelist" position="10,90" scrollbarMode="showOnDemand" size="1180,720" />
		</screen>"""
	else:
		skin = """
		<screen name="BootVideoBrowser" position="center,120" size="820,520" title="BootVideo Browser">
			<ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="200,40"/>
			<ePixmap pixmap="skin_default/buttons/green.png" position="210,5" size="200,40"/>
			<widget source="key_red" render="Label" position="10,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2"/>
			<widget source="key_green" render="Label" position="210,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2"/>
			<eLabel position="10,50" size="800,1" backgroundColor="grey"/>
			<widget name="filelist" position="10,60" size="800,450" enableWrapAround="1" scrollbarMode="showOnDemand"/>
		</screen>"""

	def __init__(self, session, current_path=None):
		Screen.__init__(self, session)
		if current_path:
			currDir = current_path
			if not pathExists(currDir):
				currDir = "/"
		else:
			currDir = None #start with mountpoints-list

		self.filelist = FileList(currDir, matchingPattern="(?i)^.*\.(mp4)")
		self["filelist"] = self.filelist

		self["FilelistActions"] = ActionMap(["SetupActions"],
			{
				"save": self.ok,
				"ok": self.ok,
				"cancel": self.exit
			})
		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("OK"))
		self.onShown.append(self.setWindowTitle)

	def setWindowTitle(self):
		self.setTitle(_("BootVideo Browser"))

	def ok(self):
		if self["filelist"].canDescent(): # isDir
			self["filelist"].descent()
		else:
			file_name = self["filelist"].getFilename()
			path = self["filelist"].getCurrentDirectory()
			self.close(path + file_name)

	def exit(self):
		self.close(None)


class Command(object):
	def __init__(self, cmd):
		self.cmd = cmd
		self.process = None

	def run(self, timeout):
		def target():
			self.process = subprocess.Popen(self.cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
			(self.out,self.err) = self.process.communicate()

		thread = threading.Thread(target=target)
		thread.start()
		self.timeout=False

		thread.join(float(timeout))
		if thread.is_alive():
			self.process.terminate()
			self.timeout=True
			self.process = None
			thread = None
			return

class bootvideo(Screen, ConfigListScreen):
	if sz_w == 1920:
		skin = """
		<screen name="bootvideo" position="center,center" size="1200,620">
			<ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="295,70" scale="stretch" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/green.png" position="305,5" size="295,70" scale="stretch" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/yellow.png" position="600,5" size="295,70" scale="stretch" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/blue.png" position="895,5" size="295,70" scale="stretch" alphatest="on" />
			<widget source="key_red" render="Label" position="10,5" zPosition="1" size="295,70" font="Regular;30" halign="center" valign="center" backgroundColor="#9f1313" shadowColor="black" shadowOffset="-2,-2" transparent="1" />
			<widget source="key_green" render="Label" position="310,5" zPosition="1" size="300,70" font="Regular;30" halign="center" valign="center" backgroundColor="#1f771f" shadowColor="black" shadowOffset="-2,-2" transparent="1" />
			<widget source="key_yellow" render="Label" position="610,5" zPosition="1" size="300,70" font="Regular;30" halign="center" valign="center" backgroundColor="#9f1313" shadowColor="black" shadowOffset="-2,-2" transparent="1" />
			<widget source="key_blue" render="Label" position="910,5" zPosition="1" size="300,70" font="Regular;30" halign="center" valign="center" backgroundColor="#1f771f" shadowColor="black" shadowOffset="-2,-2" transparent="1" />
			<widget name="config" position="10,90" itemHeight="35" size="1180,540" enableWrapAround="1" scrollbarMode="showOnDemand" />
		</screen>"""
	else:
		skin = """
		<screen name="bootvideo" position="center,center" size="800,400">
			<ePixmap pixmap="skin_default/buttons/red.png" position="0,0" size="200,40" scale="stretch" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/green.png" position="200,0" size="200,40" scale="stretch" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/yellow.png" position="400,0" size="200,40" scale="stretch" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/blue.png" position="600,0" size="200,40" scale="stretch" alphatest="on" />
			<widget source="key_red" render="Label" position="0,0" zPosition="1" size="200,40" font="Regular;22" halign="center" valign="center" backgroundColor="#9f1313" shadowColor="black" shadowOffset="-2,-2" transparent="1" />
			<widget source="key_green" render="Label" position="200,0" zPosition="1" size="200,40" font="Regular;22" halign="center" valign="center" backgroundColor="#1f771f" shadowColor="black" shadowOffset="-2,-2" transparent="1" />
			<widget source="key_yellow" render="Label" position="400,0" zPosition="1" size="200,40" font="Regular;22" halign="center" valign="center" backgroundColor="#9f1313" shadowColor="black" shadowOffset="-2,-2" transparent="1" />
			<widget source="key_blue" render="Label" position="600,0" zPosition="1" size="200,40" font="Regular;22" halign="center" valign="center" backgroundColor="#1f771f" shadowColor="black" shadowOffset="-2,-2" transparent="1" />
			<widget name="config" position="5,50" itemHeight="30" size="790,450" enableWrapAround="1" scrollbarMode="showOnDemand" />
		</screen>"""
	def __init__(self, session):
		
		Screen.__init__(self, session)
		self.setup_title = _("BootVideo") + " v" + bootvideo_version
		self.onChangedEntry = []
		self.list = [ ] 
		ConfigListScreen.__init__(self, self.list, session=session, on_change=self.changedEntry)
		
		from Components.ActionMap import ActionMap
		self["actions"] = ActionMap(["SetupActions", "ColorActions"],
			{
				"cancel": 	self.keyCancel,
				"save": 	self.save,
				"blue":		self.about,
				"ok":		self.ok,
			}, -2)
		
		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("Save"))
		self["key_yellow"] = StaticText(_(" "))
		self["key_blue"] = StaticText(_("About"))
		
		#check if exist bootlogo and set the option
		bootvideo_logo.value = fileExists("/usr/share/dreambox-bootlogo/backdrop.mvi")
		bootvideo_logo.default = bootvideo_logo.value
		
		#check if is bootvideo-service is enabled und set the option
		command = Command("systemctl is-enabled bootvideo")
		command.run(timeout=int(3))
		bootvideo_video.value = False
		
		if command.timeout:
			print "[BootVideo] command.timeout"
		elif command.err:
			print "[BootVideo] command.err", command.err
		else:
			print "[BootVideo] command.out bootvideo '" + command.out.strip() + "'"
			bootvideo_video.value = command.out.strip() == "enabled"
		bootvideo_video.default = bootvideo_video.value

		#set bootvideo_mp4
		bootvideofilename = str(self.getBootvideoFile())
		filename = os.path.basename(bootvideofilename)
		bootvideo_mp4.default = bootvideofilename
		bootvideo_mp4.choices.choices = [(bootvideofilename,filename)]
		bootvideo_mp4.value = bootvideofilename
		
		#set bootvideo_volume
		volume = self.getVolume()
		bootvideo_volume.default = str(volume)
		bootvideo_volume.value= volume
		
		
		self.createSetup() 
		self.onLayoutFinish.append(self.layoutFinished) 
		
	def layoutFinished(self):
		self.setTitle(self.setup_title)

	def ok(self):
		current = self["config"].getCurrent()[1]
		if (current == bootvideo_mp4):
			self.selectBootVideo()

	def selectBootVideo(self):
		path = os.path.dirname(bootvideo_mp4.value) + "/"
		print "basename", path
		self.session.openWithCallback(self.selectBootVideoCB, BootvideoBrowser, path) 
		#		"/usr/share/dreambox-bootvideo/"

	def selectBootVideoCB(self, retvalue):
		if retvalue:
			#self.session.open(MessageBox, retvalue, MessageBox.TYPE_INFO)
			filename = os.path.basename(retvalue)
			bootvideo_mp4.choices.choices = [(retvalue,filename)]
			bootvideo_mp4.value = retvalue
		else:
			#self.session.open(MessageBox, "Abbruch", MessageBox.TYPE_INFO)
			pass

	def createSetup(self):
		self.list = []
		self.list.append(getConfigListEntry(_("activate Boot-Logo"), bootvideo_logo))
		self.list.append(getConfigListEntry(_("activate Boot-Video"), bootvideo_video))
		if bootvideo_video.value:
			self.list.append(getConfigListEntry(_("select Boot-Video"), bootvideo_mp4))
			self.list.append(getConfigListEntry(_("select Boot-Video Volume-Level (0=mute, 10=max)"), bootvideo_volume))
		self["config"].list = self.list
		self["config"].l.setList(self.list)

	def changedEntry(self):
		for x in self.onChangedEntry:
			x()
		if self["config"].getCurrent()[1] == bootvideo_video:
			self.createSetup()

	def save(self):
		#rewrite bootvideo.service
		self.write_bootvideoservice()
		
		if bootvideo_video.value:
			command = Command("systemctl enable bootvideo")
		else:
			command = Command("systemctl disable bootvideo")
		command.run(timeout=int(3))
		if command.timeout:
			print "[BootVideo] command.timeout"
		elif command.process.returncode != 0:
			print "[BootVideo] command.err", command.err
		
		if bootvideo_logo.value:
			if fileExists("/usr/share/dreambox-bootlogo/backdrop_org.mvi"):
				os.rename('/usr/share/dreambox-bootlogo/backdrop_org.mvi', '/usr/share/dreambox-bootlogo/backdrop.mvi')
			#additional for dreambox one
			if fileExists("/boot/bootlogo_org.bmp"):
				os.rename('/boot/bootlogo_org.bmp', '/boot/bootlogo.bmp')
		elif not bootvideo_logo.value:
			if fileExists("/usr/share/dreambox-bootlogo/backdrop.mvi"):
				os.rename('/usr/share/dreambox-bootlogo/backdrop.mvi', '/usr/share/dreambox-bootlogo/backdrop_org.mvi')
			#additional for dreambox one
			if fileExists("/boot/bootlogo.bmp"):
				os.rename('/boot/bootlogo.bmp', '/boot/bootlogo_org.bmp')
		
		#rewrite bootvideo-startscript
		self.write_startscript()
		
		self.close()

	def about(self):
		title="    bootvideo version %s \nplugin by Hilfsbereit 2018-2019\n     special thanks goes to ...\n           pclin & Sven H" % bootvideo_version
		self.session.open(MessageBox,("%s") % (title),  MessageBox.TYPE_INFO)

	def getBootvideoFile(self):
		startscript_lines = ()
		try:
			startscript_file = open("/usr/script/bootvideo.startscript", "r")
			startscript_lines = startscript_file.readlines()
			startscript_file.close()
		except:
			print "[Bootvideo] Error on read bootvideo.startscript"
		
		BootvideoFilename = ""
		for line in startscript_lines:
			if "bootvideo_file=" in line:
				BootvideoFilename = line.replace("bootvideo_file=", "").replace('"',"").strip()
				break
		
		#set to default, if not read the videofilename or not exist
		if not BootvideoFilename or not fileExists(BootvideoFilename):
			if fileExists("/data/dreambox-bootvideo/bootvideo.mp4"):
				BootvideoFilename = "/data/dreambox-bootvideo/bootvideo.mp4"
			else:
				BootvideoFilename = "/usr/share/dreambox-bootvideo/bootvideo.mp4"
		
		print "[Bootvideo] getBootvideoFile:", BootvideoFilename
		return BootvideoFilename

	def getVolume(self):
		startscript_lines = ()
		try:
			startscript_file = open("/usr/script/bootvideo.startscript", "r")
			startscript_lines = startscript_file.readlines()
			startscript_file.close()
		except:
			print "[Bootvideo] Error on read bootvideo.startscript"
		
		volume = "1.0"
		for line in startscript_lines:
			pos = line.find("volume=")
			#print "[Bootvideo] pos:", pos, line
			if pos>0:
				volume = line[pos+8:pos+11]
				break
		
		#print "[Bootvideo] volume:", volume
		volume = int(float(volume)*10)
		print "[Bootvideo] getVolume:", volume
		return volume

	def write_startscript(self):
		script_txt  = '#!/bin/sh\n'
		script_txt += 'NAME="bootvideo.startscript"\n'
		script_txt += 'VER="' + bootvideo_version + '"\n'
		script_txt += 'OS="dreamOS 2.5/2.6"\n'
		script_txt += 'STRING="$NAME_$VER - $OS"\n'
		script_txt += 'bootvideo_file="' + bootvideo_mp4.value + '"\n'
		script_txt += 'printf "\\n[Bootvideo] start bootvideo on ' + boxmodel.upper() + ': $bootvideo_file"\n'
		volume = str(int(bootvideo_volume.value)/float(10))
		if boxmodel == "one":
			script_txt += 'gst-launch-1.0 playbin uri=file://$bootvideo_file audio-sink="alsasink" volume="' + volume + '">& /tmp/bootvideo.log\n'
		else:
			script_txt += 'echo 0 > /proc/stb/video/alpha && gst-launch-1.0 playbin uri=file://$bootvideo_file audio-sink="alsasink" volume="' + volume + '" >& /tmp/bootvideo.log\n'
			script_txt += 'echo 255 > /proc/stb/video/alpha\n'
		script_txt += '\n'
		script_txt += 'printf "\\n[Bootvideo] restart enigma2\\n"\n'
		script_txt += 'systemctl restart enigma2\n'
		script_txt += 'exit 0\n'

		if not pathExists("/usr/script"):
			os.makedirs("/usr/script")
		startscript_file = open("/usr/script/bootvideo.startscript", "w")
		startscript_file.write(script_txt)
		startscript_file.close()
		os.chmod("/usr/script/bootvideo.startscript",0755)
			
	def write_bootvideoservice(self):
		script_txt  = '[Unit]\n'
		script_txt += 'Description=Start a Bootvideo\n'
		script_txt += 'Requires=dev-dvb-adapter0-video0.device\n'
		script_txt += 'After=dev-dvb-adapter0-video0.device\n'
		if boxmodel == "one":
			script_txt += 'Conflicts=showiframe-backdrop.service\n'
		else:
			script_txt += 'Conflicts=enigma2.service showiframe-backdrop.service\n'
		script_txt += '\n'
		script_txt += '[Service]\n'
		script_txt += 'Type=forking\n'
		script_txt += 'ExecStart=/usr/script/bootvideo.startscript\n'
		script_txt += 'SuccessExitStatus=2\n'
		script_txt += '\n'
		script_txt += '[Install]\n'
		script_txt += 'WantedBy=graphical.target\n'

		bootvideoservice_file = open("/etc/systemd/system/bootvideo.service", "w")
		bootvideoservice_file.write(script_txt)
		bootvideoservice_file.close()
		os.chmod("/etc/systemd/system/bootvideo.service",0644)

def main(session, **kwargs):
	session.open(bootvideo)

def Plugins(**kwargs):
	list = [PluginDescriptor(name=_("Bootvideo"), description="Bootvideo for DreamOS", where = PluginDescriptor.WHERE_PLUGINMENU,icon="bootvideo.png",fnc = main)]
	list.append(PluginDescriptor(name=_("Bootvideo"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main))
	list.append(PluginDescriptor(name=_("Bootvideo"), description=_("Bootvideo"), where = [PluginDescriptor.WHERE_MENU], fnc=menu_bootvideo))
	return list

def menu_bootvideo(menuid, **kwargs):
	if menuid == "osd_video_audio":
		return [(_("BootVideo"), main, "bootvideo", 11)]
	return []	
