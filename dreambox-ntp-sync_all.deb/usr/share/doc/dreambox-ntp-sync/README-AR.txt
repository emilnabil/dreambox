حزمة Dreambox NTP Sync بصيغة DEB
==================================

متوافقة مع صور Merlin وGemini التي تستخدم dpkg على:
- Dreambox DM900
- Dreambox DM920
- Dreambox One
- Dreambox Two

التثبيت:
  dpkg -i /tmp/dreambox-ntp-sync_1.0.0_all.deb

ثم يفضّل إعادة تشغيل الجهاز مرة واحدة:
  reboot

الفحص:
  /usr/bin/merlin-ntp-sync --version
  cat /tmp/merlin-ntp-sync.log
  systemctl status merlin-ntp-sync.service

الإزالة:
  dpkg -r dreambox-ntp-sync

ملاحظة:
أجهزة MIPS القديمة التي تستخدم opkg ولا تحتوي dpkg تحتاج حزمة IPK، ولا يمكن
تثبيت ملف DEB عليها مباشرة.
