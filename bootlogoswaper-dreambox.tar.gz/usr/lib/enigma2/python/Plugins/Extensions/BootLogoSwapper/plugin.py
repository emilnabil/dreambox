# Plugin by WooshMan - Modified by Emil Nabil for Dreambox official images

from Plugins.Plugin import PluginDescriptor
import shutil
import os, random

screens = '/usr/share/bootlogos/'
logopath = '/etc/enigma2/'

# Detect Dreambox image type
def detect_image_type():
    if os.path.exists('/etc/image-version'):
        with open('/etc/image-version', 'r') as f:
            content = f.read().lower()
            if 'newnigma2' in content:
                return 'newnigma2'
            elif 'dream-elite' in content:
                return 'dream-elite'
            elif 'merlin' in content:
                return 'merlin'
    return 'unknown'

# Define target bootlogo path based on image
def get_bootlogo_target_path():
    image = detect_image_type()
    if image in ['newnigma2', 'dream-elite', 'merlin']:
        return '/boot/'
    return '/usr/share/dreambox-bootlogo/'  # fallback

def autostart(reason, **kwargs):
    if reason != 0:  # run only on boot, not shutdown
        return

    # Remove existing symlinks or files
    for logo in ['bootlogo.mvi', 'backdrop.mvi', 'bootlogo_wait.mvi']:
        target_file = os.path.join(logopath, logo)
        if os.path.exists(target_file):
            try:
                os.remove(target_file)
            except Exception:
                pass

    if os.path.isdir(screens):
        available_logos = [f for f in os.listdir(screens) if f.endswith('.mvi')]
        if available_logos:
            newscreen = random.choice(available_logos)
            source_logo = os.path.join(screens, newscreen)
            target_path = get_bootlogo_target_path()

            # Copy selected logo
            try:
                shutil.copy(source_logo, os.path.join(target_path, 'bootlogo.mvi'))
                shutil.copy(source_logo, os.path.join(target_path, 'backdrop.mvi'))
                shutil.copy(source_logo, os.path.join(target_path, 'bootlogo_wait.mvi'))
            except Exception as e:
                print("[BootLogoSwapper] Error copying logo:", str(e))

def Plugins(**kwargs):
    return PluginDescriptor(
        name="-Boot Logo Swap",
        description="Boot Logo Swapper (Dreambox Official Images Compatible)",
        where=PluginDescriptor.WHERE_AUTOSTART,
        icon="/usr/lib/enigma2/python/Plugins/Extensions/BootLogoSwapper/images/plugin.png",
        fnc=autostart
    )


