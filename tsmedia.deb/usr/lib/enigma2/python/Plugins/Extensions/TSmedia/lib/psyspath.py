# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/TSmedia/lib/syspath.py
import sys
import os
def trace_error():
   
    import traceback
    try:
        #traceback.print_exc(file=sys.stdout)
        if os.path.exists('/tmp/TSmedia_log'):
            logfile = '/tmp/TSmedia_log'
        else:
            return
        traceback.print_exc(file=open(logfile, 'a'))
    except:
        pass
scripts = '/usr/lib/enigma2/python/Plugins/Extensions/TSmedia/scripts'



try:
       for name in os.listdir(scripts):
              if "script." in name:
                      fold = scripts + "/" + name + "/lib"
                     
                      sys.path.append(fold)

      
except:
       pass



try:
       
    sys.argv[0]=sys.argv[0].replace("psyspath","default")
    try:
        sys.argv[2] = sys.argv[2].replace('AxNxD', '&').replace('ExQ', '=').strip()
    except:

        pass
    
    import default
    
except:
    trace_error()
