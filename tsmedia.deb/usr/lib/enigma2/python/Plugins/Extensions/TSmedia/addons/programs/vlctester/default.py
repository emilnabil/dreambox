
import os,sys


import httplib
import time
from urllib import urlencode
import urllib,urllib2,re
from httplib import HTTP
from urlparse import urlparse
import StringIO
from xbmctools import Item,readnet,supported,get_params,getDomain,getserver_image,resolvehost
item=Item()
addDir=item.addDir
endDir=item.endDir

regx1="""<div class="movied">
<a href="(.*?)"><img src="(.*?)"  alt="(.*?)" height="207" width="140" /></a></div>
<div class="movief"><a href="(.*?)">(.*?)</a></div>"""

regx2='<p><IFRAME SRC="(.*?)" FRAMEBORDER=0 MARGINWIDTH=0 MARGINHEIGHT=0 SCROLLING=NO WIDTH=640 HEIGHT=360></IFRAME></p>'
regx3='file: "(.*?)",'

#baseurl='http://www.vlc.eu.pn/index.php'
baseurl='http://vlctest.eu5.net/'


def fixlink(url):
   try:
    #url='rtmp://5.63.151.4:443/atv<playpath>atv3<swfUrl>http://i.tmgrup.com.tr/p/flowplayer-3.2.9.swf?i=1<pageUrl>http://www.atv.com.tr/webtv/canli-yayin<live>1'
       url=url.replace('<swfUrl>',' swfUrl=').replace('<pageUrl>',' pageUrl=').replace('<live>',' live=') .replace('<playpath>',' playpath=').replace('<playpath>',' playpath=').strip()  
   except:
      pass   
   return url
def getlinks(url=baseurl):
                print url
                list1=[]
                err='none'
                pagecounts=0
                done=True
                regx='''<h5><span style="(.*?)">(.*?)</span>(.*?)</h5>'''
                regx='''<strong><span style="(.*?)">(.*?)</span>(.*?)</strong><br>'''
                regx='''<strong><span style="(.*?)">(.*?)</span>(.*?)</strong><br>'''
                #regx='''<h5><span style="(.*?)</span>(.*?)</h5>'''
                debug=True
                if debug:

                        
                        data=readnet(url)
                        
                        print data
                        match = re.findall(regx,data, re.M|re.I)
                        #print 'match',match[0]
                        
                        print 'matchlength',len(match)
                        #print match[2]
                        
                       
                        for color,href,cdate in match:
                            print "href",href
                            #continue
                            active=True
                           
                            active='working'
                            if '#D04E0F' in color:
                                active='Not working'
                                img="img/red.png"
                            else:
                                 img="img/blue.png"    
                            cdate=cdate.replace('|','').strip()
                            name=href[:40]
                            
                            
                            if href.startswith('rtmp'):
                               href=fixlink(href)
                            name,image,issupported=getDomain(href)
                            
                            filename=os.path.split(href)[1]
                            
                            if supported(name):
                               name =name+"-"+filename+'-'+active     
                               addDir(name,href,0,img,"",1,True)
                               continue
                                                                                    
                            else:
                                    filename=os.path.split(href)[1]
                                    
                                    name=name+" "+cdate+"-"+active

              
                                    addDir(name,href,0,img,"",1,True)     
                                    
                                     
    
                        
                else:
                           err='Parsing error'
                           list1=[]
                

                return None



def start():  
        params=get_params()
        url=None
        name=None
        mode=None
        page=1


        name=params.get("name",None)
        url=params.get("url",None)
        try:mode=int(params.get("mode",None))
        except:mode=None
        image=params.get("image",None)
        section=params.get("section",None)
        page=int(params.get("page",1))
        extra=params.get("extra",None)
        show=params.get("show",None)





        print "Mode1: "+str(mode)
        print "URL: "+str(url)
        print "Name: "+str(name)
        print "Image: "+str(image)
        print "page: "+str(page)
        print "section: "+str(section)
        print "show: "+str(show)
        print "extra: "+str(extra)
        ##menu and tools
        if mode==None or url==None or len(url)<1:
                print ""
                getlinks()
        elif mode==1:
                resolvehost(item,name,url)
        
        return endDir()
