## Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/TSmedia/scripts/script.module.main/lib/xbmctools.py
import sys
import os
import urllib
import urllib2
import ssl
import re
from urlparse import parse_qs, urlparse
plugin_path='/usr/lib/enigma2/python/Plugins/Extensions/TSmedia/'
try:
    import requests
except:
    pass
def getdeveloper_mode():
    developer_mode=False
    version_file = '/usr/lib/enigma2/python/Plugins/Extensions/TSmedia/version'
    if os.path.exists(version_file):
        try:
            fp = open(version_file, 'r').readlines()
            for line in fp:
                if 'developer_mode' in line:
                    developer_mode = line.split(':')[1].strip()
                    if developer_mode=="True":
                       developer_mode=True
                    else:
                       developer_mode=False
                

        except:
            pass
        return developer_mode
def getpage(url):
    import Queue
    import threading
    import urllib2

    # called by each thread
    def get_url(q, url):
        q.put(getnet(url))

    #theurls = ["http://google.com", "http://yahoo.com"]

    q = Queue.Queue()

    if True:
        t = threading.Thread(target=get_url, args = (q,url))
        t.daemon = False
        t.start()

    s = q.get()
    return s
def decodeHtmlentities(string):
    string = entitiesfix(string)
    entity_re = re.compile("&(#?)(\d{1,5}|\w{1,8});")

    def substitute_entity(match):
        from htmlentitydefs import name2codepoint as n2cp
        ent = match.group(2)
        if match.group(1) == "#":
            return unichr(int(ent)).encode('utf-8')
        else:
            cp = n2cp.get(ent)

            if cp:
                return unichr(cp).encode('utf-8')
            else:
                return match.group()

    return entity_re.subn(substitute_entity, string)[0]
def getos():
    if __file__.startswith('/usr'):
        return 'enigma2'
    else:
        return 'windows'
data_file='/tmp/TSmedia/data.txt'
datasearch_file="/tmp/TSmedia/datasearch"
def get_youtube_link(value):
    """
    Examples:
    - http://youtu.be/SA2iWivDJiE
    - http://www.youtube.com/watch?v=_oPAwA_Udwc&feature=feedu
    - http://www.youtube.com/embed/SA2iWivDJiE
    - http://www.youtube.com/v/SA2iWivDJiE?version=3&amp;hl=en_US
    -'plugin://plugin.video.youtube/?action=play_video&amp;videoid=FBBLhRgrw0o'
    """
    from urlparse import urlparse
    vid = None
    if value is None:
        return
    else:
        value = value.strip()
        if value.startswith('plugin://'):
            try:
                vid = value.split('=')[value.count('=')]
            except:
                return

        else:
            query = urlparse(value)
            if query.hostname == 'youtu.be':
                vid = query.path[1:]
            elif query.hostname in ('www.youtube.com', 'youtube.com'):
                if query.path == '/watch':
                    p = parse_qs(query.query)
                    vid = p['v'][0]
                if query.path[:7] == '/embed/':
                    vid = query.path.split('/')[2]
                if query.path[:3] == '/v/':
                    vid = query.path.split('/')[2]
        return 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % vid
        return


def extractdata(data, marker1, marker2, withMarkers = False, caseSensitive = True):
    if caseSensitive:
        idx1 = data.find(marker1)
    else:
        idx1 = data.lower().find(marker1.lower())
    if -1 == idx1:
        idx1 = 0
    if caseSensitive:
        idx2 = data.find(marker2, idx1 + len(marker1))
    else:
        idx2 = data.lower().find(marker2.lower(), idx1 + len(marker1))
    if -1 == idx2:
        idx2 = len(data) - 1
    if withMarkers:
        idx2 = idx2 + len(marker2)
    else:
        idx1 = idx1 + len(marker1)
    return data[idx1:idx2]


def cleanparam(param):
    param = param.strip()
    if '&' in param and ';' in param:
        sdata = finddata(param, '&', ';', True)
        if not sdata.strip() == '':
            param = param.replace(sdata, '')
          
            if '&' in param and ';' in param:
                param = cleanparam(param)
    return param


def geturlbyreferal(url, referer):
    request2 = urllib2.Request(url)
    request2.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36')
    request2.add_header('Referer', referer)
    request2.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
    request2.add_header('Accept-Language', 'de,en-US;q=0.7,en;q=0.3')
    response2 = urllib2.urlopen(request2)


def findalldata(data, marker1, marker2, index = 0, fdata = []):
    
    data = data[index:len(data)]
    idx1 = data.find(marker1)
    if -1 == idx1:
        return fdata
    idx2 = data.find(marker2, idx1 + len(marker1))
    if -1 == idx2:
        return fdata
    idx1 = idx1 + len(marker1)
    fdata.append(data[idx1:idx2])
    findalldata(data, marker1, marker2, idx2 + len(marker2), fdata)


def cfdownloadImage(url = None):
    if os.path.exists('/tmp/TSmedia/dimage') == False:
        return url
    elif url is None or url.strip() == '':
        return ''
    else:
        if 'ExQ' in url:
            url.replace('ExQ', '=')
        if os.name == 'nt':
            path = 'd:\\tmp'
        else:
            path = '/tmp/TSmedia'
        if url and url.startswith('http'):
            try:
                filename = url.split('/')[-1]
                ofile = os.path.join(path, filename)
                if os.path.exists(ofile):
                    return ofile
                try:
                    r = cfresolve(url)
                    with open(ofile, 'wb') as f:
                        f.write(r)
                    f.close()
                    return ofile
                except:
                    pass

            except:
                trace_error()

        return url
        return


def downloadImage(url = None):
    if os.path.exists('/tmp/TSmedia/dimage') == False:
        return url
    elif url is None or url.strip() == '':
        return ''
    else:
        if 'ExQ' in url:
            url.replace('ExQ', '=')
        if os.name == 'nt':
            path = 'd:\\tmp'
        else:
            path = '/tmp/TSmedia'
        if url and url.startswith('http'):
            try:
                filename = url.split('/')[-1]
                ofile = os.path.join(path, filename)
                if os.path.exists(ofile):
                    return ofile
                r = requests.get(url, timeout=0.5,verify=False)
                if r.status_code == 200:
                    with open(ofile, 'wb') as f:
                        f.write(r.content)
                    f.close()
                    return ofile
            except:
                trace_error()

        return url
        return


def getitems(regx, data):
    items = re.findall(regx, data, re.M | re.I)
    return items


def finditem(text, from_string, to_string, excluding = True):
    import re
    import string
    if excluding:
        try:
            r = re.search('(?i)' + from_string + '([\\S\\s]+?)' + to_string, text).group(1)
        except:
            r = ''

    else:
        try:
            r = re.search('(?i)(' + from_string + '[\\S\\s]+?' + to_string + ')', text).group(1)
        except:
            r = ''

    return r


def finditems(text, start_with, end_with):
    import re
    r = re.findall('(?i)(' + start_with + '[\\S\\s]+?' + end_with + ')', text)
    return r


def removeunicode(data):
    try:
        try:
            data = data.encode('utf', 'ignore')
        except:
            pass

        data = data.decode('unicode_escape').encode('ascii', 'replace').replace('?', '').strip()
    except:
        pass

    return data


def readhttps(url):


    list1 = []
    try:
        req = urllib2.Request(url)
        try:
            response = urllib2.urlopen(req, context=ssl._create_unverified_context())
        except:
            response = urllib2.urlopen(req)

        data = response.read()
        response.close()
        return data
    except urllib2.URLError as e:
        trace_error()
        if hasattr(e, 'code'):
            print 'We failed with error code - %s.' % e.code
            if '401' in str(e.code):
                trace_error()
                return None
            if '404' in str(e.code):
                trace_error()
                return None
            if '400' in str(e.code):
                trace_error()
                return None
            if '403' in str(e.code):
                trace_error()
                return None
        elif hasattr(e, 'reason'):
                trace_error()
                return None
        


def requestsurl(url):
    
    try:
        import requests
        session = requests.Session()
        USER_AGENT = 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
        session.headers.update({'User-Agent': USER_AGENT})
        return session.get(url, verify=False).content
    except:

     
                trace_error()
                return None


def readtrueurl(url):
    hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
     'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
     'Accept-Encoding': 'none',
     'Accept-Language': 'en-US,en;q=0.8',
     'Connection': 'keep-alive'}
    req = urllib2.Request(url, headers=hdr)
    page = urllib2.urlopen(req)
    url = page.geturl()
    return url


def logdata(label_name = '', data = None):
    try:
        data=str(data)
        data=data.replace('AxNxD', '&').replace('ExQ', '=')
        data = urllib.unquote_plus(data)   
        caller_name = getcaller_name()
        fp = open('/tmp/TSmedia_log', 'a')
        fp.write('\n' + caller_name + ':' + str(label_name) + ': ' + data)
        fp.close()
    except:
        pass
def deldata():
    try:
        if os.path.exists('/tmp/TSmedia/data.txt'):
            os.remove('/tmp/TSmedia/data.txt')
        if os.path.exists('/tmp/TSmedia_log'):
            os.remove('/tmp/TSmedia_log')

            
    except:
        pass

def getcaller_name():
    try:
        import inspect
        import os
        frame = inspect.currentframe()
        frame = frame.f_back.f_back
        code = frame.f_code
        calling_module = os.path.basename(code.co_filename)
        return calling_module
    except:
        return ''


def trace_error():
    import sys
    import traceback
    try:
        #traceback.print_exc(file=sys.stdout)
        if os.path.exists('/tmp/TSmedia_log'):
            logfile = '/tmp/TSmedia_log'
        else:
            return
        traceback.print_exc(file=open(logfile, 'a'))
    except:
        pass

def getData(url, data = {}, host = '', Referer = ''):
    import requests
    headers = {'Host': host,
     'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:56.0) Gecko/20100101 Firefox/56.0',
     'Accept': '*/*',
     'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
     'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
     'X-Requested-With': 'XMLHttpRequest',
     'Referer': Referer,
     'Connection': 'keep-alive'}
    s = requests.Session()
    r = s.get(url, headers=headers,verify=False)
    htmldata = r.content
    return htmldata


def postData(url, data, host, Referer):
    import requests
    headers = {'Host': host,
     'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:56.0) Gecko/20100101 Firefox/56.0',
     'Accept': '*/*',
     'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
     'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
     'X-Requested-With': 'XMLHttpRequest',
     'Referer': Referer,
     'Connection': 'keep-alive'}
    s = requests.Session()
    r = s.post(url, headers=headers, data=data,verify=False)
    htmldata = r.content
    return htmldata


def getItems(data, pattern, ignoreCase = False):
    if ignoreCase:
        match = re.findall(pattern, data, re.IGNORECASE)
    else:
        match = re.findall(pattern, data)
    return match


def getGroups(data, pattern, grupsNum = 1, ignoreCase = False):
    tab = []
    if ignoreCase:
        match = re.search(pattern, data, re.IGNORECASE)
    else:
        match = re.search(pattern, data)
    for idx in range(grupsNum):
        try:
            value = match.group(idx + 1)
        except:
            value = ''

        tab.append(value)

    return tab


def getBaseUrl(url):
    from urlparse import urlparse
    parsed_uri = urlparse(url)
    domain = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_uri)
    return domain

def getimage(server=None):
    
    if server is None:
       return plugin_path+"/interface/servers/server.png"
    image=plugin_path+"/interface/servers/"+server+".png"
    if os.path.exists(image):
         return image
    else:
         return plugin_path+"/interface/servers/server.png"
        
def getserver_image(server=None):
    
    if server is None:
       return plugin_path+"/interface/servers/server.png"
    image=plugin_path+"/interface/servers/"+server+".png"
    if os.path.exists(image):
         return image
    else:
         return plugin_path+"/interface/servers/server.png"
def getmainTitle():
    try:
        mtitle=open("/tmp/TSmedia/mtitle").read()
        return mtitle
    except:
        return ''
def playlink(item,name,url):
    
    addDir=item.addDir
    endDir=item.endDir    
  
    if name=='':
           name='play'
    if "plugin.youtube" in url:
        stream_link=get_youtube_link(url)
    else:
        stream_link=get_youtube_link(url)
    logdata('stream_link',stream_link)
    logdata('type(stream_link)',type(stream_link))

 

    if stream_link.startswith("Error"):
       addDir(stream_url,stream_link,-1,"",name,1)
       return
        
    if stream_link==None :
        addDir("Error:invalid stream_link","Error:invalid stream_link",-1,"",name,1)
        return
              
    maintitle=getmainTitle()
    name=name+"*-*"+maintitle
    addDir(name,stream_link,0,'',name,1,link=True)
    	       
def resolvehost(item,name,url):
    
    addDir=item.addDir
    endDir=item.endDir    
    from urlresolver import resolve
    if name=='':
           name='play'
    if "youtube" in url:
        stream_link=get_youtube_link(url)
    else:    
        stream_link = resolve(url)
    logdata('stream_link',stream_link)
    logdata('type(stream_link)',type(stream_link))

    if stream_link and type(stream_link)==type([]):
       logdata('stream_link2',stream_link) 
       for item in stream_link:

           maintitle=getmainTitle()
           name=item[0]+"*-*"+maintitle
           addDir(name,item[1],0,"",name,1,link=True)
       return  

    if stream_link.startswith("Error"):
       addDir(stream_link,stream_link,-1,"",name,1)
       return
        
    if stream_link==None :
        addDir("Error:invalid stream_link","Error:invalid stream_link",-1,"",name,1)
        return
    maintitle=getmainTitle()
    name=name+"*-*"+maintitle             
    
    addDir(name,stream_link,0,'',name,1,link=True)
    	    
    
def readnet(url,start=None,end=None,split=None,cloudflare=False,http=False):

    
    if cloudflare or http==True:
        from core.httptools import downloadpage
        data= downloadpage(url,bypass_cloudflare=cloudflare).data
       
       
       

        

    else:
        data=getnet(url)
    if not data:
        return None
    
 
    
    if start and end:
        data=extractdata(data,start,end)
    if split:
        try:
            blocks=data.split(split)
            if blocks[0]==data:
              
               return None
            
        except:
            trace_error()
            
            blocks=[]
        return blocks
    return data    


def getnet(url):
    try:
        from addon.common.net import Net
        net = Net()
        USER_AGENT = 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
        MAX_TRIES = 3
        headers = {'User-Agent': USER_AGENT,
         'Referer': url}
        data = net.http_GET(url).content
        try:data=data.encode('utf-8',"ignore")
        except:pass
        if not data:
            return None
    
      
        return data
    except:
        trace_error()
        return None

    return None


def postnet(url, data, referer):
    try:
        from addon.common.net import Net
        net = Net()
        USER_AGENT = 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:30.0) Gecko/20100101 Firefox/30.0'
        MAX_TRIES = 3
        headers = {'User-Agent': USER_AGENT,
         'Referer': referer}
        html = net.http_POST(url, form_data=data, headers=headers).content
        return html
    except:
        trace_error()


def readurl(url):
 
    try:
        req = urllib2.Request(url)
        response = urllib2.urlopen(req)
        data = response.read()
        response.close()
        return data
    except urllib2.URLError as e:
        if hasattr(e, 'code'):
            print 'We failed with error code - %s.' % e.code
            trace_error()
            return None
        elif hasattr(e, 'reason'):
            print 'We failed to reach a server.'
            trace_error()
            return None

        return endDir()
def trueUrl(site):
    hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
     'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
     'Accept-Encoding': 'none',
     'Accept-Language': 'en-US,en;q=0.8',
     'Connection': 'keep-alive'}
    req = urllib2.Request(site, headers=hdr)
    page = urllib2.urlopen(req)
    url = page.geturl()
    return url


def readurlwithhost(url, host):
    try:
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        req.add_header('Host', host)
        req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
        req.add_header('Cookie', 'popNum=8; __atuvc=6%7C34%2C3%7C35; popundr=1; PHPSESSID=478ff84e532ad811df5d63854f4f0fe1; watched_video_list=MTgzNDY%3D')
        response = urllib2.urlopen(req)
        link = response.read()
        return link
    except Exception:
            trace_error()
            return None

def getsearchtext(marker = '+'):
        import os
        if os.path.exists('/tmp/TSmedia/xbmc_search.txt'):
            file = open('/tmp/TSmedia/xbmc_search.txt', 'r')
            sstr = file.read().replace(' ', marker)
            file.close()
        else:
            sstr = None
        return sstr
    
   


def removebbcode(incomingString):
    try:
        import bbcode
        parser = bbcode.Parser()
        code = incomingString
        plain_txt = parser.strip(code)
        return plain_txt
    except:
        return incomingString


def supported(hostname):
    from urlresolver import supported
    try:answer=supported(hostname)
    except:answer=True
    return answer





def cfresolve(url_page = None):
    
    if url_page:
        from core import  httptools
        data = httptools.downloadpage(url_page).data
        return data


def parsedata(data, regx):
    try:
        match_list = re.findall(regx, data, re.M | re.I)
        return match_list
    except:
        return []


def cleanhtml(raw_html):
    cleanr = re.compile('<.*?>')
    cleantext = re.sub(cleanr, '', raw_html)
    return cleantext


def getDomain(url):
    tmp = re.compile('//(.+?)/').findall(url)
    domain = 'server'
    if len(tmp) > 0:
        domain = tmp[0].replace('www.', '')
    if 'google' in domain:
        domain = 'google'
    if '.' in domain:
        domain = domain.split('.')[0]
    issupported=supported(domain)
    image=getserver_image(domain)
    return domain,image,issupported


def GetDomain(url):
    tmp = re.compile('//(.+?)/').findall(url)
    domain = 'server'
    if len(tmp) > 0:
        domain = tmp[0].replace('www.', '')
    if '.' in domain:
        domain = domain.split('.')[0]
    
    return domain


def getwebfilesize(link):
    try:
        site = urllib.urlopen(link)
        meta = site.info()
        pagesize = int(float(meta.getheaders('Content-Length')[0]) / 1048576)
        return str(pagesize) + 'MB'
    except:
        return ''


def traceerror():
    import sys
    import traceback
    traceback.print_exc(file=sys.stdout)


def gethostname(url):
    try:
        from urlparse import parse_qs, urlparse
        query = urlparse(url)
        hostname = query.hostname
        hostname = hostname.replace('www.', '')
        hostname = hostname.replace('.com', '')
        hostname = hostname.replace('.net', '')
        if 'google' in hostname:
            hostname = 'google'
        if '.' in hostname:
            hostname = hostname.split('.')[0]
        return hostname
    except:
        return url


def finddata(data, marker1, marker2, withMarkers = False, caseSensitive = True):
    if caseSensitive:
        idx1 = data.find(marker1)
    else:
        idx1 = data.lower().find(marker1.lower())
    if -1 == idx1:
        return ''
    if caseSensitive:
        idx2 = data.find(marker2, idx1 + len(marker1))
    else:
        idx2 = data.lower().find(marker2.lower(), idx1 + len(marker1))
    if -1 == idx2:
        return ''
    if withMarkers:
        idx2 = idx2 + len(marker2)
    else:
        idx1 = idx1 + len(marker1)
    return data[idx1:idx2]


class cParser:

    def parseSingleResult(self, sHtmlContent, sPattern):
        aMatches = re.compile(sPattern).findall(sHtmlContent)
        if len(aMatches) == 1:
            aMatches[0] = self.__replaceSpecialCharacters(aMatches[0])
            return (True, aMatches[0])
        return (False, aMatches)

    def __replaceSpecialCharacters(self, sString):
        return sString.replace('\\/', '/').replace('&amp;', '&').replace('\xc9', 'E').replace('&#8211;', '-').replace('&#038;', '&').replace('&rsquo;', "'").replace('\r', '').replace('\n', '').replace('\t', '').replace('&#039;', "'")

    def parse(self, sHtmlContent, sPattern, iMinFoundValue = 1):
        sHtmlContent = self.__replaceSpecialCharacters(str(sHtmlContent))
        aMatches = re.compile(sPattern, re.IGNORECASE).findall(sHtmlContent)
        if len(aMatches) >= iMinFoundValue:
            return (True, aMatches)
        return (False, aMatches)

    def replace(self, sPattern, sReplaceString, sValue):
        return re.sub(sPattern, sReplaceString, sValue)

    def escape(self, sValue):
        return re.escape(sValue)

    def getNumberFromString(self, sValue):
        sPattern = '\\d+'
        aMatches = re.findall(sPattern, sValue)
        if len(aMatches) > 0:
            return aMatches[0]
        return 0


def addDirectoryItem(name, url,image,desc,section):
    if '|' in url:
        url = url.split('|')[0]
    url = url.replace('&', 'AxNxD')
    url = url.replace('=', 'ExQ')


    data =str({'name':name,'url':url,'image':image,'desc':desc,'section':section})
    file = open('/tmp/TSmedia/data.txt', 'a')
    file.write(data + '\n')
    file.close()
    return

class Item(object):
    def __init__(self):

        self.list=[]
        self.spath=sys.argv[0]
        #self.__dict__ = self.toutf8(self.__dict__)
    def addDir(self,name, url, mode, image,section='',page=1,maintitle = False,desc='',show='', extra='', plugin = None, link = False, searchall = None):
            section=str(section)   
            if mode==0:
                link=True
            if url.startswith('plugin://plugin.video.youtube') or 'youtube.com' in url:
                link=True
            try:             
                name = name.encode('utf-8', 'ingnore')
                section = section.encode('utf-8', 'ingnore')
                desc = desc.encode('utf-8', 'ingnore')

                if ";" in name :
                          name=cleanparam(name)                 
                if ";" in section :
                          section=cleanparam(section)
                if ";" in desc :
                          desc=cleanparam(desc)
                
                
            except:
                pass


            if plugin is not None:
                path = self.spath.replace('/default.py', '')
                spath = os.path.split(path)[0] + '/' + plugin + '/default.py'
            if image and image.lower().startswith("img"):
                image=os.path.split(self.spath)[0]+"/"+image
            mtitle=''
            if link==True :

                
                if image is None or image=='':
                  image=plugin_path+"/interface/servers/play.png"
                elif "play.png" in image:
                     image=plugin_path+"/interface/servers/play.png"
                else:
                     image=plugin_path+"/interface/servers/play.png"
            if image.strip()=='':
                image=os.path.split(self.spath)[0]+"/icon.png"

            if not image.startswith("http") and os.path.exists(image)==False:
                image=os.path.split(self.spath)[0]+"/icon.png"
                
            maintitle=str(maintitle)     
            link=str(link)


            if link=='True' or mode==-1:
                      u=url
            else: 
                      u = self.spath + '?url=' + urllib.quote_plus(url) + '&mode=' + str(mode) + '&name=' + urllib.quote_plus(name) + "&" + "image="+image+'&page=' + str(page) + '&desc=' + urllib.quote_plus(desc)+ '&section=' + urllib.quote_plus(section)+'&maintitle=' + maintitle + '&extra=' + urllib.quote_plus(extra)+ '&show=' + urllib.quote_plus(show)
        


            if 'm3u8' in url and not name == 'm3u8_0':
                try:
                    from m3u8player import getm3u8playlist
                    list = getm3u8playlist(url)
                    for item in list:
                        url = str(item[1])
                        title = str(item[0])+"-"+ name
                        image = item[2]
                        try:             
                            title = name+"_"+title.encode('utf-8', 'ingnore')
                           
                        except:
                            pass

                        
                       # u = self.spath + '?url=' + urllib.quote_plus(url) + '&mode=' + str(mode) + '&name=' + urllib.quote_plus(name) + "&" + "image="+image+'&page=' + str(page) + '&desc=' + urllib.quote_plus(desc)+ '&section=' + urllib.quote_plus(section)+'&maintitle=' + maintitle+ '&extra=' + urllib.quote_plus(extra)+ '&link=True' 

                        
                        self.addDirectoryItem(title,url,image,desc,section,maintitle)

                    return
                except:
                        self.addDirectoryItem(name,url,image,desc,section,maintitle)
                        return


            if searchall is not None:
                try:
                    dirname = os.path.split(searchall)[0]
                    plugin_name = os.path.basename(dirname)
                    search_file = searchall.replace('default.pyc', 'searchall').replace('default.pyo', 'searchall').replace('default.py', 'searchall')
                    afile = open(search_file, 'w')
                    afile.write(plugin_name + ';;' + u)
                    afile.close()
                except:
                    pass
            
            ok = self.addDirectoryItem(name,u,image,desc,section,maintitle)
            return ok
    def addDir_tube(self,name, url, mode, iconimage, desc = '', page = '', link = False,section='',maintitle=False):
        
        if not page == '':
            u = sys.argv[0] + '?url=' + urllib.quote_plus(url) + '&mode=' + str(mode) + '&name=' + urllib.quote_plus(name) + '&desc=' + urllib.quote_plus(desc) + '&pageToken=' + str(page)
        else:
            u = sys.argv[0] + '?url=' + urllib.quote_plus(url) + '&mode=' + str(mode) + '&name=' + urllib.quote_plus(name) + '&desc=' + urllib.quote_plus(desc) + '&pageToken='
        ok = True
        if link == True:
            u = url
        maintitle=str(maintitle)     
        ok = self.addDirectoryItem(name,u,iconimage,desc,section,maintitle)
        return ok
    def addDirectoryItem(self,name, url,image,desc,section,maintitle):
           if '|' in url:
            url = url.split('|')[0]

           
            
           url = url.replace("&", "AxNxD")
           url = url.replace("=", "ExQ")
           #data = "&url=" + url
           
           
           self.list.append((name,url,image,desc,section,maintitle))
           

    def endDir(self):
            developer_mode=getdeveloper_mode()
            mylist = self.list
            if len(self.list)<1:
                return
            try:searchmode=sys.argv[3]
            except:searchmode=''
            if searchmode=="searchall":
                file = open(datasearch_file, "a")
                for item in self.list:

                    
                    #params=self.get_params(item)
                    data =str({'name':item[0],'url':item[1],'image':item[2],'desc':item[3],'section':item[4],'maintitle':item[5]})
                  
                    file.write(data+"\n")
                file.close()
            elif developer_mode==True:
                file = open(data_file, "w")
                for item in self.list:

                    
                    #params=self.get_params(item)
                    data =str({'name':item[0],'url':item[1],'image':item[2],'desc':item[3],'section':item[4],'maintitle':item[5]})
                  
                    file.write(data+"\n")
                file.close()    

                
            else:
                pass

            
            list1=self.list
            self.list=[]
            del self
            return list1
            
    def ListItem(self,name,  iconImage=None, thumbnailImage="DefaultFolder.png"):##for wTSmedia

              if (".jpg" not in thumbnailImage.lower() ) and (".png" not in thumbnailImage.lower()) and (".jpeg" not in thumbnailImage.lower()):
                      thumbnailImage = "DefaultFolder.png"
              
              if thumbnailImage is not None:
                      thumbnailImage = thumbnailImage.replace(" ", "-")
                      thumbnailImage = thumbnailImage.replace("&", "AxNxD")
                      thumbnailImage = thumbnailImage.replace("=", "ExQ")

                 
              
              data = "name=" + str(name) + "&thumbnailImage=" + str(thumbnailImage)
 
              
             
              self.list.append(data)


        
    def get_params(self,item):
        params = {}
        item = item.replace('AxNxD', '&').replace('ExQ', '=')
        paramstring = item
        if len(paramstring) >= 2:
            
            cleanedparams = paramstring.replace('?', '&')

            pairsofparams = cleanedparams.split('&')
            
            for i in range(len(pairsofparams)):
                splitparams = {}
                splitparams = pairsofparams[i].split('=')
                if len(splitparams) == 2:
                    p=splitparams[1]  
                    if isinstance(splitparams[1], basestring) :
                        p=urllib.unquote_plus(splitparams[1])
                    
                           
                    params[splitparams[0]] = p
        return params            

           
def addDir(name, url, mode, image, section = '', page = 0, maintitle = False,desc='', plugin = None, link = False, searchall = None,extra=''):
    spath = sys.argv[0]
    desc=str(desc)
    extra=str(extra)
    section=str(section)
    try:
        name = name.encode('utf-8', 'ingnore')
        section = section.encode('utf-8', 'ingnore')
        desc = desc.encode('utf-8', 'ingnore')
        if ";" in name :
                  name=cleanparam(name)                 
        if ";" in section :
                  section=cleanparam(section)
        if ";" in desc :
                  desc=cleanparam(desc)        
    except:
        pass


    if plugin is not None:
        path = spath.replace('/default.py', '')
        spath = os.path.split(path)[0] + '/' + plugin + '/default.py'
    if image and image.lower().startswith("img"):
        image=os.path.split(spath)[0]+"/"+image
    if maintitle:
                 try:
                   ftitle=open("/tmp/TSmedia/mtitle","w")
                   ftitle.write(name)
                   ftitle.close()
                 except:
                     pass

        
    mtitle=''
    if link==True:
        if os.path.exists("/tmp/TSmedia/mtitle"):
           mtitle=open("/tmp/TSmedia/mtitle").read()
           name=name+"-"+mtitle
        
           if image is None or image=='':
              image=plugin_path+"/interface/servers/play.png"
           elif "play.png" in image:
                 image=plugin_path+"/interface/servers/play.png"
           else:
                 image=plugin_path+"/interface/servers/play.png"

    if image.strip()=='':
                image=os.path.split(spath)[0]+"/icon.png"        
    if not image.startswith("http") and  os.path.exists(image)==False:
               image= os.path.split(spath)[0]+"/icon.png"

        
    maintitle=str(maintitle)     
    link=str(link)
    try:
        desc = desc.encode('utf-8', 'ingnore')
    except:
        pass
    try:
        section = section.encode('utf-8', 'ingnore')
    except:
        pass
    if link=='True':
        u=url
    else:    
        u = spath + '?url=' + urllib.quote_plus(url) + '&mode=' + str(mode) + '&name=' + urllib.quote_plus(name) + "&" + "image="+image+'&page=' + str(page) + '&desc=' + urllib.quote_plus(desc)+ '&section=' + urllib.quote_plus(section)+'&maintitle=' + maintitle+ '&extra=' + urllib.quote_plus(extra)



    if 'm3u8' in url and not name == 'm3u8_0':
        try:
            from m3u8player import getm3u8playlist
            list = getm3u8playlist(url)
            for item in list:
                url = str(item[1])
                title = str(item[0])+"-"+ name
                image = item[2]
                
                #u = spath + '?url=' + urllib.quote_plus(url) + '&mode=' + str(mode) + '&name=' + urllib.quote_plus(name) + "&" + "image="+image+'&page=' + str(page) + '&desc=' + urllib.quote_plus(desc)+ '&section=' + urllib.quote_plus(section)+'&maintitle=' + maintitle+ '&extra=' + urllib.quote_plus(extra)+ '&link=True' 

                
                addDirectoryItem(name+"_"+title,url,image,desc,section)

            return
        except:
                addDirectoryItem(name,url,image,desc,section)
                return


    if searchall is not None:
        try:
            dirname = os.path.split(searchall)[0]
            plugin_name = os.path.basename(dirname)
            search_file = searchall.replace('default.pyc', 'searchall').replace('default.pyo', 'searchall').replace('default.py', 'searchall')
            afile = open(search_file, 'w')
            afile.write(plugin_name + ';;' + u)
            afile.close()
        except:
            pass

    ok = addDirectoryItem(name,u,image,desc,section)
    return ok





def get_params():
        params = {}
        item=sys.argv[2]
        item = item.replace('AxNxD', '&').replace('ExQ', '=')
        paramstring = item
        if len(paramstring) >= 2:
            
            cleanedparams = paramstring.replace('?', '&')

            pairsofparams = cleanedparams.split('&')
            
            for i in range(len(pairsofparams)):
                splitparams = {}
                splitparams = pairsofparams[i].split('=')
                if len(splitparams) == 2:
                    p=splitparams[1]  
                    if isinstance(splitparams[1], basestring) :
                        p=urllib.unquote_plus(splitparams[1])
                    
                           
                    params[splitparams[0]] = p
        return params            

