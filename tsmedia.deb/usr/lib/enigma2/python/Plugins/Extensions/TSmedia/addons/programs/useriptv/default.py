

# 2014.09.14 17:37:13 Arabic Standard Time
#Embedded file name: /media/hdd/Extensions/TSmedia/addons/iptv/plugin.video.userm3uplayer/default.py
from xbmctools import Item,readnet,supported,get_params,getDomain,getserver_image,resolvehost,playlink
item=Item()
addDir=item.addDir
endDir=item.endDir
import sys
import urllib, urllib2, re,  sys ,os

from httplib import HTTP
from urlparse import urlparse
import StringIO
import httplib
PLUGIN_PATH = '/usr/lib/enigma2/python/Plugins/Extensions/TSmedia'
dlocation_file=PLUGIN_PATH+"/lib/defaults/download_location"
try:
  iptv_folder=open(dlocation_file).read()
except:
  iptv_folder="/media/hdd"

iptv_folder = iptv_folder+"/TSmedia/iptv/"

if not os.path.exists(iptv_folder):
  try:os.makedirs(iptv_folder)
  except:pass




def fixlink(url):
    try:
        url = url.replace('rtmp://$OPT:rtmp-raw=', '')
        url = url.replace('<swfUrl>', ' swfUrl=').replace('<pageUrl>', ' pageUrl=').replace('<live>', ' live=').replace('<playpath>', ' playpath=').replace('<playpath>', ' playpath=').replace('<object encoding>', '').replace('rtmp://$OPT:rtmp-raw=', '').strip()
    except:
        pass

    return url


def getuserlist():
    folder = iptv_folder
    files = []
    fullpath = []
    user_iptv_file = iptv_folder+"/iptvlist"
    if os.path.exists(user_iptv_file):
        f = open(user_iptv_file, 'r')
        lines = f.readlines()
        for line in lines:
            line = line.strip()
            if line.startswith('m3u'):
                parts = line.split(';')
                itemtype = parts[0]
                itempath = parts[2]
                itemname = parts[1]
                try:
                    urllib.urlretrieve(itempath, folder + itemname + '.m3u')
                except:
                    pass
            if line.startswith('iptv'):
                parts = line.split(';')
                itemtype = parts[0]
                itempath = parts[2]
                itemname = parts[1]
                addDir(itemname, itempath, 6, 'img/iptv.png','',1)                 

    if os.path.exists(folder):
        emptyfolder=True
        for item in os.listdir(folder):
            itempath = folder + item
        
            if os.path.isfile(itempath):
                if item.endswith('.m3u'):
                    itemname = item.replace('.m3u', '')
                    addDir(itemname, itempath, 1, 'img/m3u.png','',1)
                    emptyfolder=False
        if emptyfolder==True:
           addDir("No m3u file in " +iptv_folder, '', '', '')

def getm3u(url, regx):
    list1 = []
    err = 'none'
    done = True
    try:
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        try:
            response = urllib2.urlopen(req)
        except:
            return ('error', list1)

        data = response.read()
        match = re.findall(regx, data, re.S)
        for href, title in match:
            if 'Parent Directory' not in title:
                furl = url + href
                title = title.replace('.m3u', '')
                if config.TSmedia.pornmedia.value == 'no':
                    if 'adult' in title or 'xx' in title or 'sex' in title or '+18' in title:
                        continue
                if furl.strip().endswith('.m3u'):
                    if 'rtmp' in furl:
                        furl = fixlink(furl)
                    list1.append((title, furl))

    except:
        err = 'downnload or parsing error'
        list1 = []

    return (err, list1)


def getmu3info(m3ufile):
    if m3ufile.find('m3u') > -1:
        done = True
        try:
            myfile = open(m3ufile, 'r').read()
            regex = re.findall('#EXTINF.*,(.*\\s)\\s*(.*)', myfile)
            if not len(regex) > 0:
                regex = re.findall('((.*.+)(.*))', myfile)
            ts = ''
            chan_counter = 0
            video_list_temp = []
            for text in regex:
                title = text[0].strip()
                url = text[1].strip()
                chan_counter += 1
                if 'rtmp' in url:
                    url = fixlink(url)
                addDir(title, url, 0, '','',1,True)

        except:
            return ('Error reading m3u file', [])

        print 'mah121', video_list_temp
        return ('none', video_list_temp)


def getmu3links(url):
    if url.find('m3u') > -1:
        try:
            req = urllib2.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
            response = urllib2.urlopen(req)
            data = response.read()
            regex = re.findall('#EXTINF.*,(.*\\s)\\s*(.*)', data)
            if not len(regex) > 0:
                regex = re.findall('((.*.+)(.*))', data)
            ts = ''
            chan_counter = 0
            video_list_temp = []
            for text in regex:
                title = text[0].strip()
                if config.TSmedia.pornmedia.value == 'no':
                    if 'adult' in title or 'xx' in title or 'sex' in title:
                        continue
                url = text[1].strip()
                chan_counter += 1
                chan_tulpe = (chan_counter,
                 title,
                 '',
                 'tv.png',
                 url,
                 None,
                 None,
                 '',
                 '',
                 None,
                 ts)
                video_list_temp.append(chan_tulpe)
                if len(video_list_temp) < 1:
                    return ('No channels found', [])

        except:
            return ('Error reading m3u file', [])

        return ('none', video_list_temp)
    else:
        return





def start():  
        params=get_params()
        url=None
        name=None
        mode=None
        page=1


        name=params.get("name",None)
        url=params.get("url",None)
        try:mode=int(params.get("mode",None))
        except:mode=None
        image=params.get("image",None)
        section=params.get("section",None)
        page=int(params.get("page",1))
        extra=params.get("extra",None)
        show=params.get("show",None)





        print "Mode1: "+str(mode)
        print "URL: "+str(url)
        print "Name: "+str(name)
        print "Image: "+str(image)
        print "page: "+str(page)
        print "section: "+str(section)
        print "show: "+str(show)
        print "extra: "+str(extra)
        ##menu and tools
        if mode==None == None or url == None or len(url) < 1:
            print ''
            getuserlist()
        elif mode == 1:
            print '' + url
            getmu3info(url)
        elif mode == 2:
            print '' + url
            get_play_link(name, url, page)
        elif mode == 3:
            print '' + url
            playContent(url)
        
        elif mode == 6:
           
            playlink(url)
        return endDir()
