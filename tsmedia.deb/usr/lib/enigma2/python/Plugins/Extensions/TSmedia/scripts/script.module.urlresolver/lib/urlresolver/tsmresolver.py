
import os, sys, urllib
from xbmctools import getDomain,finddata,getos,logdata

import os
module_path=os.path.split(__file__)[0]
default_mainserver='urlresolver'
forceresolve=True

def isvalidlink(link):
    if link is None:
        return False
    if  link.startswith("http") or  link.startswith("rtmp"):
        return True
    return False
def getmainserver(host):
       logdata("module_path",module_path)
       logdata("host",host)
       mainserver=''
       servers=open(module_path+"/servers.txt").readlines()
       if True:
             if getos()=='windows':
                plugin_path=module_path.split("wTSmedia")[0]+"wTSmedia"
                txt=open(plugin_path+"/scripts/script.module.urlresolver/lib/urlresolver/resolver.txt").read()
             else:
                plugin_path=module_path.split("TSmedia")[0]+"TSmedia"
                txt=open(plugin_path+"/scripts/script.module.urlresolver/lib/urlresolver/resolver.txt").read()
             
             assigned_mainserver=txt.strip()
             print 'assigned_mainserver2,host',assigned_mainserver,host
             urlresolver_host=False
             pelisresolver_host=False
            
             print "2",plugin_path+"/scripts/script.module.urlresolver/lib/urlresolver/servers/"+host+'.py'
             if os.path.exists(module_path+"/plugins/"+host+'.py')==True or os.path.exists(module_path+"/plguins/"+host+'.pyo')==True:
                 urlresolver_host=True    
             if os.path.exists(plugin_path+"/scripts/script.module.urlresolver/lib/urlresolver/servers/"+host+'.py')==True or os.path.exists(plugin_path+"/scripts/script.module.urlresolver/lib/urlresolver/servers/"+host+'.pyo')==True:

                 pelisresolver_host=True
                
             print 'assigned_mainserver',assigned_mainserver
             
            
             if assigned_mainserver=='urlresolver' and  urlresolver_host==True:
                 classname=getclass(host)
                 return "urlresolver",host,classname
             elif assigned_mainserver=='pelisresolver' and  pelisresolver_host==True:
                  return "pelisresolver",host,"get_url"
             elif assigned_mainserver=='urlresolver' and  urlresolver_host==False:
                  if pelisresolver_host==True:
                     
                     return "pelisresolver",host,"get_url"
                    
                  else:
                     return None,host,None 

                
             elif assigned_mainserver=='pelisresolver' and  pelisresolver_host==False:
                  if urlresolver_host==True:
                     classname=getclass(host)
                     return "urlresolver",host,classname
                    
                  else:
                     return None,host,None 
             else:
                 assigned_mainserver='auto'
                 
                 
                 for line in servers:

                       
                        
                       mainserver=None
                       
                       classname=None

                         
                       
                       if host in line:
                          
                         
                         mainserver,hostname,classname,update=line.split(";")
                         print 'mainserverxx,urlresolver_host,pelisresolver_host',mainserver,urlresolver_host,pelisresolver_host
                        
                         if mainserver=='urlresolver' and  urlresolver_host==True:
                             classname=getclass(host)
                             return "urlresolver",host,classname
                         elif mainserver=='pelisresolver' and  pelisresolver_host==True:
                              return "pelisresolver",host,"get_url"
                         elif mainserver=='urlresolver' and  urlresolver_host==False:
                              if pelisresolver_host==True:
                                 
                                 return "pelisresolver",host,"get_url"
                                
                              else:
                                 return None,host,None 

                            
                         elif mainserver=='pelisresolver' and  pelisresolver_host==False:
                              if urlresolver_host==True:
                                 classname=getclass(host)
                                 return "urlresolver",host,classname
                                
                              else:
                                 return None,host,None 

                          
                         if host.lower()==hostname.strip().lower():
                             
                            
                             return mainserver,host,classname
                 print "Error,host not available in servers list"          
                 return None,host,None



    
def logdata(label_name='', data=None):

    if os.name=="nt":
                logfile='TSmedia_log2'
    else:
                logfile='/tmp/TSmedia/TSmedia_log2'        
    try:

        caller_name=getcaller_name()
        fp = open(logfile, 'a')
        fp.write('\n' +caller_name+":"+ str(label_name) + ': ' + str(data))
        fp.close()
    except:
        try:
            data = 'error in writing data to the log'
            fp = open(logfile, 'a')
            fp.write('\n' + label_name + ': ' + str(data))
            fp.close()
        except:
            print 'error in loging data'
def getcaller_name():
    try:
        import inspect,os
        frame=inspect.currentframe()
        frame=frame.f_back.f_back
        code=frame.f_code
        calling_module=os.path.basename(code.co_filename)
        return calling_module
    except:
        return ""
            
def trace_error():
                  import sys,traceback
                  if os.name=="nt":
                                logfile='TSmedia_log'
                  else:
                                logfile='/tmp/TSmedia/TSmedia_log'   
                  
                  traceback.print_exc(file = sys.stdout)
                 
                 
                  traceback.print_exc(file=open(logfile,"a"))   

import urlresolver

def getclass(host):

        hostfile=module_path + "/plugins/" + host + ".py"
        if not os.path.exists(hostfile):
                return None
        lines =open(hostfile).readlines()
        for  line  in lines:
            if line.startswith("class") and "Resolver" in line:
                classname = line.split("(")[0].replace("class", "").strip()
                return classname
                
            
        return None
def get_host_id(host,url):

    import re
    
    hostfile=module_path + "/plugins/" + host + ".py"
    if not os.path.exists(hostfile):
                return None,None
    txt =open(hostfile).read()
    pattern =finddata(txt,"pattern = '","'")
    print "pattern",pattern
                   
    
    #pattern = '(?://|\.)(o(?:pen)??load\.(?:io|co|tv))/(?:embed|f)/([0-9a-zA-Z-_]+)'
    try:
        host,id = re.search(pattern, url).groups()
        
       
        return host,id
    except:
         return None,None
    


def get_linkid(web_url):
    parts = web_url.split('/')
    if parts:
        web_url = web_url.split('/')[len(parts) - 1]
    return web_url


def resolve(web_url = None, host = None, media_id = None, urllist = False,resolver=None):
    if host is None and web_url is not None:
        host,image,issupported = getDomain(web_url)
    else:
        print "No enough data"
        #addDir("Error:Error: -err1-no data supplied by the addon",-1,'',host,1)
        
        return "Error:Error: -err1-no data supplied by the addon"
        
    if 'googledrive' in web_url or 'google' in web_url:
            host= "googlevideo"              
    if 'nowvideo' in web_url:
            web_url=web_url.replace(".sx",".li")
            host= "nowvideo"    
        
    if 'streamin' in web_url:
            host= "streaminto"
    if 'ok.ru' in web_url:
            host= "yasokru"               
            
    if 'vimple' in web_url:
            host= "vimple"
    if 'docs' in web_url:
            host='googlevideo'
    if "uptostream" in web_url:
            host="uptobox"
    if "dailymotion" in web_url:
            host="dailymotion"
    if '9xplay' in web_url:
        host='ninexplay'
            
    stream_url = None
    done = True
    ###for debug

       
    ######
    try:
        host = host.lower()
    except:
        pass

    
    logdata("web_url",web_url)
    logdata("host",host)
    sys.argv.append(web_url)
    debug = True

    mainserver,host,classname=getmainserver(host)

    print 'mainserver3,host,classname',mainserver,host,classname
    host_module_urlresolver=module_path + "/plugins/" + host + ".py"
    if not os.path.exists(host_module_urlresolver):
        host_module_urlresolver=module_path + "/plugins/" + host + ".pyo"    
    plugin_path=module_path.split("wTSmedia")[0]+"wTSmedia"
    if getos()=='windows':
        plugin_path=module_path.split("wTSmedia")[0]+"wTSmedia"
        
    else:
        plugin_path=module_path.split("TSmedia")[0]+"TSmedia"
        

    host_module_pelisresolver=plugin_path + "/scripts/script.module.urlresolver/lib/urlresolver/servers/" + host + ".py"
    if not os.path.exists(host_module_pelisresolver):
        host_module_pelisresolver=plugin_path + "/scripts/script.module.urlresolver/lib/urlresolver/servers/" + host + ".pyo"
    

            

    if  mainserver is None:
            print "No resolving module for given host"
            #addDir("Error:No resolving module for given host","Error:-err2-No resolving module for given host",-1,"",host,1)
            
            return "Error:No resolving module for given host"         
    
    
    print 'mainserver,host,classname',mainserver,host,classname       
    if mainserver=='urlresolver':                             
                        
                        
                        txt='from urlresolver.plugins.'+host.strip()+" import " +classname.strip()+' as Resolver'
                        print "import text",txt
                        exec(txt)                 
                       
                        resolver = Resolver()
                        host,media_id=get_host_id(host,web_url)
                        print 'host,media_id',host,media_id
                        stream_url = resolver.get_media_url(host, media_id)

    if mainserver=='pelisresolver':
         
            
            
            exec('from urlresolver.servers.'+host.strip()+" import get_video_url")
            
            stream_url = get_video_url(web_url)
            if stream_url and type(stream_url)==type([]):
                print 'stream_urls',stream_url,len(stream_url)
                if len(stream_url)==0:
                   #addDir("Error:Link is not available",'"Error:link is not available"',-1,'img/play.png','',1)
                   
                   return "Error:Link is not available"
                list1=[]
                for item in stream_url:
                    if item[1].strip()=='':
                        continue
                    list1.append((item[0],item[1]))
                print "list1-tt",list1    
                return list1
                #stream_url=stream_url[0][1]
           
            if not stream_url:#added 16-6-2018
                   #addDir("Error:Link is not available",'"Error:Link is not available"',-1,'img/play.png','',1)
                   
                   return "Error:Link is not available"               

                  
              
           

   
       
    print "stream_url",stream_url                   
    if  type(stream_url)==type([]):
        if len(stream_url)==0:
                  # addDir("Error:Link is not available",'Error:Link is not available',-1,'img/play.png','',1)
                  
                   return "Error:Link is not available"
        list1=[]        
        for item in stream_url:
                    list1.append((item[0],item[1]))
                   
                    
        return list1
    if  isvalidlink(stream_url)==False:
                   stream_url = 'Error:Invalid stream link'         
    if '|' in stream_url:
        stream_url=stream_url.split("|")[0]
    if os.name=='nt':
        if not "Error" in stream_url:
           saveasexample(web_url,mainserver,success=True)
        else:
           saveasexample(web_url,mainserver,success=False) 
    return stream_url
    
def saveasexample(web_url,servername,success=True):
                     
               if True:
                           try:lines=open(module_path+"/examples").readlines()
                           except:lines=[]
                           exists=False
                           for line in lines:
                               parts=line.split(";")
                               if web_url==parts[0] and servername==parts[1]:
                                  exists=True
                                  break
                           if exists==False:
                               afile=open(module_path+"/examples","a")
                               afile.write("\n"+web_url+";"+servername+";"+str(success))
                               afile.close()
               else:
                           pass      
