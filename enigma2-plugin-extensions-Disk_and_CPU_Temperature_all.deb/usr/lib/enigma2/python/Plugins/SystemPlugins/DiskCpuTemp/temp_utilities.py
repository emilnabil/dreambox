# -*- coding: utf-8 -*-
from __future__ import print_function, division
import os
import subprocess
import re
import time

# Try to import real gRGB from enigma (used by Enigma2 UI). If not available, enigma_gRGB will be None.
try:
    from enigma import gRGB as enigma_gRGB
except Exception:
    enigma_gRGB = None

# Fallback dummy gRGB (kept for non-Enigma testing environments).
def gRGB(r, g, b): return (r, g, b)

# Global variables
log_file = "/tmp/diskcputemp.log"

# HDD Warning thresholds
HDD_FIRST_WARNING_TEMP = 45
HDD_SECOND_WARNING_TEMP = 50
HDD_FINAL_WARNING_TEMP = 55

# CPU Warning thresholds
CPU_FIRST_WARNING_TEMP = 75
CPU_SECOND_WARNING_TEMP = 80
CPU_FINAL_WARNING_TEMP = 85

# Warning system variables
warning_active = False
warning_level = {"CPU": 0, "/dev/sda": 0, "/dev/sdb": 0, "/dev/sdc": 0}
warning_timer = None
warnings_enabled = True  # Global variable to control warning display

# ==== Logging ====
def log_message(message):
    """Write message to log file with timestamp"""
    try:
        with open(log_file, "a") as f:
            timestamp = time.strftime("%H:%M:%S")
            f.write("[%s] %s\n" % (timestamp, message))
    except:
        pass

def clear_log():
    """Clear the log file"""
    try:
        with open(log_file, "w") as f:
            f.write("")
        log_message("Log file cleared")
    except:
        pass

# ==== Temperature parsing ====
def extract_temperature_value(temp_string):
    """Extract numeric temperature value from string, handling various formats"""
    try:
        if temp_string is None:
            return None
        if "N/A" in str(temp_string):
            return None

        # Try to extract temperature value using multiple patterns
        patterns = [
            r'(\d+(?:\.\d+)?)\s*C',           # 45 C or 45.5 C
            r'Temperature[^:]*:\s*(\d+)',     # Temperature: 45
            r'(\d+)$',                        # Just a number at the end
        ]

        for pattern in patterns:
            match = re.search(pattern, str(temp_string), re.IGNORECASE)
            if match:
                try:
                    return float(match.group(1))
                except:
                    return None

        return None
    except:
        return None

# ==== Color mapping ====
def temp_to_color(temp, device_type="CPU"):
    """
    Return a color corresponding to temperature.
    This function now returns a real enigma.gRGB object when available,
    otherwise it returns the fallback tuple via the local gRGB function.
    """
    try:
        # Extract numeric temperature
        temp_value = extract_temperature_value(temp)
        if temp_value is None:
            return enigma_gRGB(255, 255, 255) if enigma_gRGB else gRGB(255, 255, 255)
    except:
        return enigma_gRGB(255, 255, 255) if enigma_gRGB else gRGB(255, 255, 255)

    # Set ranges based on device type
    if device_type == "CPU":
        min_temp, max_temp = 30.0, 85.0
    else:
        min_temp, max_temp = 25.0, 55.0

    # Clamp value
    temp_value = max(min_temp, min(temp_value, max_temp))
    norm = (temp_value - min_temp) / (max_temp - min_temp)

    # Simplified color gradient calculation
    color_ranges = [
        (0.0, 0.2, (0, 0, 255)),      # Blue
        (0.2, 0.4, (0, 255, 255)),    # Sky blue
        (0.4, 0.6, (0, 255, 0)),      # Green
        (0.6, 0.8, (255, 255, 0)),    # Yellow
        (0.8, 1.0, (255, 0, 0))       # Red
    ]

    r = g = b = 255
    for start, end, (rr, gg, bb) in color_ranges:
        if start <= norm <= end:
            ratio = (norm - start) / (end - start) if end != start else 0
            # Interpolate between colors (approximate)
            if start == 0.0:  # Blue to Sky blue
                r, g, b = 0, int(255 * ratio), 255
            elif start == 0.2:  # Sky blue to Green
                r, g, b = 0, 255, int(255 * (1 - ratio))
            elif start == 0.4:  # Green to Yellow
                r, g, b = int(255 * ratio), 255, 0
            elif start == 0.6:  # Yellow to Orange
                r, g, b = 255, int(255 * (1 - ratio) + 165 * ratio), 0
            else:  # Orange to Red
                r, g, b = 255, int(165 * (1 - ratio)), 0
            break

    # ===== lighten colors towards white =====
    lighten = 180  # lighten value
    r = min(255, r + lighten)
    g = min(255, g + lighten)
    b = min(255, b + lighten)

    # Return actual gRGB object for Enigma2 if available, otherwise fallback tuple
    if enigma_gRGB:
        try:
            return enigma_gRGB(r, g, b)
        except Exception:
            # last-resort: fallback tuple
            return gRGB(r, g, b)
    else:
        return gRGB(r, g, b)

def check_temperature_warnings(device_type, device_name, temperature):
    """
    device_type: "CPU" or "HDD" or "SSD" or "NVMe"
    device_name: "CPU" or "/dev/sda" or "/dev/sdb" or "/dev/sdc"
    temperature: string like "45 C" or "N/A"
    """
    global warning_active, warning_level, warnings_enabled

    # Check if warnings are enabled
    if not warnings_enabled:
        return

    try:
        # Extract numeric temperature value
        temp_value = extract_temperature_value(temperature)
        if temp_value is None:
            return

        # Filter out unrealistic HDD/SSD temperatures (above 100 C)
        if device_type in ("HDD", "SSD", "NVMe") and temp_value > 100:
            log_message("Ignoring unrealistic storage temperature: %s (%s)" % (temperature, device_name))
            return

        # Check warning levels CPU or HDD
        if device_type == "CPU":
            first, second, final = CPU_FIRST_WARNING_TEMP, CPU_SECOND_WARNING_TEMP, CPU_FINAL_WARNING_TEMP
        else:
            first, second, final = HDD_FIRST_WARNING_TEMP, HDD_SECOND_WARNING_TEMP, HDD_FINAL_WARNING_TEMP

        # Ensure key exists in warning_level
        if device_name not in warning_level:
            warning_level[device_name] = 0

        # Check warning levels
        if temp_value >= final and warning_level[device_name] < 3:
            show_warning(device_name, 3, temp_value)
            warning_level[device_name] = 3
        elif temp_value >= second and warning_level[device_name] < 2:
            show_warning(device_name, 2, temp_value)
            warning_level[device_name] = 2
        elif temp_value >= first and warning_level[device_name] < 1:
            show_warning(device_name, 1, temp_value)
            warning_level[device_name] = 1
        elif temp_value < first and warning_level[device_name] > 0:
            # Temperature returned to normal, clear warning
            warning_level[device_name] = 0
            clear_warning_bar(device_name)
            log_message("Temperature normalized for %s" % device_name)
            # If there is no longer a warning for any device, clear the displayed warning.
            if all(level == 0 for level in warning_level.values()):
                try:
                    from plugin import DiskCpuTempScreen
                    if DiskCpuTempScreen.instance:
                        DiskCpuTempScreen.instance.clear_warning_bar()
                except:
                    pass

    except Exception as e:
        log_message("Exception in check_temperature_warnings: %s" % str(e))

def show_warning(device_name, level, temperature_value):
    """Display warning message on screen"""
    global warning_active, warning_timer, warnings_enabled

    # Check if warnings are enabled
    if not warnings_enabled:
        return

    # Get warning duration from configuration
    try:
        from plugin import config
        warning_duration = int(config.plugins.DiskCpuTemp.warning_duration.value)
        timeout_seconds = warning_duration / 1000  # Convert to seconds for MessageBox
    except Exception:
        warning_duration = 5000
        timeout_seconds = 5

    # Determine which Device is causing the warning (display name)
    display_name = device_name
    try:
        if device_name == "CPU":
            display_name = "CPU"
            temp_display = "%.1f C" % temperature_value
        else:
            if device_name.startswith("/dev/"):
                # use last part
                display_name = device_name
                temp_display = "%d C" % temperature_value
            else:
                display_name = device_name
                temp_display = "%d C" % temperature_value
    except:
        temp_display = str(temperature_value)

    if level == 1:
        message = "First warning: %s temperature %s" % (display_name, temp_display)
        warning_bar_text = "FIRST WARNING: %s TEMP %s" % (display_name, temp_display)
    elif level == 2:
        message = "Second warning: %s temperature %s" % (display_name, temp_display)
        warning_bar_text = "SECOND WARNING: %s TEMP %s" % (display_name, temp_display)
    else:
        message = "Final warning: %s temperature %s" % (display_name, temp_display)
        warning_bar_text = "FINAL WARNING: %s TEMP %s" % (display_name, temp_display)

    log_message("WARNING: " + message)
    log_message("Warning will be displayed for %d seconds" % (warning_duration / 1000))

    # Show warning on screen (popup)
    try:
        from plugin import DiskCpuTempScreen
        if DiskCpuTempScreen.instance and DiskCpuTempScreen.instance.session:
            from Screens.MessageBox import MessageBox
            DiskCpuTempScreen.instance.session.open(
                MessageBox, str(message), type=MessageBox.TYPE_ERROR, timeout=timeout_seconds
            )
    except Exception as e:
        log_message("Popup failed: %s" % str(e))

    # Show warning banner
    try:
        from plugin import DiskCpuTempScreen
        if DiskCpuTempScreen.instance:
            DiskCpuTempScreen.instance.show_warning_bar(warning_bar_text)
            # Update warning bar - this will remain until temperature normalizes
    except Exception as e:
        log_message("Failed to display warning on screen: %s" % str(e))

    # Reset and start warning timer
    try:
        if warning_timer:
            warning_timer.stop()
            warning_timer = None
    except Exception:
        pass

    try:
        from enigma import eTimer
        warning_timer = eTimer()
        try:
            warning_timer.timeout.get().append(clear_warning)
        except:
            warning_timer.callback.append(clear_warning)
        warning_timer.start(warning_duration, 1)  # Single shot timer
    except Exception as e:
        log_message("Failed to start warning_timer: %s" % str(e))
    warning_active = True

def clear_warning():
    global warning_active
    warning_active = False

    # Removed the modification that was clearing the warning after the time period
    # The warning will remain in place until the temperature drops.
    pass

def clear_warning_bar(device_name):
    try:
        from plugin import DiskCpuTempScreen
        if DiskCpuTempScreen.instance:
            # Only when all devices are back to normal, clear the warning.
            if all(level == 0 for level in warning_level.values()):
                DiskCpuTempScreen.instance.clear_warning_bar()
    except:
        pass

# ==== Temperature reading ====
def get_smartctl_commands(device_path):
    """Get temperature using smartctl with automatic device type detection"""
    smartctl_path = "/usr/sbin/smartctl"
    
    # Candidate commands - try common invocations
    commands = [
        [smartctl_path, "-A", device_path],
        [smartctl_path, "-A", "-d", "sat", device_path],
        [smartctl_path, "-A", "-d", "ata", device_path],
        [smartctl_path, "-a", device_path],
        [smartctl_path, "-a", "-d", "sat", device_path],
        [smartctl_path, "-a", "-d", "ata", device_path]
    ]

    for cmd in commands:
        try:
            log_message("Trying command: %s" % " ".join(cmd))
            p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out, error = p.communicate()

            if p.returncode == 0:
                # Fix for Unicode decoding error - use 'replace' instead of 'ignore'
                output = out.decode("utf-8", "replace")
                log_message("SMART output for %s: %s" % (device_path, output))

                # Look for known temperature lines
                for line in output.splitlines():
                    # common SMART attribute lines include Temperature_Celsius or numeric with columns (190/194)
                    if re.search(r'\b(Temperature_Celsius|Airflow_Temperature_Cel|Temperature|Current Drive Temperature)\b', line, re.IGNORECASE):
                        log_message("Found temperature line: %s" % line)
                        
                        # SMART output format example:
                        # 194 Temperature_Celsius     0x0022   100   100   000    Old_age   Always       -       35 (Min/Max 13/55)
                        # We need to extract the RAW_VALUE which is 35, not the Min (13)
                        
                        # Split line and look for the RAW_VALUE (usually the last number before parentheses)
                        parts = line.split()
                        if len(parts) >= 10:
                            # The RAW_VALUE is typically the field before the parentheses
                            # Let's find the field that contains the actual temperature value
                            for i, part in enumerate(parts):
                                # Look for a number that could be temperature (between 10-80)
                                if re.match(r'^\d+$', part):
                                    temp_num = int(part)
                                    if 10 <= temp_num <= 80:
                                        # Check if this is likely the RAW_VALUE (not VALUE/WORST/THRESH)
                                        # RAW_VALUE is usually after the '-' field and before parentheses
                                        if i > 0 and parts[i-1] == '-':
                                            log_message("Found temperature for %s: %d C (from RAW_VALUE)" % (device_path, temp_num))
                                            return "%d C" % temp_num
                        
                        # Alternative approach: extract the number just before parentheses
                        temp_match = re.search(r'(\d+)\s*\(', line)
                        if temp_match:
                            temp_num = int(temp_match.group(1))
                            if 10 <= temp_num <= 80:
                                log_message("Found temperature for %s: %d C (from before parentheses)" % (device_path, temp_num))
                                return "%d C" % temp_num
                
                # fallback: try to find attribute ID lines (190 or 194)
                for line in output.splitlines():
                    if re.match(r'^\s*(190|194)\s+', line):
                        log_message("Found temperature attribute line: %s" % line)
                        parts = line.split()
                        # The RAW_VALUE is usually the last field before parentheses
                        for i in range(len(parts)-1, 0, -1):
                            part = parts[i]
                            if re.match(r'^\d+$', part) and not part.startswith('0x'):
                                temp_num = int(part)
                                if 10 <= temp_num <= 80:
                                    log_message("Found temperature for %s: %d C (from attribute ID)" % (device_path, temp_num))
                                    return "%d C" % temp_num
            else:
                err = error.decode("utf-8", "replace")
                log_message("smartctl returned non-zero for %s: %s" % (device_path, err))
        except Exception as e:
            log_message("Exception running smartctl on %s: %s" % (device_path, str(e)))
            continue

    log_message("No smartctl temperature found for %s" % device_path)
    return "N/A"
    return None

def get_nvme_temp(device_path):
    """Get temperature for NVMe drives"""
    smartctl_path = "/usr/sbin/smartctl"
    try:
        cmd = [smartctl_path, "-A", "-d", "nvme", device_path]
        log_message("Trying NVMe command: %s" % " ".join(cmd))
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, error = p.communicate()
        if p.returncode == 0:
            output = out.decode("utf-8", "replace")
            # NVMe often has "Composite Temperature" or "Temperature Sensor 1"
            for line in output.splitlines():
                if "Composite Temperature" in line or "Temperature Sensor 1" in line or re.search(r'\bTemperature\b', line, re.IGNORECASE):
                    m = re.search(r'(\d+)\s*C', line)
                    if m:
                        temp_num = int(m.group(1))
                        if 0 <= temp_num <= 100:
                            return "%d C" % temp_num
            # fallback: search any number that looks like temperature
            for line in output.splitlines():
                m = re.search(r'(\d+)\s*C', line)
                if m:
                    temp_num = int(m.group(1))
                    if 0 <= temp_num <= 100:
                        return "%d C" % temp_num
        else:
            err = error.decode("utf-8", "replace")
            log_message("NVMe smartctl returned non-zero for %s: %s" % (device_path, err))
    except Exception as e:
        log_message("Exception reading NVMe temp for %s: %s" % (device_path, str(e)))
    return None

# ==== Device detection ====
def detect_all_storage_devices():
    """Detect all connected storage devices automatically"""
    devices = []

    # SATA devices (sda, sdb, sdc, etc.)
    try:
        sata_devices = ["/dev/" + d for d in os.listdir("/dev/") if d.startswith("sd") and len(d) == 3]
        devices.extend(sata_devices)
    except Exception as e:
        log_message("Error detecting SATA devices: %s" % str(e))
    
    # Legacy IDE devices (hda, hdb, etc.)
    try:
        ide_devices = ["/dev/" + d for d in os.listdir("/dev/") if d.startswith("hd") and len(d) == 3]
        devices.extend(ide_devices)
    except Exception as e:
        log_message("Error detecting IDE devices: %s" % str(e))

    # MMC / eMMC devices (mmcblk0, mmcblk1, etc.)
    try:
        mmc_devices = ["/dev/" + d for d in os.listdir("/dev/") if re.match(r'^mmcblk\d+$', d)]
        devices.extend(mmc_devices)
    except Exception as e:
        log_message("Error detecting MMC devices: %s" % str(e))


    # NVMe devices (nvme0n1, nvme1n1, etc.)
    try:
        nvme_devices = ["/dev/" + d for d in os.listdir("/dev/") if d.startswith("nvme") and re.match(r'nvme\d+n\d+$', d)]
        devices.extend(nvme_devices)
    except Exception as e:
        log_message("Error detecting NVMe devices: %s" % str(e))

    # SSD devices (could be SATA or NVMe, we'll detect type later)
    log_message("Detected storage devices: %s" % devices)
    return devices

def get_device_type(device_path):
    """Determine device type (HDD, SSD, NVMe)"""
    if 'nvme' in device_path:
        return "NVMe"

    # For SATA devices, check if they are SSD or HDD
    try:
        smartctl_path = "/usr/sbin/smartctl"
        cmd = [smartctl_path, "-i", device_path]
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, error = p.communicate()

        if p.returncode == 0:
            output = out.decode("utf-8", "replace")
            # Check for SSD indicators
            if re.search(r'\bSSD\b', output, re.IGNORECASE) or re.search(r'Solid State', output, re.IGNORECASE):
                return "SSD"
            # Check for rotational rate - if 0 or 1, it's HDD, if not present or 0, it's SSD
            if re.search(r'Rotation Rate.*:\s*0', output, re.IGNORECASE):
                return "SSD"
            if re.search(r'Rotation Rate.*:\s*[1-9]', output, re.IGNORECASE):
                return "HDD"
    except Exception as e:
        log_message("Error determining device type for %s: %s" % (device_path, str(e)))
    
    # Default to HDD if cannot determine
    return "HDD"

def get_hdd_temps():
    """Return dict of storage device temps with automatic detection and naming"""
    devices = detect_all_storage_devices()
    results = {}

    # Counters for each device type
    hdd_count = 1
    ssd_count = 1
    nvme_count = 1

    # Sort devices: SATA first, then NVMe
    sata_devices = [d for d in devices if d.startswith("/dev/sd")]
    nvme_devices = [d for d in devices if d.startswith("/dev/nvme")]

    sorted_devices = sorted(sata_devices) + sorted(nvme_devices)

    for device_path in sorted_devices:
        device_name = device_path.split("/")[-1]
        
        # Get device type
        device_type = get_device_type(device_path)
        
        # Get temperature based on device type
        if device_type == "NVMe":
            temp = get_nvme_temp(device_path)
            if not temp:
                temp = "N/A"
            display_name = "NVMe%d-%s" % (nvme_count, device_name)
            results[display_name] = temp
            nvme_count += 1
        else:
            temp = get_smartctl_commands(device_path)
            if not temp:
                temp = "N/A"
            if device_type == "SSD":
                display_name = "SSD%d-%s" % (ssd_count, device_name)
                ssd_count += 1
            else:  # HDD
                display_name = "HDD%d-%s" % (hdd_count, device_name)
                hdd_count += 1
            results[display_name] = temp

    log_message("Detected storage temperatures: %s" % results)
    return results

def get_drive_temps():
    """Get drive temperatures in format expected by plugin - returns list of (device, temp)"""
    temps_dict = get_hdd_temps()
    # Convert dictionary to list of tuples
    return [(device, temp) for device, temp in temps_dict.items()]

def get_cpu_temp():
    """Read CPU temperature if available"""
    paths = [
        "/sys/class/thermal/thermal_zone0/temp",
        "/sys/class/hwmon/hwmon0/temp1_input"
    ]
    for path in paths:
        if os.path.exists(path):
            try:
                with open(path, "r") as f:
                    val = f.read().strip()
                    # some files give millidegrees
                    try:
                        fval = float(val)
                        temp_c = fval / 1000.0 if fval > 1000 else fval
                        return "%.1f C" % temp_c
                    except:
                        pass
            except:
                continue
    # fallback to sensors output if available
    try:
        out = subprocess.check_output(["sensors"], universal_newlines=True)
        m = re.search(r'(?i)cpu.*?:\s*\+?(\d+(\.\d+)?)', out)
        if m:
            return "%s C" % m.group(1)
    except:
        pass
    return "N/A"

# ==== Display function ====
def show_drive_summary_with_temp():
    try:
        cpu_temp = get_cpu_temp()
        print("=" * 60)
        print("Detected Devices and Temperatures:\n")

        # CPU first
        print("CPU : %s" % cpu_temp)
        log_message("CPU : %s" % cpu_temp)
        print("")

        # Get drive temperatures
        drive_temps = get_drive_temps()

        if not drive_temps:
            print("No drives detected or smartctl not available.")
            log_message("No drives detected.")
            print("=" * 60)
            return

        for device, temp in drive_temps:
            if temp is None:
                temp = "error reading temp"

            line = "%s : %s" % (device, temp)
            print(line)
            log_message(line)
        print("=" * 60)
    except Exception as e:
        print("Error displaying drives: %s" % str(e))
        log_message("Error displaying drives: %s" % str(e))

# ==== Main execution ====
if __name__ == "__main__":
    show_drive_summary_with_temp()