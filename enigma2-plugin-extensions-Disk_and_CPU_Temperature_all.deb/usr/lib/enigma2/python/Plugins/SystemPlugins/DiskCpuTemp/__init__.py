# -*- coding: utf-8 -*-
# Init file for DiskCpuTemp plugin