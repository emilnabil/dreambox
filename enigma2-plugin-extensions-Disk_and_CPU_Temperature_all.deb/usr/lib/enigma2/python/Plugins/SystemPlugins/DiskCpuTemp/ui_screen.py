# -*- coding: utf-8 -*-
from __future__ import print_function, division
import os
import subprocess
import re
import time
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.config import config
from enigma import eTimer, getDesktop, gRGB

# Import from our other modules
from temp_utilities import *

# --- UI Screen Methods ---
class UIScreenMethods:
    # --- Skins ---
    def _skin_fhd1(self):
        # HD Skin (1280x720)
        return """
        <screen name="DiskCpuTempScreen" position="center,center" size="900,630" title="" flags="wfNoBorder">
            <widget name="plugin_name" position="30,13" size="540,30" font="Regular;28" halign="left" foregroundColor="#FFFF00" transparent="1"/>
            <widget name="version" position="750,13" size="120,30" font="Regular;28" halign="right" foregroundColor="#FFFF00" transparent="1"/>
            <widget name="warning_bar" position="30,150" size="840,40" font="Regular;28" halign="center" foregroundColor="#FF0000" transparent="1"/>

            <!-- Buttons -->
            <widget name="exit_button" position="40,75" size="190,50" font="Regular;24" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#FF0000" transparent="0"/>
            <widget name="save_button" position="240,75" size="190,50" font="Regular;24" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#00FF00" transparent="0"/>
            <widget name="change_skin_button" position="440,75" size="190,50" font="Regular;24" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#FFFF00" transparent="0"/>
            <widget name="stop_warning_button" position="640,75" size="190,50" font="Regular;24" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#0000FF" transparent="0"/>

            <!-- Content section -->
            <widget name="cpu_label" position="30,200" size="840,36" font="Regular;28" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="hdd1_label" position="30,260" size="840,36" font="Regular;28" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="hdd2_label" position="30,310" size="840,36" font="Regular;28" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="hdd3_label" position="30,360" size="840,36" font="Regular;28" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="hdd4_label" position="30,410" size="840,36" font="Regular;28" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="settings_label" position="30,480" size="840,32" font="Regular;26" halign="center" foregroundColor="#00FF00" transparent="1"/>
            <widget name="update_label" position="30,520" size="840,32" font="Regular;26" halign="center" foregroundColor="#00BFFF" transparent="1"/>
            <widget name="settings_hint" position="30,560" size="840,32" font="Regular;26" halign="center" foregroundColor="#FFFF00" transparent="1"/>
        </screen>
        """

    def _skin_fhd2(self):
        # Full screen FHD (1920x1080) skin — widgets sized and positioned for full-screen display (Fhd2)
        return """
        <screen name="DiskCpuTempScreen" position="0,0" size="1920,1080" title="" flags="wfNoBorder">
            <widget name="plugin_name" position="40,20" size="1740,60" font="Regular;36" halign="left" foregroundColor="#FFFF00" transparent="1"/>
            <widget name="version" position="1760,20" size="120,60" font="Regular;32" halign="right" foregroundColor="#FFFF00" transparent="1"/>
            <widget name="warning_bar" position="40,260" size="1840,70" font="Regular;34" halign="center" foregroundColor="#FF0000" transparent="1"/>

            <!-- Buttons -->
            <widget name="exit_button" position="200,150" size="380,80" font="Regular;28" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#FF0000" transparent="0"/>
            <widget name="save_button" position="600,150" size="380,80" font="Regular;28" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#00FF00" transparent="0"/>
            <widget name="change_skin_button" position="1000,150" size="380,80" font="Regular;28" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#FFFF00" transparent="0"/>
            <widget name="stop_warning_button" position="1400,150" size="380,80" font="Regular;28" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#0000FF" transparent="0"/>

            <!-- Content section -->
            <widget name="cpu_label" position="100,310" size="1840,56" font="Regular;34" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="hdd1_label" position="100,380" size="1840,56" font="Regular;34" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="hdd2_label" position="100,450" size="1840,56" font="Regular;34" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="hdd3_label" position="100,520" size="1840,56" font="Regular;34" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="hdd4_label" position="100,590" size="1840,56" font="Regular;34" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="settings_label" position="60,740" size="1840,50" font="Regular;30" halign="center" foregroundColor="#00FF00" transparent="1"/>
            <widget name="update_label" position="60,800" size="1840,50" font="Regular;30" halign="center" foregroundColor="#00BFFF" transparent="1"/>
            <widget name="settings_hint" position="60,860" size="1840,50" font="Regular;30" halign="center" foregroundColor="#FFFF00" transparent="1"/>
        </screen>
        """

    # --- Actions ---
    def save_only(self):
        try:
            config.plugins.DiskCpuTemp.warning_duration.save()
            self.show_temp_confirmation("Settings saved")
            log_message("Settings saved without exit")
        except Exception as e:
            log_message("Failed to save config: %s" % str(e))

    def exit_plugin(self):
        try:
           self.close()
        except:
            pass

    def reset_to_default(self):
        # Reset warning duration to default (5 seconds)
        config.plugins.DiskCpuTemp.warning_duration.value = "5000"
        config.plugins.DiskCpuTemp.warning_duration.save()
        self["settings_label"].setText("Warning Duration: 5 seconds")
        log_message("Warning duration reset to default: 5 seconds")
        self.show_temp_confirmation("Reset to default: 5 seconds")

    def change_skin(self):
        # Yellow button action: toggle skin selection between Fhd1 and Fhd2, save and restart Enigma
        try:
            current = config.plugins.DiskCpuTemp.last_skin.value
        except:
            current = "Fhd2"
        new_skin = "Fhd1" if current == "Fhd2" else "Fhd2"
        prompt = "Change skin to %s?\nEnigma will restart to apply the new skin." % new_skin

        # Ask user for confirmation (YES/NO)
        try:
            self.session.openWithCallback(
                lambda answer, ns=new_skin: self._apply_skin_choice(answer, ns),
                MessageBox, prompt, type=MessageBox.TYPE_YESNO
            )
        except Exception as e:
            # fallback: if openWithCallback not available, apply immediately
            log_message("openWithCallback failed for change_skin: %s" % str(e))
            self._apply_skin_choice(True, new_skin)
        except Exception as e:
            log_message("Error in change_skin: %s" % str(e))

    def _apply_skin_choice(self, confirmed, new_skin):
        if not confirmed:
            self.show_temp_confirmation("Skin change cancelled")
            return
        try:
            config.plugins.DiskCpuTemp.last_skin.value = new_skin
            config.plugins.DiskCpuTemp.last_skin.save()
            log_message("Skin changed to %s - saved to config" % new_skin)
        except Exception as e:
            log_message("Failed to save skin choice: %s" % str(e))

        # Restart Enigma2 to apply the skin change
        try:
            # Try the proper method first
            from Screens.Standby import TryQuitMainloop
            try:
                TryQuitMainloop(2)  # 2 = restart
            except Exception as e:
                # In case TryQuitMainloop requires args or fails, fallback
                log_message("TryQuitMainloop call failed: %s" % str(e))
                try:
                    subprocess.call(["killall", "enigma2"])
                except Exception as e2:
                    log_message("Fallback killall enigma2 failed: %s" % str(e2))
        except Exception as e:
            # If import fails, fallback to killing enigma2 process
            log_message("Restart import failed: %s" % str(e))
            try:
                subprocess.call(["killall", "enigma2"])
            except Exception as e2:
                log_message("Fallback killall enigma2 failed: %s" % str(e2))

    # --- Warning toggle ---
    def toggle_warnings(self):
        # Toggle warnings on/off
        global warnings_enabled, warning_level
        warnings_enabled = not warnings_enabled

        if warnings_enabled:
            # Reset all warning levels when re-enabling warnings
            for device in warning_level:
                warning_level[device] = 0
            self["stop_warning_button"].setText("Stop Warning")
            log_message("Warnings enabled - reset all warning levels")
            self.show_temp_confirmation("Warnings enabled")
        else:
            self["stop_warning_button"].setText("Warnings stopped")
            # Clear any active warning
            self.clear_warning_bar()
            log_message("Warnings disabled")
            self.show_temp_confirmation("Warnings disabled")

    # --- Timer ---
    def startTimer(self):
        if hasattr(self, 'updateTimer') and self.updateTimer is not None:
            try:
                self.updateTimer.start(5000)  # Update every 5 seconds
                log_message("Timer started with 5000ms interval")
            except Exception as e:
                log_message("Failed to start timer: %s" % str(e))

        # Update temperatures immediately
        self.updateTemps()

    def stopTimer(self):
        if hasattr(self, 'updateTimer') and self.updateTimer is not None:
            try:
                self.updateTimer.stop()
                log_message("Timer stopped")
            except Exception as e:
                log_message("Failed to stop timer: %s" % str(e))

    # --- Duration adjustment --
    def increase_duration(self):
        try:
            current_value = config.plugins.DiskCpuTemp.warning_duration.value
            choices = config.plugins.DiskCpuTemp.warning_duration.choices

            current_index = 0
            for i, choice in enumerate(choices):
                value = choice[0] if isinstance(choice, tuple) else choice
                if value == current_value:
                    current_index = i
                    break

            if current_index < len(choices) - 1:
                next_choice = choices[current_index + 1]
                new_value = next_choice[0] if isinstance(next_choice, tuple) else next_choice
                config.plugins.DiskCpuTemp.warning_duration.value = new_value
                config.plugins.DiskCpuTemp.warning_duration.save()

                try:
                    warning_duration = int(new_value) / 1000
                except:
                    warning_duration = int(new_value) if isinstance(new_value, int) else 5
                self["settings_label"].setText("Warning Duration: %d seconds" % warning_duration)
                log_message("Warning duration increased to %d seconds" % warning_duration)

                self.show_temp_confirmation("Duration: %d seconds" % warning_duration)
        except Exception as e:
            log_message("Error in increase_duration: %s" % str(e))

    def decrease_duration(self):
        try:
            current_value = config.plugins.DiskCpuTemp.warning_duration.value
            choices = config.plugins.DiskCpuTemp.warning_duration.choices

            current_index = 0
            for i, choice in enumerate(choices):
                value = choice[0] if isinstance(choice, tuple) else choice
                if value == current_value:
                    current_index = i
                    break

            if current_index > 0:
                prev_choice = choices[current_index - 1]
                new_value = prev_choice[0] if isinstance(prev_choice, tuple) else prev_choice
                config.plugins.DiskCpuTemp.warning_duration.value = new_value
                config.plugins.DiskCpuTemp.warning_duration.save()

                try:
                    warning_duration = int(new_value) / 1000
                except:
                    warning_duration = int(new_value) if isinstance(new_value, int) else 5
                self["settings_label"].setText("Warning Duration: %d seconds" % warning_duration)
                log_message("Warning duration decreased to %d seconds" % warning_duration)

                self.show_temp_confirmation("Duration: %d seconds" % warning_duration)
        except Exception as e:
            log_message("Error in decrease_duration: %s" % str(e))

    # --- Confirmation label ---
    def show_temp_confirmation(self, message):
        try:
            original_text = self["settings_label"].text
        except Exception:
            original_text = ""
        try:
            self["settings_label"].setText(message)
        except Exception:
            pass

        try:
            # Clean up existing timer if any
            if hasattr(self, 'confirm_timer') and self.confirm_timer is not None:
                try:
                    self.confirm_timer.stop()
                except:
                    pass
                self.confirm_timer = None

            self.confirm_timer = eTimer()
            try:
                if hasattr(self.confirm_timer, 'timeout'):
                    self.confirm_timer.timeout.connect(lambda: self.restore_settings_label(original_text))
                else:
                    self.confirm_timer.callback.append(lambda: self.restore_settings_label(original_text))
            except:
                self.confirm_timer.callback.append(lambda: self.restore_settings_label(original_text))
            self.confirm_timer.start(2000, True)
        except Exception as e:
            log_message("Failed to start confirmation timer: %s" % str(e))

    def restore_settings_label(self, text):
        try:
            self["settings_label"].setText(text)
        except:
            pass

    def updateSettingsDisplay(self):
        try:
            warning_duration = int(config.plugins.DiskCpuTemp.warning_duration.value)
            self["settings_label"].setText("Warning Duration: %d seconds" % (warning_duration / 1000))
        except Exception:
            try:
                self["settings_label"].setText("Warning Duration: %s" % str(config.plugins.DiskCpuTemp.warning_duration.value))
            except:
                pass

    # --- Warning bar ---
    def show_warning_bar(self, message):
        try:
            self["warning_bar"].setText(message)
        except Exception as e:
            log_message("Failed to update warning_bar: %s" % str(e))

    def clear_warning_bar(self):
        try:
            self["warning_bar"].setText("")
        except Exception as e:
            log_message("Failed to clear warning_bar: %s" % str(e))

    # --- Helper to ensure we pass a proper gRGB object to eLabel ---
    def ensure_grgb(self, color):
        """
        Ensure 'color' is an enigma.gRGB object (or fallback).
        Accepts: gRGB instance, tuple/list (r,g,b), hex string "#RRGGBB", "r,g,b" string,
                 or any object - returns a gRGB or a safe default.
        """
        try:
            # already a gRGB instance
            if isinstance(color, gRGB):
                return color
        except Exception:
            # isinstance may fail if gRGB not the expected class in this runtime
            pass

        # tuple/list like (r,g,b)
        try:
            if isinstance(color, (tuple, list)) and len(color) >= 3:
                r = int(color[0]); g = int(color[1]); b = int(color[2])
                return gRGB(r, g, b)
        except Exception:
            pass

        # string formats
        try:
            if isinstance(color, str):
                s = color.strip()
                if s.startswith("#") and len(s) in (7, 9):
                    # hex #RRGGBB or #AARRGGBB (ignore alpha)
                    r = int(s[1:3], 16); g = int(s[3:5], 16); b = int(s[5:7], 16)
                    return gRGB(r, g, b)
                if "," in s:
                    parts = [p.strip() for p in s.split(",")]
                    if len(parts) >= 3:
                        r = int(parts[0]); g = int(parts[1]); b = int(parts[2])
                        return gRGB(r, g, b)
        except Exception:
            pass

        # fallback safe white
        try:
            return gRGB(255, 255, 255)
        except Exception:
            # last resort, try to return something that won't crash (tuple)
            return (255, 255, 255)

    def updateTemps(self):
        log_message("Starting temperature update")
        try:
            # Update settings display
            self.updateSettingsDisplay()

            # Update CPU temperature
            cpu_temp = get_cpu_temp()
            log_message("CPU temp: %s" % str(cpu_temp))
            try:
                self["cpu_label"].setText("CPU Temp: %s" % cpu_temp)
                # compute color, ensure it's gRGB
                try:
                    color = temp_to_color(cpu_temp, "CPU")
                except Exception as e:
                    log_message("temp_to_color CPU raised: %s" % str(e))
                    color = gRGB(255, 255, 255)
                color = self.ensure_grgb(color)
                try:
                    # prefer instance method if available
                    self["cpu_label"].instance.setForegroundColor(color)
                except Exception:
                    try:
                        self["cpu_label"].setForegroundColor(color)
                    except Exception as e:
                        log_message("Failed to set CPU label color: %s" % str(e))
            except Exception as e:
                log_message("Failed to update CPU label: %s" % str(e))

            # Check for CPU warnings
            check_temperature_warnings("CPU", "CPU", cpu_temp)

            # Get all storage temps (HDD / SSD / NVMe) with automatic detection
            storage = get_hdd_temps()
            try:
                log_message("Storage devices found: %s" % str(list(storage.keys())))
            except Exception:
                log_message("Storage devices found (unable to stringify keys)")

            # Display storage devices - show first four devices found
            storage_keys = sorted(storage.keys()) if storage else []

            # Update all 4 HDD labels
            hdd_labels = ["hdd1_label", "hdd2_label", "hdd3_label", "hdd4_label"]
            
            for i in range(4):
                if i < len(storage_keys):
                    device = storage_keys[i]
                    temp = storage.get(device)
                    hdd_text = "%s Temp: %s" % (device, temp)
                    self[hdd_labels[i]].setText(hdd_text)
                    
                    # Set color based on device type
                    device_type = "HDD"  # default
                    if "SSD" in device.upper():
                        device_type = "SSD"
                    elif "NVME" in device.upper():
                        device_type = "NVMe"
                    
                    try:
                        color = temp_to_color(temp, device_type)
                    except Exception as e:
                        log_message("temp_to_color for %s raised: %s" % (device, str(e)))
                        color = gRGB(255, 255, 255)
                    
                    color = self.ensure_grgb(color)
                    try:
                        self[hdd_labels[i]].instance.setForegroundColor(color)
                    except Exception:
                        try:
                            self[hdd_labels[i]].setForegroundColor(color)
                        except Exception as e:
                            log_message("Failed to set %s color: %s" % (hdd_labels[i], str(e)))
                    
                    # Check for warnings
                    check_temperature_warnings(device_type, device, temp)
                else:
                    self[hdd_labels[i]].setText("")

            # Log any additional devices beyond the first four
            if len(storage_keys) > 4:
                for extra_device in storage_keys[4:]:
                    try:
                        log_message("Additional storage device: %s Temp: %s" % (extra_device, storage[extra_device]))
                    except Exception as e:
                        log_message("Failed logging extra device: %s" % str(e))

            log_message("Temperature update complete")
        except Exception as e:
            log_message("Error in updateTemps: %s" % str(e))

        # Restart the timer for the next update
        try:
            if hasattr(self, 'updateTimer') and self.updateTimer is not None:
                self.updateTimer.start(5000, True)
        except Exception as e:
            log_message("Failed to restart timer: %s" % str(e))