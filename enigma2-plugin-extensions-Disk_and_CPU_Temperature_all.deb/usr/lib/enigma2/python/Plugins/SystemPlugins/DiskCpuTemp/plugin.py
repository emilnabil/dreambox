# -*- coding: utf-8 -*-
from __future__ import print_function
from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.config import config, ConfigSubsection, ConfigSelection
from Plugins.Plugin import PluginDescriptor
from enigma import eTimer
import os
import subprocess
import re
import time

PLUGIN_VERSION = "1.2"

log_file = "/tmp/diskcputemp.log"

# Warning thresholds
FIRST_WARNING_TEMP = 45
SECOND_WARNING_TEMP = 48
FINAL_WARNING_TEMP = 50

# Configuration setup
config.plugins.DiskCpuTemp = ConfigSubsection()
config.plugins.DiskCpuTemp.warning_duration = ConfigSelection(
    choices=[
        ("5000", "5 seconds"),
        ("10000", "10 seconds"),
        ("15000", "15 seconds"),
        ("20000", "20 seconds")
    ],
    default="5000"
)

# Warning system variables
warning_active = False
warning_level = {"/dev/sda": 0, "/dev/sdb": 0}
warning_timer = None

def clear_log():
    try:
        with open(log_file, "w") as f:
            f.write("")
        log_message("Log file cleared")
    except:
        pass

def log_message(message):
    try:
        with open(log_file, "a") as f:
            timestamp = time.strftime("%H:%M:%S")
            f.write("[%s] %s\n" % (timestamp, message))
    except:
        pass

def check_temperature_warnings(hdd_device, temperature):
    global warning_active, warning_level

    try:
        if "N/A" in temperature:
            return

        # temperature string usually like "45 C" or "45 C" or "45"
        # split and take first token that's numeric
        parts = temperature.split()
        temp_token = None
        for p in parts:
            if any(ch.isdigit() for ch in p):
                temp_token = p
                break
        if temp_token is None:
            return

        temp_only = re.findall(r"[-+]?\d+(\.\d+)?", temp_token)
        if not temp_only:
            return
        temp_value = float(temp_only[0])

        # Check warning levels
        if temp_value >= FINAL_WARNING_TEMP and warning_level[hdd_device] < 3:
            show_warning(hdd_device, 3, temperature)
            warning_level[hdd_device] = 3
        elif temp_value >= SECOND_WARNING_TEMP and warning_level[hdd_device] < 2:
            show_warning(hdd_device, 2, temperature)
            warning_level[hdd_device] = 2
        elif temp_value >= FIRST_WARNING_TEMP and warning_level[hdd_device] < 1:
            show_warning(hdd_device, 1, temperature)
            warning_level[hdd_device] = 1
        elif temp_value < FIRST_WARNING_TEMP and warning_level[hdd_device] > 0:
            warning_level[hdd_device] = 0
            log_message("Temperature normalized for %s" % hdd_device)
    except ValueError:
        pass
    except Exception as e:
        log_message("Exception in check_temperature_warnings: %s" % str(e))

def show_warning(hdd_device, level, temperature):
    global warning_active, warning_timer
    # Get warning duration from configuration
    try:
        warning_duration = int(config.plugins.DiskCpuTemp.warning_duration.value)
    except Exception:
        warning_duration = 5000

    # Determine which HDD is causing the warning
    hdd_name = "HDD1" if hdd_device == "/dev/sda" else "HDD2"

    if level == 1:
        message = "# First warning: %s temperature %s" % (hdd_name, temperature)
    elif level == 2:
        message = "# Second warning: %s temperature %s" % (hdd_name, temperature)
    else:
        message = "# Final warning: %s temperature %s" % (hdd_name, temperature)

    log_message("WARNING: " + message)
    log_message("Warning will be displayed for %d seconds" % (warning_duration / 1000))

    # Show warning on screen
    if DiskCpuTempScreen.instance:
        DiskCpuTempScreen.instance.show_temp_warning(message)

    try:
        if warning_timer:
            warning_timer.stop()
    except Exception:
        pass

    try:
        warning_timer = eTimer()
        try:
            warning_timer.timeout.get().append(clear_warning)
        except:
            warning_timer.callback = clear_warning
        warning_timer.start(warning_duration)
    except Exception as e:
        log_message("Failed to start warning_timer: %s" % str(e))
    warning_active = True

def clear_warning():
    global warning_active
    warning_active = False

    if DiskCpuTempScreen.instance:
        DiskCpuTempScreen.instance.clear_temp_warning()

class DiskCpuTempScreen(Screen):
    instance = None

    def __init__(self, session):
        Screen.__init__(self, session)
        log_message("Initializing DiskCpuTempScreen")

        # Get warning duration from configuration
        try:
            warning_duration = int(config.plugins.DiskCpuTemp.warning_duration.value)
        except Exception:
            warning_duration = 5000
        log_message("Warning duration set to %d seconds" % (warning_duration / 1000))

        # Set instance for global access
        DiskCpuTempScreen.instance = self

        # Fixed skin without title attribute to prevent default Enigma2 title
        self.skin = """
        <screen position="center,center" size="700,500" flags="wfNoBorder">
            <!-- Custom header with gray background -->
            <widget name="header_bg" position="0,0" size="700,40" backgroundColor="#333333"/>

            <!-- Plugin name on left -->
            <widget name="plugin_name" position="10,5" size="500,30" font="Regular;24" halign="left" foregroundColor="#FFD700" transparent="1"/>

            <!-- Version on right -->
            <widget name="version" position="600,5" size="90,30" font="Regular;24" halign="right" foregroundColor="#FFD700" transparent="1"/>

            <!-- Warning display -->
            <widget name="warning_label" position="50,60" size="600,30" font="Regular;20" halign="center" foregroundColor="#FF0000" transparent="1"/>

            <!-- Temperature display -->
            <widget name="cpu_label" position="50,100" size="600,50" font="Regular;28"/>
            <widget name="hdd1_label" position="50,170" size="600,50" font="Regular;28"/>
            <widget name="hdd2_label" position="50,240" size="600,50" font="Regular;28"/>

            <!-- Settings info -->
            <widget name="settings_label" position="50,310" size="600,30" font="Regular;20" halign="center" foregroundColor="#00FF00" transparent="1"/>

            <widget name="info_label" position="50,350" size="600,40" font="Regular;22"/>
            <widget name="update_label" position="50,390" size="600,40" font="Regular;22"/>
            <widget name="settings_hint" position="50,430" size="600,40" font="Regular;22" foregroundColor="#FFFF00"/>
        </screen>"""

        # Initialize header
        self["header_bg"] = Label("")
        self["plugin_name"] = Label("Disk & CPU Temperature by Iet5")
        self["version"] = Label("v" + PLUGIN_VERSION)

        # Initialize warning label
        self["warning_label"] = Label("")

        # Initialize temperature labels
        self["cpu_label"] = Label("CPU Temp: Loading...")
        self["hdd1_label"] = Label("")
        self["hdd2_label"] = Label("")

        # Initialize settings info
        self["settings_label"] = Label("Warning Duration: %d seconds" % (warning_duration / 1000))
        # Help line requested
        self["info_label"] = Label("Press OK or EXIT to save and close")
        self["update_label"] = Label("Update every 5 seconds")
        self["settings_hint"] = Label("Press UP/DOWN to change warning duration")

        # Actions
        # Support many action maps for widest remote compatibility, bind OK/EXIT to save_and_close
        self["actions"] = ActionMap(
            ["SetupActions", "OkCancelActions", "ChannelSelectActions", "InfobarChannelSelection", "DirectionActions", "NumberActions"], {
                "ok": self.save_and_close,
                "cancel": self.save_and_close,
                "up": self.increase_duration,
                "down": self.decrease_duration
            }, -1
        )

        self.updateTimer = eTimer()
        try:
            self.updateTimer.timeout.get().append(self.updateTemps)
        except Exception as e:
            log_message("Timeout append failed, trying callback: %s" % str(e))
            try:
                self.updateTimer.callback = self.updateTemps
            except Exception as e2:
                log_message("Failed to assign timer callback: %s" % str(e2))

        self.onShown.append(self.startTimer)
        self.onHide.append(self.stopTimer)

        log_message("Screen initialization complete")

    def save_and_close(self):
        try:
            config.plugins.DiskCpuTemp.warning_duration.save()
        except Exception as e:
            log_message("Failed to save config: %s" % str(e))
        try:
            self.close()
        except Exception:
            pass

    def startTimer(self):
        if self.updateTimer is not None:
            try:
                interval = int(config.plugins.DiskCpuTemp.warning_duration.value)
            except:
                interval = 5000
            self.updateTimer.start(interval)
            log_message("Timer started with %dms interval" % interval)
        self.updateTemps()

    def stopTimer(self):
        if self.updateTimer is not None:
            try:
                self.updateTimer.stop()
            except:
                pass
            log_message("Timer stopped")

    def increase_duration(self):
        try:
            current_value = config.plugins.DiskCpuTemp.warning_duration.value
            choices = config.plugins.DiskCpuTemp.warning_duration.choices

            current_index = 0
            for i, choice in enumerate(choices):
                value = choice[0] if isinstance(choice, tuple) else choice
                if value == current_value:
                    current_index = i
                    break

            if current_index < len(choices) - 1:
                next_choice = choices[current_index + 1]
                new_value = next_choice[0] if isinstance(next_choice, tuple) else next_choice
                config.plugins.DiskCpuTemp.warning_duration.value = new_value
                config.plugins.DiskCpuTemp.warning_duration.save()

                try:
                    warning_duration = int(new_value) / 1000
                except:
                    warning_duration = int(new_value) if isinstance(new_value, int) else 5
                self["settings_label"].setText("Warning Duration: %d seconds" % warning_duration)
                log_message("Warning duration increased to %d seconds" % warning_duration)

                self.show_temp_confirmation("Duration: %d seconds" % warning_duration)
        except Exception as e:
            log_message("Error in increase_duration: %s" % str(e))

    def decrease_duration(self):
        try:
            current_value = config.plugins.DiskCpuTemp.warning_duration.value
            choices = config.plugins.DiskCpuTemp.warning_duration.choices

            current_index = 0
            for i, choice in enumerate(choices):
                value = choice[0] if isinstance(choice, tuple) else choice
                if value == current_value:
                    current_index = i
                    break

            if current_index > 0:
                prev_choice = choices[current_index - 1]
                new_value = prev_choice[0] if isinstance(prev_choice, tuple) else prev_choice
                config.plugins.DiskCpuTemp.warning_duration.value = new_value
                config.plugins.DiskCpuTemp.warning_duration.save()

                try:
                    warning_duration = int(new_value) / 1000
                except:
                    warning_duration = int(new_value) if isinstance(new_value, int) else 5
                self["settings_label"].setText("Warning Duration: %d seconds" % warning_duration)
                log_message("Warning duration decreased to %d seconds" % warning_duration)

                self.show_temp_confirmation("Duration: %d seconds" % warning_duration)
        except Exception as e:
            log_message("Error in decrease_duration: %s" % str(e))

    def show_temp_confirmation(self, message):
        try:
            original_text = self["settings_label"].text
        except Exception:
            original_text = ""
        try:
            self["settings_label"].setText(message)
        except Exception:
            pass

        try:
            self.confirm_timer = eTimer()
            try:
                self.confirm_timer.timeout.get().append(lambda: self["settings_label"].setText(original_text))
            except:
                self.confirm_timer.callback = lambda: self["settings_label"].setText(original_text)
            self.confirm_timer.start(2000)
        except Exception as e:
            log_message("Failed to start confirmation timer: %s" % str(e))

    def updateSettingsDisplay(self):
        try:
            warning_duration = int(config.plugins.DiskCpuTemp.warning_duration.value)
            self["settings_label"].setText("Warning Duration: %d seconds" % (warning_duration / 1000))
        except Exception:
            try:
                self["settings_label"].setText("Warning Duration: %s" % str(config.plugins.DiskCpuTemp.warning_duration.value))
            except:
                pass

    def show_temp_warning(self, message):
        try:
            self["warning_label"].setText(message)
        except Exception:
            pass

    def clear_temp_warning(self):
        try:
            self["warning_label"].setText("")
        except Exception:
            pass

    def updateTemps(self):
        log_message("Starting temperature update")
        try:
            # Update settings display
            self.updateSettingsDisplay()

            # CPU temperature
            cpu_temp = self.get_cpu_temp()
            log_message("CPU temp: " + str(cpu_temp))
            try:
                self["cpu_label"].setText(str("CPU Temp: %s" % cpu_temp))
            except:
                pass

            # HDD temperatures
            hdd_count = 0

            # Check HDD1
            if os.path.exists("/dev/sda"):
                hdd1_temp = self.get_hdd_temp_smartctl("/dev/sda")
                log_message("HDD1 temp: " + str(hdd1_temp))
                try:
                    self["hdd1_label"].setText(str("HDD1 Temp: %s" % hdd1_temp))
                except:
                    pass
                hdd_count += 1
                # Check for warnings on HDD1
                check_temperature_warnings("/dev/sda", hdd1_temp)
            else:
                # Hide HDD1 label if not exists
                self["hdd1_label"].setText("")

            # Check HDD2
            if os.path.exists("/dev/sdb"):
                hdd2_temp = self.get_hdd_temp_smartctl("/dev/sdb")
                log_message("HDD2 temp: " + str(hdd2_temp))
                try:
                    self["hdd2_label"].setText(str("HDD2 Temp: %s" % hdd2_temp))
                except:
                    pass
                hdd_count += 1
                # Check for warnings on HDD2
                check_temperature_warnings("/dev/sdb", hdd2_temp)
            else:
                # Hide HDD2 label if not exists
                self["hdd2_label"].setText("")

            # If no HDDs found, show message on HDD1 label
            if hdd_count == 0:
                self["hdd1_label"].setText("There is no hdd found")

            log_message("Temperature update complete")
        except Exception as e:
            log_message("Error in updateTemps: " + str(e))

    def get_cpu_temp(self):
        try:
            if not os.path.exists("/sys/class/thermal/thermal_zone0/temp"):
                return "N/A"
            with open("/sys/class/thermal/thermal_zone0/temp", "r") as f:
                temp = int(f.read().strip()) / 1000.0
                return "%.1f C" % temp
        except:
            return "N/A"

    def get_hdd_temp_smartctl(self, device="/dev/sda"):
        try:
            # Check if smartctl exists
            smartctl_path = None
            for path in ["/usr/sbin/smartctl", "/bin/smartctl", "/sbin/smartctl"]:
                if os.path.exists(path):
                    smartctl_path = path
                    break

            if not smartctl_path:
                log_message("smartctl not found")
                return "N/A (smartctl missing)"

            # Try different smartctl command options
            commands = [
                [smartctl_path, "-A", "-d", "sat", device],
                [smartctl_path, "-A", "-d", "ata", device],
                [smartctl_path, "-A", device]
            ]

            output = None
            for cmd in commands:
                try:
                    output = subprocess.check_output(cmd, stderr=subprocess.STDOUT)
                    log_message("Used command: %s" % " ".join(cmd))
                    break
                except subprocess.CalledProcessError as e:
                    log_message("Command failed: %s, error: %s" % (" ".join(cmd), str(e)))
                    continue

            if output is None:
                log_message("All smartctl commands failed for device: %s" % device)
                return "N/A (smartctl error)"

            if isinstance(output, bytes):
                output = output.decode("utf-8", "ignore")

            log_message("Smartctl output: %s" % output[:200])

            patterns = [
                r"194 Temperature_Celsius.*?(\d+)\s*\([^)]*\)$",
                r"190 Airflow_Temperature_Cel.*?(\d+)\s*\([^)]*\)$",
                r"Temperature_Celsius.*?\s+\d+\s+\d+\s+\d+\s+\S+\s+\S+\s+\S+\s+(\d+)",
                r"Current Drive Temperature.*?(\d+)",
            ]

            for line in output.split("\n"):
                if "Temperature" in line or "Airflow" in line or "Drive Temperature" in line:
                    log_message("Temperature line: %s" % line)
                    for pattern in patterns:
                        match = re.search(pattern, line, re.IGNORECASE)
                        if match:
                            temp = match.group(1)
                            log_message("Found temperature for %s: %s" % (device, temp))
                            return "%s C" % temp

            log_message("No temperature found in smartctl output for device: %s" % device)
            return "N/A (no temp)"
        except Exception as e:
            log_message("Exception in get_hdd_temp_smartctl for %s: %s" % (device, str(e)))
            return "N/A"

def main(session, **kwargs):
    try:
        clear_log()
        log_message("Plugin started - opening screen")
        session.open(DiskCpuTempScreen)
        log_message("Screen opened successfully")
    except Exception as e:
        log_message("Error opening screen: " + str(e))

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Disk & CPU Temperature by Iet5",
            description="Show CPU and HDD temperatures",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main
        )
    ]