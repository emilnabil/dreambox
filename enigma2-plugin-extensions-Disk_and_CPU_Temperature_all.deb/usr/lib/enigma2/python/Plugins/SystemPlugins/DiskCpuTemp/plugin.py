# -*- coding: utf-8 -*-
from __future__ import print_function, division
import os
import sys
import subprocess
import re
import time
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.config import config, ConfigSubsection, ConfigSelection
from enigma import eTimer, getDesktop, gRGB
from Plugins.Plugin import PluginDescriptor

# Add the script folder path to sys.path
plugin_dir = os.path.dirname(os.path.realpath(__file__))
if plugin_dir not in sys.path:
    sys.path.append(plugin_dir)

# Import from our other modules
try:
    from temp_utilities import *
    from ui_screen import *
except ImportError as e:
    print("[DiskCpuTemp] Error importing modules: %s" % str(e))
    # Try to import the functions we need directly if the modules are not found
    # This is a fallback and might not work if the modules are essential
    # You might need to define fallback functions here or handle the error appropriately.

# Global variables
log_file = "/tmp/diskcputemp.log"

# HDD Warning thresholds
HDD_FIRST_WARNING_TEMP = 45
HDD_SECOND_WARNING_TEMP = 50
HDD_FINAL_WARNING_TEMP = 55

# CPU Warning thresholds
CPU_FIRST_WARNING_TEMP = 75
CPU_SECOND_WARNING_TEMP = 80
CPU_FINAL_WARNING_TEMP = 85

# Configuration setup
config.plugins.DiskCpuTemp = ConfigSubsection()
config.plugins.DiskCpuTemp.warning_duration = ConfigSelection(
    choices=[
        ("5000", "5 seconds"),
        ("10000", "10 seconds"),
        ("15000", "15 seconds"),
        ("20000", "20 seconds")
    ],
    default="5000"
)

# Save last chosen skin so it persists after restart
config.plugins.DiskCpuTemp.last_skin = ConfigSelection(
    choices=[
        ("Fhd1", "Fhd1"),
        ("Fhd2", "Fhd2")
    ],
    default="Fhd2"
)

# --------- Version from file ---------
plugin_path = os.path.dirname(os.path.realpath(__file__))
version_file = os.path.join(plugin_path, "version.txt")
plugin_version = "Unknown"
try:
    with open(version_file, "r") as f:
        plugin_version = f.read().strip()
        if not plugin_version:
            plugin_version = "Unknown"
except Exception as e:
    print("[Plugin] Error reading version.txt: %s" % str(e))
    plugin_version = "Unknown"

# Warning system variables
warning_active = False
warning_level = {"CPU": 0, "/dev/sda": 0, "/dev/sdb": 0}
warning_timer = None
warnings_enabled = True  # Global variable to control warning display

def log_message(message):
    try:
        with open(log_file, "a") as f:
            timestamp = time.strftime("%H:%M:%S")
            f.write("[%s] %s\n" % (timestamp, message))
    except:
        pass

def clear_log():
    try:
        with open(log_file, "w") as f:
            f.write("")
        log_message("Log file cleared")
    except:
        pass

# --- Main Screen Class ---
class DiskCpuTempScreen(Screen, UIScreenMethods):
    instance = None

    def __init__(self, session):
        self.session = session

        # detect screen resolution
        desktop_size = getDesktop(0).size()
        width = desktop_size.width()
        height = desktop_size.height()

        # Choose skin based on saved preference (persisted in config)
        try:
            skin_choice = config.plugins.DiskCpuTemp.last_skin.value
        except Exception:
            skin_choice = "Fhd2"

        if skin_choice == "Fhd1":
            skin = self._skin_fhd1()
        else:
            skin = self._skin_fhd2()

        self.skin = skin
        Screen.__init__(self, session)
        DiskCpuTempScreen.instance = self

        # Get warning duration from configuration
        try:
            warning_duration = int(config.plugins.DiskCpuTemp.warning_duration.value)
        except Exception:
            warning_duration = 5000
        log_message("Warning duration set to %d seconds" % (warning_duration / 1000))

        # Initialize header
        self["plugin_name"] = Label("Disk & CPU Temperature by Iet5")
        self["version"] = Label("v" + plugin_version)
        self["warning_bar"] = Label("")  # Initialize warning bar

        # Initialize other widgets
        self["cpu_label"] = Label("CPU Temp: Loading...")
        self["hdd1_label"] = Label("")
        self["hdd2_label"] = Label("")
        self["hdd3_label"] = Label("")
        self["hdd4_label"] = Label("")
        self["update_label"] = Label("Update every 5 Seconds")
        self["settings_label"] = Label("Warning Duration: %d seconds" % (warning_duration / 1000))
        self["settings_hint"] = Label("Press UP/DOWN to change warning duration")
        self["exit_button"] = Label("Exit")
        self["save_button"] = Label("Save")
        self["change_skin_button"] = Label("Change Skin")
        self["stop_warning_button"] = Label("Stop Warning")

        # Action map
        self["actions"] = ActionMap(
            ["SetupActions", "OkCancelActions", "ChannelSelectActions",
             "InfobarChannelSelection", "DirectionActions", "NumberActions", "ColorActions"], {
                "ok": self.close,
                "cancel": self.close,
                "red": self.exit_plugin,
                "green": self.save_only,
                "yellow": self.change_skin,
                "blue": self.toggle_warnings,
                "up": self.increase_duration,
                "down": self.decrease_duration
            }, -1
        )

        # Timer setup
        self.updateTimer = eTimer()
        try:
            # Try to connect both possible interfaces (compatibility)
            self.updateTimer_conn = self.updateTimer.timeout.connect(self.updateTemps)
        except:
            try:
                self.updateTimer.callback.append(self.updateTemps)
            except:
                log_message("Failed to connect timer to updateTemps")
                self.updateTimer = None

        log_message("Initializing DiskCpuTempScreen")
        self.onShown.append(self.startTimer)
        self.onHide.append(self.stopTimer)

        log_message("Screen initialization complete")

    def __del__(self):
        # Clean up resources
        try:
            if hasattr(self, 'updateTimer') and self.updateTimer is not None:
                self.updateTimer.stop()
                self.updateTimer = None
        except:
            pass

        # Clear instance reference
        if DiskCpuTempScreen.instance == self:
            DiskCpuTempScreen.instance = None

    # --- Temperature update --- 
    def get_cpu_temp(self):
        try:
            if not os.path.exists("/sys/class/thermal/thermal_zone0/temp"):
                return "N/A"
            with open("/sys/class/thermal/thermal_zone0/temp", "r") as f:
                raw = f.read().strip()
                try:
                    temp = int(raw)
                    # if value looks like millidegree
                    if temp > 1000:
                        temp = temp / 1000.0
                    else:
                        temp = float(temp)
                    return "%.1f C" % temp
                except:
                    return "N/A"
        except:
            return "N/A"

# --- Main Functions ---
def main(session, **kwargs):
    try:
        clear_log()
        log_message("Plugin started - opening screen")
        session.open(DiskCpuTempScreen)
        log_message("Screen opened successfully")
    except Exception as e:
        log_message("Error opening screen: %s" % str(e))

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Disk & CPU Temperature by Iet5",
            description="Show CPU and HDD/SSD/NVMe temperatures",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main
        )
    ]