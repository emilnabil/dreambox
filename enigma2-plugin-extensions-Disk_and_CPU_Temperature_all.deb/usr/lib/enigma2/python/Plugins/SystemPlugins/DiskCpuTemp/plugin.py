# -*- coding: utf-8 -*-
from __future__ import print_function
from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap
from Plugins.Plugin import PluginDescriptor
from enigma import eTimer
import os
import subprocess
import re
import time

# Plugin version
PLUGIN_VERSION = "1.0"

# Create a log file
log_file = "/tmp/diskcputemp.log"

def clear_log():
    """Clear Log File"""
    try:
        with open(log_file, "w") as f:
            f.write("")  # Write an empty string to clear the content.
        log_message("Log file cleared")
    except:
        pass

def log_message(message):
    try:
        with open(log_file, "a") as f:
            timestamp = time.strftime("%H:%M:%S")
            f.write("[%s] %s\n" % (timestamp, message))
    except:
        pass

class DiskCpuTempScreen(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        log_message("Initializing DiskCpuTempScreen")

        # Fixed skin without title attribute to prevent default Enigma2 title
        self.skin = """
        <screen position="center,center" size="700,450" flags="wfNoBorder">
            <!-- Custom header with gray background -->
            <widget name="header_bg" position="0,0" size="700,40" backgroundColor="#333333"/>

            <!-- Plugin name on left -->
            <widget name="plugin_name" position="10,5" size="500,30" font="Regular;24" halign="left" foregroundColor="#FFD700" transparent="1"/>

            <!-- Version on right -->
            <widget name="version" position="600,5" size="90,30" font="Regular;24" halign="right" foregroundColor="#FFD700" transparent="1"/>

            <!-- Temperature display -->
            <widget name="cpu_label" position="50,60" size="600,50" font="Regular;28"/>
            <widget name="hdd1_label" position="50,140" size="600,50" font="Regular;28"/>
            <widget name="hdd2_label" position="50,220" size="600,50" font="Regular;28"/>
            <widget name="info_label" position="50,300" size="600,40" font="Regular;22"/>
            <widget name="update_label" position="50,350" size="600,40" font="Regular;22"/>
        </screen>"""
        
        # Initialize header
        self["header_bg"] = Label("")
        self["plugin_name"] = Label("Disk & CPU Temperature by Iet5")
        self["version"] = Label("v" + PLUGIN_VERSION)

        # Initialize temperature labels
        self["cpu_label"] = Label("CPU Temp: Loading...")
        self["hdd1_label"] = Label("HDD1 Temp: Loading...")
        self["hdd2_label"] = Label("HDD2 Temp: Loading...")
        self["info_label"] = Label("Press OK or EXIT to close")
        self["update_label"] = Label("update every 5 Second")

        # Actions
        self["actions"] = ActionMap(["SetupActions", "OkCancelActions"], {
            "ok": self.close,
            "cancel": self.close
        }, -1)

        # Timer setup ������ �� Python 2.7
        self.updateTimer = eTimer()
        try:
            # update every 5 Second 
            self.updateTimer.timeout.get().append(self.updateTemps)
        except Exception as e:
            log_message("Timeout append failed, trying callback: %s" % str(e))
            try:
                self.updateTimer.callback = self.updateTemps
            except Exception as e2:
                log_message("Failed to assign timer callback: %s" % str(e2))

        self.onShown.append(self.startTimer)
        self.onHide.append(self.stopTimer)

        log_message("Screen initialization complete")

    def startTimer(self):
        # Start the timer with 5-second interval
        if self.updateTimer is not None:
            self.updateTimer.start(5000)  
            log_message("Timer started with 5000ms interval")
        self.updateTemps()  # Update immediately

    def stopTimer(self):
        # Stop the timer when screen is closed
        if self.updateTimer is not None:
            self.updateTimer.stop()
            log_message("Timer stopped")

    def updateTemps(self):
        log_message("Starting temperature update")
        try:
            # CPU temperature
            cpu_temp = self.get_cpu_temp()
            log_message("CPU temp: " + cpu_temp)
            self["cpu_label"].setText(str("CPU Temp: %s" % cpu_temp))
            
            # HDD temperatures
            hdd1_temp = self.get_hdd_temp_smartctl("/dev/sda")
            log_message("HDD1 temp: " + hdd1_temp)
            self["hdd1_label"].setText(str("HDD1 Temp: %s" % hdd1_temp))
            
            hdd2_temp = self.get_hdd_temp_smartctl("/dev/sdb")
            log_message("HDD2 temp: " + hdd2_temp)
            self["hdd2_label"].setText(str("HDD2 Temp: %s" % hdd2_temp))
            
            log_message("Update #%d - Temperature update complete" % self.update_count)
        except Exception as e:
            log_message("Error in updateTemps: " + str(e))

    def get_cpu_temp(self):
        try:
            if not os.path.exists("/sys/class/thermal/thermal_zone0/temp"):
                return "N/A"
            with open("/sys/class/thermal/thermal_zone0/temp", "r") as f:
                temp = int(f.read().strip()) / 1000.0
                return "%.1f C" % temp
        except:
            return "N/A"

    def get_hdd_temp_smartctl(self, device="/dev/sda"):
        try:
            if not os.path.exists(device):
                log_message("Device %s does not exist" % device)
                return "N/A (no device)"
                
            # Check if smartctl exists
            smartctl_path = None
            for path in ["/usr/sbin/smartctl", "/bin/smartctl", "/sbin/smartctl"]:
                if os.path.exists(path):
                    smartctl_path = path
                    break
            
            if not smartctl_path:
                log_message("smartctl not found")
                return "N/A (smartctl missing)"

            # Try different smartctl command options
            commands = [
                [smartctl_path, "-A", "-d", "sat", device],
                [smartctl_path, "-A", "-d", "ata", device],
                [smartctl_path, "-A", device]
            ]
            
            output = None
            for cmd in commands:
                try:
                    output = subprocess.check_output(cmd, stderr=subprocess.STDOUT)
                    log_message("Used command: %s" % " ".join(cmd))
                    break
                except subprocess.CalledProcessError as e:
                    log_message("Command failed: %s, error: %s" % (" ".join(cmd), str(e)))
                    continue
            
            if output is None:
                log_message("All smartctl commands failed for device: %s" % device)
                return "N/A (smartctl error)"

            if isinstance(output, bytes):
                output = output.decode("utf-8", "ignore")

            log_message("Smartctl output: %s" % output[:200])  # Log first 200 characters

            patterns = [
                r"194 Temperature_Celsius.*?(\d+)\s*\([^)]*\)$",  # For /dev/sdb format
                r"190 Airflow_Temperature_Cel.*?(\d+)\s*\([^)]*\)$",  # Alternative attribute
                r"Temperature_Celsius.*?\s+\d+\s+\d+\s+\d+\s+\S+\s+\S+\s+\S+\s+(\d+)",  # General pattern
                r"Current Drive Temperature.*?(\d+)",  # Some drives use this format
            ]

            for line in output.split("\n"):
                if "Temperature" in line or "Airflow" in line:
                    log_message("Temperature line: %s" % line)
                    for pattern in patterns:
                        match = re.search(pattern, line, re.IGNORECASE)
                        if match:
                            temp = match.group(1)
                            log_message("Found temperature for %s: %s" % (device, temp))
                            return "%s C" % temp

            log_message("No temperature found in smartctl output for device: %s" % device)
            return "N/A (no temp)"
        except Exception as e:
            log_message("Exception in get_hdd_temp_smartctl for %s: %s" % (device, str(e)))
            return "N/A"

def main(session, **kwargs):
    try:
        clear_log()  # Clear Log before start
        log_message("Plugin started - opening screen")
        session.open(DiskCpuTempScreen)
        log_message("Screen opened successfully")
    except Exception as e:
        log_message("Error opening screen: " + str(e))

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Disk & CPU Temperature by Iet5",
            description="Show CPU and HDD temperatures",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main
        )
    ]