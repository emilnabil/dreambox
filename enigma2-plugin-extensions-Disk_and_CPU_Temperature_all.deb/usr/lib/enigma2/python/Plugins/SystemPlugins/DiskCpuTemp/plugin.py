# -*- coding: utf-8 -*-
from __future__ import print_function
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.config import config, ConfigSubsection, ConfigSelection
from Plugins.Plugin import PluginDescriptor
from enigma import eTimer, getDesktop
import os
import subprocess
import re
import time

PLUGIN_VERSION = "1.2.2"

log_file = "/tmp/diskcputemp.log"

# HDD Warning thresholds
HDD_FIRST_WARNING_TEMP = 45
HDD_SECOND_WARNING_TEMP = 50
HDD_FINAL_WARNING_TEMP = 55

# CPU Warning thresholds
CPU_FIRST_WARNING_TEMP = 75
CPU_SECOND_WARNING_TEMP = 80
CPU_FINAL_WARNING_TEMP = 85

# Configuration setup
config.plugins.DiskCpuTemp = ConfigSubsection()
config.plugins.DiskCpuTemp.warning_duration = ConfigSelection(
    choices=[
        ("5000", "5 seconds"),
        ("10000", "10 seconds"),
        ("15000", "15 seconds"),
        ("20000", "20 seconds")
    ],
    default="5000"
)

# Warning system variables
warning_active = False
warning_level = {"CPU": 0, "/dev/sda": 0, "/dev/sdb": 0}
warning_timer = None
warnings_enabled = True

def log_message(message):
    try:
        with open(log_file, "a") as f:
            timestamp = time.strftime("%H:%M:%S")
            f.write("[%s] %s\n" % (timestamp, message))
    except:
        pass

def clear_log():
    try:
        with open(log_file, "w") as f:
            f.write("")
    except:
        pass

def wake_up_hdd(device_path):
    """Wake up HDD from sleep using hdparm command"""
    try:
        log_message("Waking up HDD: %s" % device_path)
        hdparm_path = None
        for path in ["/sbin/hdparm", "/usr/sbin/hdparm", "/bin/hdparm"]:
            if os.path.exists(path):
                hdparm_path = path
                break
        
        if hdparm_path:
            p = subprocess.Popen([hdparm_path, "-S0", device_path], 
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out, err = p.communicate()
            if p.returncode == 0:
                time.sleep(2)
                return True
        return False
    except Exception as e:
        return False

def extract_temperature_value(temp_string):
    """Extract numeric temperature value from string"""
    try:
        if "N/A" in str(temp_string):
            return None
            
        patterns = [
            r'(\d+(\.\d+)?)\s*C',
            r'Temperature[^:]*:\s*(\d+)',
            r'(\d+)$',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, str(temp_string), re.IGNORECASE)
            if match:
                return float(match.group(1))
                
        return None
    except:
        return None

def temp_to_color(temp, device_type="CPU"):
    try:
        temp_value = extract_temperature_value(temp)
        if temp_value is None:
            return "#FFFFFF"
    except:
        return "#FFFFFF"

    if device_type == "CPU":
        min_temp, max_temp = 30.0, 85.0
    else:
        min_temp, max_temp = 25.0, 50.0

    temp_value = max(min_temp, min(temp_value, max_temp))
    norm = (temp_value - min_temp) / (max_temp - min_temp)

    if norm < 0.5:
        r = int(2 * norm * 255)
        g = 255
    else:
        r = 255
        g = int((1 - 2 * (norm - 0.5)) * 255)

    b = 0
    return "#%02X%02X%02X" % (r, g, b)

def check_temperature_warnings(device_type, device_name, temperature):
    global warning_active, warning_level

    try:
        temp_value = extract_temperature_value(temperature)
        if temp_value is None:
            return

        if device_type == "HDD" and temp_value > 80:
            return
            
        if device_name not in warning_level:
            warning_level[device_name] = 0

        if device_type == "CPU":
            first, second, final = CPU_FIRST_WARNING_TEMP, CPU_SECOND_WARNING_TEMP, CPU_FINAL_WARNING_TEMP
        else:
            first, second, final = HDD_FIRST_WARNING_TEMP, HDD_SECOND_WARNING_TEMP, HDD_FINAL_WARNING_TEMP

        if temp_value >= final and warning_level[device_name] < 3:
            show_warning(device_name, 3, temp_value)
            warning_level[device_name] = 3
        elif temp_value >= second and warning_level[device_name] < 2:
            show_warning(device_name, 2, temp_value)
            warning_level[device_name] = 2
        elif temp_value >= first and warning_level[device_name] < 1:
            show_warning(device_name, 1, temp_value)
            warning_level[device_name] = 1
        elif temp_value < first and warning_level[device_name] > 0:
            warning_level[device_name] = 0
            clear_warning_bar(device_name)
            if all(level == 0 for level in warning_level.values()):
                try:
                    if DiskCpuTempScreen.instance:
                        DiskCpuTempScreen.instance.clear_warning_bar()
                except:
                    pass

    except Exception:
        pass

def show_warning(device_name, level, temperature_value):
    global warning_active, warning_timer, warnings_enabled

    if not warnings_enabled:
        return

    try:
        warning_duration = int(config.plugins.DiskCpuTemp.warning_duration.value)
        timeout_seconds = warning_duration / 1000
    except Exception:
        warning_duration = 5000
        timeout_seconds = 5

    if device_name == "CPU":
        name_display = "CPU"
        temp_display = "%.1f C" % temperature_value
    else:
        name_display = "HDD1" if device_name == "/dev/sda" else "HDD2"
        temp_display = "%d C" % temperature_value

    if level == 1:
        message = "First warning: %s temperature %s" % (name_display, temp_display)
        warning_bar_text = "FIRST WARNING: %s TEMP %s" % (name_display, temp_display)
    elif level == 2:
        message = "Second warning: %s temperature %s" % (name_display, temp_display)
        warning_bar_text = "SECOND WARNING: %s TEMP %s" % (name_display, temp_display)
    else:
        message = "Final warning: %s temperature %s" % (name_display, temp_display)
        warning_bar_text = "FINAL WARNING: %s TEMP %s" % (name_display, temp_display)

    log_message("WARNING: " + message)

    try:
        if DiskCpuTempScreen.instance and DiskCpuTempScreen.instance.session:
            DiskCpuTempScreen.instance.session.open(
                MessageBox, str(message), type=MessageBox.TYPE_ERROR, timeout=timeout_seconds
            )
    except:
        pass

    try:
        if DiskCpuTempScreen.instance:
            DiskCpuTempScreen.instance.show_warning_bar(warning_bar_text)
    except:
        pass

    try:
        if warning_timer:
            warning_timer.stop()
    except:
        pass

    try:
        warning_timer = eTimer()
        try:
            warning_timer.timeout.get().append(clear_warning)
        except:
            warning_timer.callback.append(clear_warning)
        warning_timer.start(warning_duration, 1)
    except:
        pass
    warning_active = True

def clear_warning():
    global warning_active
    warning_active = False

def clear_warning_bar(device_name):
    try:
        if DiskCpuTempScreen.instance:
            if all(level == 0 for level in warning_level.values()):
                DiskCpuTempScreen.instance.clear_warning_bar()
    except:
        pass

def get_hdd_temps():
    smartctl_path = "/usr/sbin/smartctl"
    devices = [d for d in os.listdir("/dev/") if d.startswith("sd") and len(d) == 3]
    devices = sorted(devices)
    results = {}

    for i, dev in enumerate(devices[:2]):
        device_path = "/dev/%s" % dev
        temp_found = None

        wake_up_hdd(device_path)
        
        commands = [
            [smartctl_path, "-A", "-d", "sat", device_path],
            [smartctl_path, "-A", "-d", "ata", device_path],
            [smartctl_path, "-A", device_path],
            [smartctl_path, "-a", "-d", "sat", device_path],
            [smartctl_path, "-a", "-d", "ata", device_path],
            [smartctl_path, "-a", device_path]
        ]
        try:
            output = None
            for cmd in commands:
                try:
                    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    out, error = p.communicate()
                    if p.returncode == 0:
                        output = out.decode("utf-8", "ignore")
                        break
                except:
                    continue

            if not output:
                continue

            for line in output.splitlines():
                if "Temperature" in line or "Airflow" in line or "Drive Temperature" in line:
                    match = re.search(r"(\d+)\s*C", line)
                    if match:
                        temp_found = "%s C" % match.group(1)
                        break

        except:
            continue

        if temp_found:
            if i == 0:
                results["HDD1"] = temp_found
            elif i == 1:
                results["HDD2"] = temp_found

    # if you have only one HDD
    if len(results) == 1:
        results["HDD2"] = "N/A"

    return results

class DiskCpuTempScreen(Screen):
    instance = None

    def __init__(self, session):
        self.session = session

        # detect screen resolution
        desktop_size = getDesktop(0).size()
        width = desktop_size.width()
        height = desktop_size.height()

        if width >= 1920:
            skin = self._skin_fullhd()
        else:
            skin = self._skin_hd()

        self.skin = skin
        Screen.__init__(self, session)
        DiskCpuTempScreen.instance = self

        try:
            warning_duration = int(config.plugins.DiskCpuTemp.warning_duration.value)
        except Exception:
            warning_duration = 5000

        self["plugin_name"] = Label("Disk & CPU Temperature by Iet5")
        self["version"] = Label("v" + PLUGIN_VERSION)
        self["warning_bar"] = Label("")
        self["cpu_label"] = Label("CPU Temp: Loading...")
        self["hdd1_label"] = Label("")
        self["hdd2_label"] = Label("")
        self["update_label"] = Label("Update every 5 Seconds")
        self["settings_label"] = Label("Warning Duration: %d seconds" % (warning_duration / 1000))
        self["settings_hint"] = Label("Press UP/DOWN to change warning duration")
        self["exit_button"] = Label("Exit")
        self["save_button"] = Label("Save")
        self["default_button"] = Label("Default")
        self["stop_warning_button"] = Label("Stop Warning")

        self["actions"] = ActionMap(
            ["SetupActions", "OkCancelActions", "ChannelSelectActions", "InfobarChannelSelection", "DirectionActions", "NumberActions", "ColorActions"], {
                "ok": self.save_and_close,
                "cancel": self.save_and_close,
                "green": self.save_only,
                "yellow": self.reset_to_default,
                "blue": self.toggle_warnings,
                "up": self.increase_duration,
                "down": self.decrease_duration
            }, -1
        )

        self.updateTimer = eTimer()
        try:
            self.updateTimer_conn = self.updateTimer.timeout.connect(self.updateTemps)
        except:
            try:
                self.updateTimer.callback.append(self.updateTemps)
            except:
                pass

        self.onShown.append(self.startTimer)
        self.onHide.append(self.stopTimer)

    def _skin_hd(self):
        return """
        <screen name="DiskCpuTempScreen" position="center,center" size="720,530" title="" flags="wfNoBorder">
            <widget name="plugin_name" position="20,8" size="450,25" font="Regular;26" halign="left" foregroundColor="#FFFF00" transparent="1"/>
            <widget name="version" position="580,8" size="120,25" font="Regular;26" halign="right" foregroundColor="#FFFF00" transparent="1"/>
            <widget name="warning_bar" position="20,150" size="680,36" font="Regular;36" halign="center" foregroundColor="#FF0000" transparent="1"/>

            <!-- Buttons -->
            <widget name="exit_button" position="60,65" size="138,30" font="Regular;22" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#FF0000" transparent="0"/>
            <widget name="save_button" position="210,65" size="138,30" font="Regular;21" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#00FF00" transparent="0"/>
            <widget name="default_button" position="360,65" size="138,30" font="Regular;22" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#FFFF00" transparent="0"/>
            <widget name="stop_warning_button" position="510,65" size="138,30" font="Regular;20" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#0000FF" transparent="0"/>      

            <!-- Content section -->
            <widget name="cpu_label" position="20,210" size="680,34" font="Regular;24" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="hdd1_label" position="20,250" size="680,34" font="Regular;24" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="hdd2_label" position="20,290" size="680,34" font="Regular;24" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="settings_label" position="20,360" size="680,30" font="Regular;20" halign="center" foregroundColor="#00FF00" transparent="1"/>
            <widget name="update_label" position="20,390" size="680,30" font="Regular;20" halign="center" foregroundColor="#00BFFF" transparent="1"/>
            <widget name="settings_hint" position="20,430" size="680,30" font="Regular;20" halign="center" foregroundColor="#FFFF00" transparent="1"/>
        </screen>
        """

    def _skin_fullhd(self):
        return """
        <screen name="DiskCpuTempScreen" position="center,center" size="900,630" title="" flags="wfNoBorder">
            <widget name="plugin_name" position="30,13" size="540,30" font="Regular;28" halign="left" foregroundColor="#FFFF00" transparent="1"/>
            <widget name="version" position="750,13" size="120,30" font="Regular;28" halign="right" foregroundColor="#FFFF00" transparent="1"/>
            <widget name="warning_bar" position="30,150" size="840,40" font="Regular;28" halign="center" foregroundColor="#FF0000" transparent="1"/>

            <!-- Buttons -->
            <widget name="exit_button" position="104,75" size="172,35" font="Regular;24" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#FF0000" transparent="0"/>
            <widget name="save_button" position="284,75" size="172,35" font="Regular;24" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#00FF00" transparent="0"/>
            <widget name="default_button" position="464,75" size="172,35" font="Regular;24" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#FFFF00" transparent="0"/>
            <widget name="stop_warning_button" position="644,75" size="172,35" font="Regular;24" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#0000FF" transparent="0"/>

            <!-- Content section -->
            <widget name="cpu_label" position="30,220" size="840,36" font="Regular;28" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="hdd1_label" position="30,280" size="840,36" font="Regular;28" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="hdd2_label" position="30,330" size="840,36" font="Regular;28" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="settings_label" position="30,430" size="840,32" font="Regular;26" halign="center" foregroundColor="#00FF00" transparent="1"/>
            <widget name="update_label" position="30,470" size="840,32" font="Regular;26" halign="center" foregroundColor="#00BFFF" transparent="1"/>
            <widget name="settings_hint" position="30,510" size="840,32" font="Regular;26" halign="center" foregroundColor="#FFFF00" transparent="1"/>
        </screen>
        """

    def save_and_close(self):
        try:
            config.plugins.DiskCpuTemp.warning_duration.save()
        except:
            pass
        self.close()

    def save_only(self):
        try:
            config.plugins.DiskCpuTemp.warning_duration.save()
            self.show_temp_confirmation("Settings saved")
        except:
            pass

    def reset_to_default(self):
        config.plugins.DiskCpuTemp.warning_duration.value = "5000"
        config.plugins.DiskCpuTemp.warning_duration.save()
        self["settings_label"].setText("Warning Duration: 5 seconds")
        self.show_temp_confirmation("Reset to default: 5 seconds")

    def toggle_warnings(self):
        global warnings_enabled, warning_level
        warnings_enabled = not warnings_enabled

        if warnings_enabled:
            for device in warning_level:
                warning_level[device] = 0
            self["stop_warning_button"].setText("Stop Warning")
            self.show_temp_confirmation("Warnings enabled")
        else:
            self["stop_warning_button"].setText("Warnings stopped")
            self.clear_warning_bar()
            self.show_temp_confirmation("Warnings disabled")

    def startTimer(self):
        if self.updateTimer is not None:
            try:
                self.updateTimer.start(5000)
            except:
                pass
        self.updateTemps()

    def stopTimer(self):
        if self.updateTimer is not None:
            try:
                self.updateTimer.stop()
            except:
                pass

    def increase_duration(self):
        try:
            current_value = config.plugins.DiskCpuTemp.warning_duration.value
            choices = config.plugins.DiskCpuTemp.warning_duration.choices

            current_index = 0
            for i, choice in enumerate(choices):
                value = choice[0] if isinstance(choice, tuple) else choice
                if value == current_value:
                    current_index = i
                    break

            if current_index < len(choices) - 1:
                next_choice = choices[current_index + 1]
                new_value = next_choice[0] if isinstance(next_choice, tuple) else next_choice
                config.plugins.DiskCpuTemp.warning_duration.value = new_value
                config.plugins.DiskCpuTemp.warning_duration.save()

                try:
                    warning_duration = int(new_value) / 1000
                except:
                    warning_duration = int(new_value) if isinstance(new_value, int) else 5
                self["settings_label"].setText("Warning Duration: %d seconds" % warning_duration)
                self.show_temp_confirmation("Duration: %d seconds" % warning_duration)
        except:
            pass

    def decrease_duration(self):
        try:
            current_value = config.plugins.DiskCpuTemp.warning_duration.value
            choices = config.plugins.DiskCpuTemp.warning_duration.choices

            current_index = 0
            for i, choice in enumerate(choices):
                value = choice[0] if isinstance(choice, tuple) else choice
                if value == current_value:
                    current_index = i
                    break

            if current_index > 0:
                prev_choice = choices[current_index - 1]
                new_value = prev_choice[0] if isinstance(prev_choice, tuple) else prev_choice
                config.plugins.DiskCpuTemp.warning_duration.value = new_value
                config.plugins.DiskCpuTemp.warning_duration.save()

                try:
                    warning_duration = int(new_value) / 1000
                except:
                    warning_duration = int(new_value) if isinstance(new_value, int) else 5
                self["settings_label"].setText("Warning Duration: %d seconds" % warning_duration)
                self.show_temp_confirmation("Duration: %d seconds" % warning_duration)
        except:
            pass

    def show_temp_confirmation(self, message):
        try:
            original_text = self["settings_label"].text
        except:
            original_text = ""
        try:
            self["settings_label"].setText(message)
        except:
            pass

        try:
            self.confirm_timer = eTimer()
            try:
                self.confirm_timer_conn = self.confirm_timer.timeout.connect(lambda: self.restore_settings_label(original_text))
            except:
                self.confirm_timer.callback.append(lambda: self.restore_settings_label(original_text))
            self.confirm_timer.start(2000, True)
        except:
            pass
    
    def restore_settings_label(self, text):
        try:
            self["settings_label"].setText(text)
        except:
            pass

    def updateSettingsDisplay(self):
        try:
            warning_duration = int(config.plugins.DiskCpuTemp.warning_duration.value)
            self["settings_label"].setText("Warning Duration: %d seconds" % (warning_duration / 1000))
        except:
            try:
                self["settings_label"].setText("Warning Duration: %s" % str(config.plugins.DiskCpuTemp.warning_duration.value))
            except:
                pass

    def show_warning_bar(self, message):
        try:
            self["warning_bar"].setText(message)
        except:
            pass

    def clear_warning_bar(self):
        try:
            self["warning_bar"].setText("")
        except:
            pass

    def updateTemps(self):
        try:
            self.updateSettingsDisplay()

            cpu_temp = self.get_cpu_temp()
            try:
                self["cpu_label"].setText("CPU Temp: %s" % cpu_temp)
                self["cpu_label"].instance.setForegroundColor(temp_to_color(cpu_temp, "CPU"))
            except:
                pass
            check_temperature_warnings("CPU", "CPU", cpu_temp)

            hdd_temps = get_hdd_temps()
            
            if hdd_temps and ("HDD1" in hdd_temps or "HDD2" in hdd_temps):
                if "HDD1" in hdd_temps:
                    hdd1_temp = hdd_temps["HDD1"]
                    try:
                        self["hdd1_label"].setText("HDD1 Temp: %s" % hdd1_temp)
                        self["hdd1_label"].instance.setForegroundColor(temp_to_color(hdd1_temp, "HDD"))
                    except:
                        pass
                    check_temperature_warnings("HDD", "/dev/sda", hdd1_temp)
                else:
                    self["hdd1_label"].setText("")

                if "HDD2" in hdd_temps:
                    hdd2_temp = hdd_temps["HDD2"]
                    try:
                        self["hdd2_label"].setText("HDD2 Temp: %s" % hdd2_temp)
                        self["hdd2_label"].instance.setForegroundColor(temp_to_color(hdd2_temp, "HDD"))
                    except:
                        pass
                    check_temperature_warnings("HDD", "/dev/sdb", hdd2_temp)
                else:
                    self["hdd2_label"].setText("")
                    
            else:
                hdd_count = 0

                if os.path.exists("/dev/sda"):
                    hdd1_temp = self.get_hdd_temp_smartctl("/dev/sda")
                    try:
                        self["hdd1_label"].setText(str("HDD1 Temp: %s" % hdd1_temp))
                        self["hdd1_label"].instance.setForegroundColor(temp_to_color(hdd1_temp, "HDD"))
                    except:
                        pass
                    hdd_count += 1
                    check_temperature_warnings("HDD", "/dev/sda", hdd1_temp)
                else:
                    self["hdd1_label"].setText("")

                if os.path.exists("/dev/sdb"):
                    hdd2_temp = self.get_hdd_temp_smartctl("/dev/sdb")
                    try:
                        self["hdd2_label"].setText(str("HDD2 Temp: %s" % hdd2_temp))
                        self["hdd2_label"].instance.setForegroundColor(temp_to_color(hdd2_temp, "HDD"))
                    except:
                        pass
                    hdd_count += 1
                    check_temperature_warnings("HDD", "/dev/sdb", hdd2_temp)
                else:
                    self["hdd2_label"].setText("")

                if not os.path.exists("/dev/sda") and not os.path.exists("/dev/sdb"):
                    self["hdd1_label"].setText("There is no hdd found")

        except:
            pass

        try:
            if self.updateTimer is not None:
                self.updateTimer.start(5000, True)
        except:
            pass

    def get_cpu_temp(self):
        try:
            if not os.path.exists("/sys/class/thermal/thermal_zone0/temp"):
                return "N/A"
            with open("/sys/class/thermal/thermal_zone0/temp", "r") as f:
                temp = int(f.read().strip()) / 1000.0

            return "%.1f C" % temp
        except:
            return "N/A"

    def get_hdd_temp_smartctl(self, device="/dev/sda"):
        try:
            # Check if smartctl exists
            smartctl_path = None
            for path in ["/usr/sbin/smartctl", "/bin/smartctl", "/sbin/smartctl"]:
                if os.path.exists(path):
                    smartctl_path = path
                    break

            if not smartctl_path:
                return "N/A (smartctl missing)"

            wake_up_hdd(device)

            commands = [
                [smartctl_path, "-A", device],
                [smartctl_path, "-a", device],
                [smartctl_path, "-A", "-d", "sat", device],
                [smartctl_path, "-a", "-d", "sat", device],
                [smartctl_path, "-A", "-d", "ata", device],
                [smartctl_path, "-a", "-d", "ata", device],
            ]

            output = None
            for cmd in commands:
                try:
                    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    output, error = p.communicate()
                    if p.returncode == 0:
                        break
                except:
                    continue

            if output is None:
                return "N/A (smartctl error)"

            if isinstance(output, bytes):
                output = output.decode("utf-8", "ignore")

            patterns = [
                r"194 Temperature_Celsius.*?(\d+)\s*\([^)]*\)$",
                r"190 Airflow_Temperature_Cel.*?(\d+)\s*\([^)]*\)$",
                r"Temperature_Celsius.*?\s+\d+\s+\d+\s+\d+\s+\S+\s+\S+\s+\S+\s+(\d+)",
                r"Current Drive Temperature.*?(\d+)",
                r"Temperature.*?(\d+)\s*C",
                r"Drive Temperature.*?(\d+)",
                r"(\d+)\s*Celsius",
                r"(\d+)\s*C\b"
            ]

            for line in output.split("\n"):
                if "Temperature" in line or "Airflow" in line or "Drive Temperature" in line:
                    for pattern in patterns:
                        match = re.search(pattern, line, re.IGNORECASE)
                        if match:
                            temp = match.group(1)
                            return "%s C" % temp

            temp_match = re.search(r"(\d+)\s*(?:Celsius|C)", output, re.IGNORECASE)
            if temp_match:
                temp = temp_match.group(1)
                return "%s C" % temp

            return "N/A (no temp)"
        except:
            return "N/A"

def main(session, **kwargs):
    try:
        clear_log()
        session.open(DiskCpuTempScreen)
    except:
        pass

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Disk & CPU Temperature by iet5",
            description="Show CPU and HDD temperatures",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main
        )
    ]