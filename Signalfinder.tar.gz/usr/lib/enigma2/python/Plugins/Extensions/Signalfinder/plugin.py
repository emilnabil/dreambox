import sys, os
from time import time
from math import log10, log
from enigma import eTimer, eDVBResourceManager, eDVBFrontendParameters, ePoint, iFrontendInformation, \
  eDVBFrontendParametersSatellite, eDVBFrontendParametersCable, eDVBFrontendParametersTerrestrial
from enigma import eConsoleAppContainer

from Screens.Screen import Screen
from Screens.ScanSetup import ScanSetup
from Screens.MessageBox import MessageBox
from Screens.Console import Console
from Plugins.Plugin import PluginDescriptor
from Tools.Directories import fileExists

from Components.ActionMap import ActionMap
from Components.config import config, ConfigSelection, getConfigListEntry
from Components.Label import Label
from Components.NimManager import nimmanager, getConfigSatlist
from Components.Pixmap import Pixmap
from Components.Sources.CanvasSource import CanvasSource
from Components.Sources.Progress import Progress
from Components.Sources.StaticText import StaticText
from Components.MenuList import MenuList

dvbsnoop = "dvbsnoop -hideproginfo -devnr "

################################################################################

class readPID(Console):
  skin = """
  <screen position="center,160" size="1000,430" title="Command execution..." >
  <widget name="text" position="0,0" size="1000,430" font="Console;14" />
  </screen>"""
		
  def __init__(self, session, title, cmdlist):
    Console.__init__(self, session, title, cmdlist)
    self["actions"] = ActionMap(["WizardActions"], 
    {
	"ok": self.cancel,
	"back": self.cancel,
	"up": self["text"].pageUp,
	"down": self["text"].pageDown,
	"right": self["text"].lastPage,
	"left": self.firstPage
    }, -1)

  def firstPage(self):
    self["text"].long_text.move(ePoint(0,0))
    self["text"].updateScrollbar()

################################################################################

class PIDsMenu(Screen):
  skin = """
  <screen position="center,160" size="1000,430" title="Transponder PID-Scan" >
  <widget name="myMenu" position="5,0" size="990,425" scrollbarMode="showOnDemand" />
  </screen>"""

  def __init__(self, session, list, demux):
    Screen.__init__(self, session)
    self.demux = demux
    self["myMenu"] = MenuList(list)
    self["actions"] = ActionMap(["WizardActions", "DirectionActions"], 
    {
      "ok": self.go,
      "back": self.close,
    }, -1)

  def go(self):
    returnValue = self["myMenu"].l.getCurrentSelection()
    pid = int(returnValue[0:4])
    cmd1 = "%s %s -s bandwidth %d -pd 1 -n 1" %(dvbsnoop, self.demux, pid)
    if returnValue.find("[SECTION:") > 1: 
      cmd2 = "%s %d %d -pd 4 -n 1 " %(dvbsnoop, self.demux, pid)
    else:
      cmd2 = ""
    title = "PID " + str(pid) 
    self.session.open(readPID,_(title),[cmd1,cmd2])

################################################################################
class PIDsScan(Screen):
  skin = """
  <screen position="center,center" size="300,50" title="Please Wait" >
  <widget name="text" position="20,10" size="260,25" font="Regular;20"/>
  </screen>"""
		
  def __init__(self, session, demux):
    Screen.__init__(self, session)
    self["text"] = Label("Searching PIDs...")    
    self["actions"] = ActionMap(["WizardActions"], 
    {
      "back": self.cancel,
    }, -1)
    cmd = "%s %d -s pidscan" %(dvbsnoop, demux)
    self.demux = demux
    self.container = eConsoleAppContainer()
    self.run = 0
    self.str = ""
    self.container.appClosed.append(self.runFinished)
    self.container.dataAvail.append(self.dataAvail)
    if self.container.execute(cmd): #start of container application failed...
      self.runFinished(-1) # so we must call runFinished manual

  def runFinished(self, retval):
    self.run += 1
    list = []
    count = 0
    for line in self.str.splitlines():
      if line.startswith("PID found:"):
        list.append(line[11:])
        count += 1
    if count == 0:
      self["text"].setText(_("Nothing found !"))
    else:
      self.session.open(PIDsMenu, list, self.demux)
      self.cancel()

  def dataAvail(self, str):
    self.str = self.str + str

  def cancel(self):
    if self.run == 1:
      self.close()
      self.container.appClosed.remove(self.runFinished)
      self.container.dataAvail.remove(self.dataAvail)

        
################################################################################

class SignalfinderLCD(Screen):
  skin = """
  <screen position="0,0" size="132,64" id="1">
  <eLabel text="SNR:" position="6,0" size="54,16" font="Display;16" />
  <eLabel text="AGC:" position="6,16" size="54,16" font="Display;16" />
  <eLabel text="BER:" position="6,32" size="54,16" font="Display;16" />
  <eLabel text="Lock:" position="6,48" size="54,16" font="Display;16" />
  <widget source="parent.lcd_snr" render="Label" position="60,0" size="66,16" font="Display;16" />
  <widget source="parent.lcd_agc" render="Label" position="60,16" size="66,16" font="Display;16" />
  <widget source="parent.lcd_ber" render="Label" position="60,32" size="66,16" font="Display;16" />
  <widget source="parent.lcd_lock" render="Label" position="60,48" size="66,16" font="Display;16" />
  </screen>"""

################################################################################

class Signalfinder(ScanSetup):
  skin = """
  <screen position="center,110" size="620,540" title="Signalfinder">
  <widget name="scan_c" pixmap="skin_default/icons/scan-c.png" 
    position="40,20" zPosition="0" size="64,64" alphatest="on"/>
  <widget name="scan_s" pixmap="skin_default/icons/scan-s.png" 
    position="40,20" zPosition="0" size="64,64" alphatest="on"/>
  <widget name="scan_t" pixmap="skin_default/icons/scan-t.png" 
    position="40,20" zPosition="0" size="64,64" alphatest="on"/>
  <eLabel text="SNR:" position="170,10" size="60,25" font="Regular;21"/>
  <eLabel text="AGC:" position="170,35" size="60,25" font="Regular;21"/>
  <eLabel text="BER:" position="170,60" size="60,25" font="Regular;21"/>
  <eLabel text="Lock:" position="170,85" size="80,25" font="Regular;21"/>
  <widget source="snr_bar" render="Progress" position="240,10" size="260,20"
    pixmap="skin_default/bar_snr.png" borderWidth="2" borderColor="#cccccc"/>
  <widget source="agc_bar" render="Progress" position="240,35" size="260,20" 
    pixmap="skin_default/bar_snr.png" borderWidth="2" borderColor="#cccccc"/>
  <widget source="ber_bar" render="Progress" position="240,60" size="260,20" 
    pixmap="skin_default/bar_snr.png" borderWidth="2" borderColor="#cccccc"/>
  <widget name="lock_on" pixmap="skin_default/icons/lock_on.png" 
    position="260,85" zPosition="1" size="38,31" alphatest="on"/>
  <widget name="lock_off" pixmap="skin_default/icons/lock_off.png" 
    position="260,85" zPosition="1" size="38,31" alphatest="on"/>
  <widget name="snr_val" position="510,10" size="110,25" font="Regular;21"/>
  <widget name="agc_val" position="510,35" size="110,25" font="Regular;21"/>
  <widget name="ber_val" position="510,60" size="100,25" font="Regular;21"/>
  <eLabel position="10,130" size="600,1" backgroundColor="grey"/>
  <widget name="config" position="10,140" size="340,360" itemHeight="30" scrollbarMode="showOnDemand"/>
  <widget source="Canvas" render="Canvas" position="354,180" size="256,256"/>
  <widget name="Info" position="10,500" size="100,40" 
    backgroundColor="black" valign="center" halign="center" zPosition="2" 
    foregroundColor="white" font="Regular;20"/>
  <widget name="PIDs" position="120,500" size="100,40" 
    backgroundColor="red" valign="center" halign="center" zPosition="2" 
    foregroundColor="white" font="Regular;20"/>
  <widget name="Services" position="230,500" size="100,40" 
    backgroundColor="green" valign="center" halign="center" zPosition="2" 
    foregroundColor="white" font="Regular;20"/>
  <eLabel text="SNR Chart" position="340,500" size="100,40" 
    backgroundColor="yellow" valign="center" halign="center" zPosition="2" 
    foregroundColor="white" font="Regular;20"/>
  <eLabel text="Clear" position="450,500" size="100,40" 
    backgroundColor="blue" valign="center" halign="center" zPosition="2" 
    foregroundColor="white" font="Regular;20"/>
  </screen>"""

  def __init__(self, session):
    self.session = session
    self.initcomplete = False
    self.feid = 0
    self.oldref = None
    self.frontend = None
    self.default_sat = 192
    self.lock = False
    self.tuner_type = nimmanager.getNimType(self.feid)
    if self.tuner_type == "DVB-S2":
      self.tuner_type = "DVB-S"
    self.tunercount = len(nimmanager.nim_slots)
    self.constellation_supported = None
    self.service2 = session.nav.getCurrentService()
    if self.service2 is not None:
      feinfo = self.service2 and self.service2.frontendInfo()
      frontendData = feinfo and feinfo.getAll(False)
      if frontendData:
        self.feid = frontendData["tuner_number"]
        self.tuner_type = frontendData["tuner_type"]
        if self.tuner_type == "DVB-S":
          self.system = frontendData["system"]
          self.default_sat = frontendData["orbital_position"]
        elif self.tuner_type == "DVB-C":
          self.modulation = frontendData["modulation"]
      else: 
        self.service2 = None
    ScanSetup.__init__(self, session)
    self["Canvas"] = CanvasSource()
    self["snr_val"] = Label()
    self["agc_val"] = Label()
    self["ber_val"] = Label()
    self["snr_bar"] = Progress()
    self["snr_bar"].value = 0
    self["agc_bar"] = Progress()
    self["agc_bar"].value = 0
    self["ber_bar"] = Progress()
    self["ber_bar"].value = 0
    self["lock_on"] = Pixmap()
    self["lock_off"] = Pixmap()
    self["scan_c"] = Pixmap()
    self["scan_s"] = Pixmap()
    self["scan_t"] = Pixmap()
    self["lock_on"].visible = False
    self["lcd_snr"] = StaticText()
    self["lcd_agc"] = StaticText()
    self["lcd_ber"] = StaticText()
    self["lcd_lock"] = StaticText()
    self["Info"] = Label()
    self["PIDs"] = Label()
    self["Services"] = Label()
    self.showPicture(self.tuner_type)
    self.set_i2c(self.feid)
    self.clearConstellation()
    self.getConstellation()
    self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "EPGSelectActions"],
    {
      "cancel": self.keyCancel,
      "ok": self.keyGo,
      "red": self.startPIDsScan,
      "green": self.startServiceScan,
      "yellow": self.startScanner,
      "blue": self.clearConstellation,
      "info": self.setParameter,
    }, -1)
    self.update_interval = 500
    self.poll_timer = eTimer()
    if os.path.exists("/var/lib/dpkg/status"):
    	self.poll_timer_conn= self.poll_timer.timeout.connect(self.updateFrontendStatus)
    else:
    	self.poll_timer.callback.append(self.updateFrontendStatus)
    self.poll_timer.start(self.update_interval, True)
    if self.service2 is None:
      self.keyGo()		    

  def showPicture(self,type):
    self["scan_c"].visible = False
    self["scan_s"].visible = False
    self["scan_t"].visible = False
    if type == "DVB-S":
      self["scan_s"].visible = True
    elif type == "DVB-C":
      self["scan_c"].visible = True
    elif type == "DVB-T":
      self["scan_t"].visible = True
      
  def nextTuner(self):
    self.tuner_type = nimmanager.getNimType(self.feid)
    if self.tuner_type == "DVB-S2":
      self.tuner_type = "DVB-S"
    self.showPicture(self.tuner_type)
    self.set_i2c(self.feid)
    self.initcomplete = False
    self.poll_timer.stop()
    self.createConfig(None)
    self.createSetup()
    self.keyGo()
    
  def set_i2c(self,feid):
    self.bus = nimmanager.getI2CDevice(feid)
    self.tunername = nimmanager.getNimName(feid)
    if self.tunername=="CXD1981":
      self.i2c_adr = 0x6e
      self.i2c_reg = 0x2e
    else: #CU1216
      self.i2c_adr = 0x0c
      self.i2c_reg = 0x39
    
  def openFrontend(self):
    res_mgr = eDVBResourceManager.getInstance()
    if res_mgr:
      self.raw_channel = res_mgr.allocateRawChannel(self.feid)
      if self.raw_channel:
	self.frontend = self.raw_channel.getFrontend()
	if self.frontend:
	  return True
	else:
	  print "getFrontend failed"
      else:
	print "getRawChannel failed"
    else:
      print "getResourceManager instance failed"
      return False

  def createSetup(self):
    self.typeOfTuningEntry = None
    self.satEntry = None
    self.list = []
    self.tunerEntry = getConfigListEntry(_('Tuner'), self.tuner_number) 
    self.list.append(self.tunerEntry)
    if self.tuner_type == "DVB-S":
      self.satEntry = getConfigListEntry(_('Satellite'), self.tuning_sat)
      self.list.append(self.satEntry)
      self.typeOfTuningEntry = getConfigListEntry(_('Tune'), self.tuning_type)
      self.list.append(self.typeOfTuningEntry)
      nim = nimmanager.nim_slots[self.feid]
      self.systemEntry = None
      if self.tuning_type.value == "manual_transponder":
	if nim.isCompatible("DVB-S2"):
	  self.systemEntry = getConfigListEntry(_('System'), self.scan_sat.system)
	  self.list.append(self.systemEntry)
	else:
	  # downgrade to dvb-s, in case a -s2 config was active
	  self.scan_sat.system.value = eDVBFrontendParametersSatellite.System_DVB_S
	self.list.append(getConfigListEntry(_('Frequency'), self.scan_sat.frequency))
	self.list.append(getConfigListEntry(_('Inversion'), self.scan_sat.inversion))
	self.list.append(getConfigListEntry(_('Symbol rate'), self.scan_sat.symbolrate))
	self.list.append(getConfigListEntry(_('Polarization'), self.scan_sat.polarization))
	if self.scan_sat.system.value == eDVBFrontendParametersSatellite.System_DVB_S:
	  self.list.append(getConfigListEntry(_("FEC"), self.scan_sat.fec))
	elif self.scan_sat.system.value == eDVBFrontendParametersSatellite.System_DVB_S2:
	  if self.scan_sat.modulation.value == eDVBFrontendParametersSatellite.Modulation_QPSK:
	    self.list.append(getConfigListEntry(_("FEC"), self.scan_sat.fec_s2_qpsk))
	  else:
	    self.list.append(getConfigListEntry(_("FEC"), self.scan_sat.fec_s2_8psk))
	  self.modulationEntry = getConfigListEntry(_('Modulation'), self.scan_sat.modulation)
	  self.list.append(self.modulationEntry)
	  self.list.append(getConfigListEntry(_('Roll-off'), self.scan_sat.rolloff))
	  self.list.append(getConfigListEntry(_('Pilot'), self.scan_sat.pilot))
    elif self.tuner_type == "DVB-C":
      self.typeOfTuningEntry = getConfigListEntry(_('Tune'), self.tuning_type)
      if config.Nims[self.feid].cable.scan_type.value != "provider":
	self.tuning_type.value = "manual_transponder"
      else:
        self.list.append(self.typeOfTuningEntry)
      if self.tuning_type.value == "manual_transponder":
	self.list.append(getConfigListEntry(_('Frequency'), self.scan_cab.frequency))
	self.list.append(getConfigListEntry(_('Inversion'), self.scan_cab.inversion))
	self.list.append(getConfigListEntry(_('Symbol rate'), self.scan_cab.symbolrate))
	self.list.append(getConfigListEntry(_('Modulation'), self.scan_cab.modulation))
	self.list.append(getConfigListEntry(_("FEC"), self.scan_cab.fec))
    elif self.tuner_type == "DVB-T":
      self.typeOfTuningEntry = getConfigListEntry(_('Tune'), self.tuning_type)
      self.list.append(self.typeOfTuningEntry)
      if self.tuning_type.value == "manual_transponder":
	self.list.append(getConfigListEntry(_("Frequency"), self.scan_ter.frequency))
	self.list.append(getConfigListEntry(_("Inversion"), self.scan_ter.inversion))
	self.list.append(getConfigListEntry(_("Bandwidth"), self.scan_ter.bandwidth))
	self.list.append(getConfigListEntry(_("Code rate HP"), self.scan_ter.fechigh))
	self.list.append(getConfigListEntry(_("Code rate LP"), self.scan_ter.feclow))
	self.list.append(getConfigListEntry(_("Modulation"), self.scan_ter.modulation))
	self.list.append(getConfigListEntry(_("Transmission mode"), self.scan_ter.transmission))
	self.list.append(getConfigListEntry(_("Guard interval"), self.scan_ter.guard))
	self.list.append(getConfigListEntry(_("Hierarchy info"), self.scan_ter.hierarchy))
    if self.tuning_transponder and self.tuning_type.value == "predefined_transponder":
      self.list.append(getConfigListEntry(_("Transponder"), self.tuning_transponder))
    self["config"].list = self.list
    self["config"].l.setList(self.list)

  def newConfig(self):
    cur = self["config"].getCurrent()
    if cur == self.tunerEntry:
      self.feid = int(self.tuner_number.value)
      self.nextTuner()
      return       
    if self.tuner_type == "DVB-S":
      if cur in (self.typeOfTuningEntry, self.systemEntry):
	self.createSetup()
      elif cur == self.satEntry:
	self.updateSats()
	self.createSetup()
      elif self.scan_sat.system.value == eDVBFrontendParametersSatellite.System_DVB_S2:
        if cur == self.modulationEntry:
  	  self.createSetup()
    elif (self.tuner_type == "DVB-C") or (self.tuner_type == "DVB-T"): 
      if cur == self.typeOfTuningEntry:
	self.createSetup()

  def sat_changed(self, config_element):
    self.newConfig()
    self.retune(config_element)

  def retune(self, configElement):
    if self.tuner_type == "DVB-S":
      satpos = int(self.tuning_sat.value)
      if self.tuning_type.value == "manual_transponder":
	if self.scan_sat.system.value == eDVBFrontendParametersSatellite.System_DVB_S2:
  	  if self.scan_sat.modulation.value == eDVBFrontendParametersSatellite.Modulation_QPSK:
	    fec = self.scan_sat.fec_s2_qpsk.value
	  else:
	    fec = self.scan_sat.fec_s2_8psk.value
	else:
	  fec = self.scan_sat.fec.value
	returnvalue = (0,
	  self.scan_sat.frequency.value,
	  self.scan_sat.symbolrate.value,
	  self.scan_sat.polarization.value,
	  fec,
	  self.scan_sat.inversion.value,
	  satpos,
	  self.scan_sat.system.value,
	  self.scan_sat.modulation.value,
	  self.scan_sat.rolloff.value,
	  self.scan_sat.pilot.value)
	self.tune(returnvalue)
      elif self.tuning_type.value == "predefined_transponder":
	tps = nimmanager.getTransponders(satpos)
	l = len(tps)
	if l > self.tuning_transponder.index:
	  transponder = tps[self.tuning_transponder.index]
          # 0=SAT, 1=freq, 2=sr, 3=pol, 4=fec, 5=system, 6=mod, 7=inv, 8=rolloff, 9=pilot  
	  returnvalue = (transponder[0], (transponder[1]+500)/1000, transponder[2]/1000, transponder[3], 
	    transponder[4], 2, satpos, transponder[5], transponder[6], 3, 2)
	  self.tune(returnvalue)
    elif self.tuner_type == "DVB-C":
      if self.tuning_type.value == "manual_transponder":
	returnvalue = (1,
	  self.scan_cab.frequency.value,
	  self.scan_cab.symbolrate.value,
	  self.scan_cab.modulation.value,
	  self.scan_cab.fec.value,
	  self.scan_cab.inversion.value)
	self.tune(returnvalue)
      elif self.tuning_type.value == "predefined_transponder":
	tps = nimmanager.getTranspondersCable(self.feid)
	l = len(tps)
	if l > self.tuning_transponder.index:
	  transponder = tps[self.tuning_transponder.index]
          freq = transponder[1] / 1000 
          if (self.tuning_transponder.index == 0) and (freq > 510): #Bug in Enigma2
            freq /= 10 
	  returnvalue = (transponder[0], freq, transponder[2]/1000, transponder[3], transponder[4])
	  self.tune(returnvalue)
    elif self.tuner_type == "DVB-T":
      if self.tuning_type.value == "manual_transponder":
	returnvalue = (2,
	  self.scan_ter.frequency.value,
          self.scan_ter.bandwidth.value,
          self.scan_ter.modulation.value, 
	  self.scan_ter.fechigh.value, 
          self.scan_ter.feclow.value,
          self.scan_ter.guard.value, 
          self.scan_ter.transmission.value,
          self.scan_ter.hierarchy.value,
	  self.scan_ter.inversion.value)
	self.tune(returnvalue)
      elif self.tuning_type.value == "predefined_transponder":
        tps = nimmanager.getTranspondersTerrestrial(nimmanager.getTerrestrialDescription(self.feid))
	l = len(tps)
	if l > self.tuning_transponder.index:
	  transponder = tps[self.tuning_transponder.index]
	  returnvalue = (transponder[0], transponder[1]/1000, transponder[2],
	    transponder[3], transponder[4], transponder[5], transponder[6], 
            transponder[7], transponder[8], transponder[9])
	  self.tune(returnvalue)

  def createConfig(self, foo):
    nim_list = []
    for n in nimmanager.nim_slots:
      if not (n.isCompatible("DVB-S") or n.isCompatible("DVB-T") or n.isCompatible("DVB-C")):
	continue
      if n.config_mode  in ("loopthrough", "satposdepends", "nothing"):
	continue
      if n.isCompatible("DVB-S") and n.config_mode == "advanced" and len(nimmanager.getSatListForNim(n.slot)) < 1:
	continue
      nim_list.append((str(n.slot), n.friendly_full_description[6:]))
    default = str(self.feid)
    self.tuner_number = ConfigSelection(choices = nim_list, default = default)
    self.tuner_number.addNotifier(self.retune, initial_call = False)
    self.tuning_transponder = None
    self.tuning_type = ConfigSelection(choices = [("manual_transponder", _("Manual transponder")), ("predefined_transponder", _("Predefined transponder"))])
    ScanSetup.createConfig(self, foo)
    if self.tuner_type == "DVB-S":
      self.tuning_sat = getConfigSatlist(self.default_sat, nimmanager.getSatListForNim(self.feid))
      self.updateSats()
      for x in (self.tuning_type, self.tuning_sat, self.scan_sat.frequency,
	self.scan_sat.inversion, self.scan_sat.symbolrate,
	self.scan_sat.polarization, self.scan_sat.fec, self.scan_sat.pilot,
	self.scan_sat.fec_s2_8psk, self.scan_sat.fec_s2_qpsk, self.scan_sat.fec, self.scan_sat.modulation,
	self.scan_sat.rolloff, self.scan_sat.system):
        x.addNotifier(self.retune, initial_call = False)
    elif self.tuner_type == "DVB-C":
      self.updateSats()
      for x in (self.tuning_type, self.scan_cab.frequency,
	self.scan_cab.inversion, self.scan_cab.symbolrate,
	self.scan_cab.fec, self.scan_cab.modulation):
        x.addNotifier(self.retune, initial_call = False)
    elif self.tuner_type == "DVB-T":
      self.updateSats()
      for x in (self.tuning_type, self.scan_ter.frequency,
        self.scan_ter.inversion, self.scan_ter.bandwidth,
        self.scan_ter.fechigh, self.scan_ter.feclow,
        self.scan_ter.modulation, self.scan_ter.transmission,
        self.scan_ter.guard, self.scan_ter.hierarchy):
        x.addNotifier(self.retune, initial_call = False)

  def updateSats(self):
    fecstr = {0:"Auto", 1:"1/2", 2:"2/3", 3:"3/4", 4:"5/6", 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 15:"None"}
    modstr = ["Auto", "QAM16", "QAM32", "QAM64", "QAM128", "QAM256"]
    bwstr  = ["8 MHz", "7 MHz", "6 MHz", "BW Auto"]
    polstr = ["H", "V", "CL", "CR"]
    list = []
    default = None
    index = 0
    if self.tuner_type == "DVB-S":
      orb_pos = self.tuning_sat.orbital_position
      if orb_pos is not None:
	transponderlist = nimmanager.getTransponders(orb_pos)
	for x in transponderlist:
          pol = polstr[x[3]]
          fec = fecstr[x[4]]
	  e = str((x[1]+500)/1000) + ", " + str(x[2]/1000) + ", " + pol + ", " + fec
	  if default is None:
	    default = str(index)
          list.append((str(index), e))
	  index += 1
    elif self.tuner_type == "DVB-C":
      transponderlist = nimmanager.getTranspondersCable(self.feid)
      for x in transponderlist:
        mod = x[3]
        if mod > eDVBFrontendParametersCable.Modulation_QAM256:
          mod = eDVBFrontendParametersCable.Modulation_Auto  
        mod = modstr[mod]
        freq = x[1] / 1000 
        if (index == 0) and (freq > 510): #Bug in Enigma2
          freq /= 10 
        e = str(freq) + ", " + str(x[2]/1000) + ", " + mod 
	if default is None:
	  default = str(index)
	list.append((str(index), e))
	index += 1
    elif self.tuner_type == "DVB-T":
      transponderlist = nimmanager.getTranspondersTerrestrial(nimmanager.getTerrestrialDescription(self.feid))
      for x in transponderlist:
        bw = bwstr[x[2]]
	e = str(x[1]/1000) + ", " + bw 
	if default is None:
	  default = str(index)
	list.append((str(index), e))
	index += 1
    self.tuning_transponder = ConfigSelection(choices = list, default = default)
    self.tuning_transponder.addNotifier(self.retune, initial_call = False)

  def keyGo(self):
    self.retune(self.tuning_type)

  def tune(self, transponder):
    if self.initcomplete == False:
      self.poll_timer.stop()
      if self.service2 is not None:
        self.oldref = self.session.nav.getCurrentlyPlayingServiceReference()
        self.session.nav.stopService() # try to disable foreground service
      self.service2 = None
      if not self.openFrontend():
	if self.session.pipshown: # try to disable pip
	  self.session.pipshown = False
	  del self.session.pip
	if not self.openFrontend():
	  self.frontend = None # in normal case this should not happen
      self.initcomplete = True
      self.poll_timer.start(self.update_interval, True)
    if transponder is not None:
      if transponder[0] == 0: #DVB-S
	parm = eDVBFrontendParametersSatellite()
	parm.frequency = transponder[1] * 1000
	parm.symbol_rate = transponder[2] * 1000
	parm.polarisation = transponder[3]
	parm.fec = transponder[4]
	parm.inversion = transponder[5]
	parm.orbital_position = transponder[6]
	parm.system = transponder[7]
	self.system = transponder[7]
	parm.modulation = transponder[8]
	parm.rolloff = transponder[9]
	parm.pilot = transponder[10]
	feparm = eDVBFrontendParameters()
	feparm.setDVBS(parm, False)
      elif transponder[0] == 1: #DVB-C
	parm = eDVBFrontendParametersCable()
	parm.frequency = transponder[1] * 1000
	parm.symbol_rate = transponder[2] * 1000
	parm.modulation = transponder[3]
	self.modulation = transponder[3]
	parm.fec_inner = transponder[4]
	parm.inversion = parm.Inversion_Unknown
	feparm = eDVBFrontendParameters()
	feparm.setDVBC(parm)
      elif transponder[0] == 2: #DVB-T
	parm = eDVBFrontendParametersTerrestrial()
	parm.frequency = transponder[1] * 1000
	parm.bandwidth = transponder[2]
	parm.modulation = transponder[3]
	parm.code_rate_HP = transponder[4]
	parm.code_rate_LP = transponder[5]
	parm.guard_interval = transponder[6]
	parm.transmission_mode = transponder[7]
	parm.hierarchy = transponder[8]
	parm.inversion = transponder[9]
	feparm = eDVBFrontendParameters()
	feparm.setDVBT(parm)
      self.parm = parm 	
      self.frontend.tune(feparm)
      frontendData = { }
      self.frontend.getFrontendData(frontendData)
      self.tuner_type = frontendData["tuner_type"]
    self.clearConstellation()

  def clearConstellation(self):
    c = self["Canvas"]
    c.fill(0,0,256,256,0x25101010)
    c.flush()

  def updateConstellation(self):
    if self.constellation_supported or self.constellation_supported is None:
      pass
    else:
      return
    bitmap_list = self.getConstellation(10)
    for bitmap in bitmap_list:
      Q = []
      I = []
      for pos in range(0,30,2):
	try:
 	  val = (int(bitmap[pos:pos+2], 16) + 128) & 0xff
        except ValueError:
	  print "I constellation data broken at pos", pos
	  val = 0
        I.append(val)
      for pos in range(30,60,2):
	try:
 	  val = (int(bitmap[pos:pos+2], 16) + 128) & 0xff
        except ValueError:
	  print "Q constellation data broken at pos", pos
	  val = 0
	Q.append(val)
      c = self["Canvas"]
      for i in range(15):
        c.fill(I[i],Q[i],1,1,0x25ffffff)
      c.flush()

  def getConstellation(self, cnt=1):
    ret = []
    if self.tuner_type == "DVB-S":
      path = "/proc/stb/frontend/%d/constellation_bitmap" %self.feid
      if self.constellation_supported is None:
        s = fileExists(path)
	self.constellation_supported = s
	if not s:
          c = self["Canvas"]
	  c.fill(0,0,256,256,0x25101010)
	  c.flush()
      if self.constellation_supported:
	while cnt > 0:
          f = open(path, "r")
	  ret.append(f.readline())
          cnt -= 1
          f.close()
    if self.tuner_type == "DVB-C":
      path = "/usr/lib/enigma2/python/Plugins/Extensions/Signalfinder/iq"
      if self.constellation_supported is None:
	s = fileExists(path)
	self.constellation_supported = s
	if not s:
          c = self["Canvas"]
	  c.fill(0,0,256,256,0x25101010)
	  c.flush()
      if self.constellation_supported:
        os.system("%s %d %x %x %d" %(path, self.bus, self.i2c_adr, self.i2c_reg, cnt))
        f = open("/tmp/iq.txt", "r")
	while cnt > 0:
	  ret.append(f.readline())
          cnt -= 1
        f.close()
    return ret

  def updateFrontendStatus(self):
#   akt = time()
    if self.frontend is not None:
      status = { }
      self.frontend.getFrontendStatus(status)
    elif self.service2 is not None:
      feinfo = self.service2.frontendInfo()
      status = feinfo and feinfo.getFrontendStatus()
    if status:
      self.lock = status.get("tuner_locked")
      snr = status.get("tuner_signal_quality")
      snr_db = status.get("tuner_signal_quality_db")
      agc = status.get("tuner_signal_power")
      ber = status.get("tuner_bit_error_rate")
      #lock
      self["lock_on"].visible = self.lock
      self["lock_off"].visible = not self.lock
      if self.lock:
        self["lcd_lock"].text = "On"
        self["Info"].setText(_("Info"))
        self["PIDs"].setText(_("PIDs"))
        self["Services"].setText(_("Services"))
      else:  
        self["lcd_lock"].text = "Off"
        self["Info"].setText("")
        self["PIDs"].setText("")
        self["Services"].setText("")

      #agc
      if self.tuner_type == 'DVB-S': #BCM4505
        if self.system == 0:
          agc = (agc / -100) + 270 
        else:
          agc = (agc / -100) + 180
        if agc < 0:
          agc = 0  
        if agc > 100:
          agc = 100  
        text = "%d dB\xb5V" %agc
      else:
        if (self.tuner_type == 'DVB-T') and (self.tunername=="CXD1981"):
          if (agc & 0x3000) == 0:
            agc = 0
          else:
            agc = (agc ^ 0x7ff) & 0xfff
            agc = (agc * 100) / 4096
        else:
          agc = (agc * 100) / 65536 
        text = "%d %%" %agc
      self["agc_val"].setText(text)
      self["lcd_agc"].text = text
      self["agc_bar"].value = agc

      #snr
      if snr_db is None:
        if self.tunername=="CXD1981":
          snr = ~snr & 0xff
          if self.tuner_type == 'DVB-C':
            if (snr == 0):
              snr_db = 0
            else:
              if (self.modulation==2) or (self.modulation==4): 
                snr_db = int(875.0 * log(650.0 / snr))
              else:
                snr_db = int(950.0 * log(760.0 / snr))
          else: #DVB-T
            snr_db = (snr * 25) / 2
        elif (self.tuner_type == 'DVB-T') and self.lock: #TU1216 
          snr_db = 2700
        else: #CU1216, BCM7405
          snr_db = 0
      elif snr_db == 0x7fffffff: 
        snr_db = 0
      text = "%3.01f dB" %(snr_db / 100.0)
      self["snr_val"].setText(text)
      self["lcd_snr"].text = text 
      snr_bar=0 # just fix crashes ...
      if self.tuner_type == 'DVB-S':
        snr_bar = snr_db / 17     
      elif self.tuner_type == 'DVB-C':
        snr_bar = snr_db / 42     
      elif self.tuner_type == 'DVB-T':
        snr_bar = snr_db / 32
      self["snr_bar"].value = snr_bar

      #ber
      if ber==0: 
        text = str(ber)
      else:
        text = "%.1E" %(ber * 1.0E-8)
      self["ber_val"].setText(text)
      self["lcd_ber"].text = text
      if not self.lock:
        self["ber_bar"].value = 0
      elif ber == 0: 
        self["ber_bar"].value = 100
      else:
        self["ber_bar"].value = 100 - int(12.5 * log10(ber))

    self.updateConstellation()
    self.poll_timer.start(self.update_interval, True)
#   akt = time() - akt
#   print "Zeit=", akt 

  def setParameter(self):
    if self.tuning_type.value == "manual_transponder":
      if self.service2 is not None:
        self.keyGo()		    
      if self.lock:
        data = { }
        self.frontend.getTransponderData(data, False)
        if self.tuner_type == "DVB-S":
          self.scan_sat.inversion.value = data.get("inversion")
          self.scan_sat.modulation.value = data.get("modulation")
          self.scan_sat.symbolrate.value = (data.get("symbol_rate") + 500) / 1000
          self.scan_sat.polarization.value = data.get("polarization")
          self.scan_sat.frequency.value = (data.get("frequency") + 500) / 1000
          self.scan_sat.pilot.value = data.get("pilot")
          self.scan_sat.rolloff.value = data.get("rolloff")
          self.scan_sat.system.value = data.get("system")
          fec = data.get("fec_inner")
          if self.scan_sat.system.value == eDVBFrontendParametersSatellite.System_DVB_S2:
            if self.scan_sat.modulation.value == eDVBFrontendParametersSatellite.Modulation_QPSK:
              self.scan_sat.fec_s2_qpsk.value = fec 
            else:
              self.scan_sat.fec_s2_8psk.value = fec
          else:
            self.scan_sat.fec.value = fec
        elif self.tuner_type == "DVB-C":
          self.scan_cab.frequency.value = (data.get("frequency") + 500) / 1000
          self.scan_cab.symbolrate.value = (data.get("symbol_rate") + 500) / 1000
          self.scan_cab.modulation.value = data.get("modulation")
          self.scan_cab.fec.value = data.get("fec_inner")
          self.scan_cab.inversion.value = data.get("inversion")
        elif self.tuner_type == "DVB-T":
          self.scan_ter.frequency.value = (data.get("frequency") + 500) / 1000
          self.scan_ter.bandwidth.value = data.get("bandwidth")
          self.scan_ter.inversion.value = data.get("inversion")
          self.scan_ter.modulation.value = data.get("constellation") 
          self.scan_ter.guard.value = data.get("guard_interval") 
          self.scan_ter.transmission.value = data.get("transmission_mode")
          self.scan_ter.hierarchy.value = data.get("hierarchy_information")
          self.scan_ter.fechigh.value = data.get("code_rate_hp") 
          if self.scan_ter.hierarchy.value == eDVBFrontendParametersTerrestrial.Hierarchy_None:
            self.scan_ter.feclow.value = eDVBFrontendParametersTerrestrial.FEC_Auto
          else: 
            self.scan_ter.feclow.value = data.get("code_rate_lp")
        else:
          return
        self.createSetup()

  def startScanner(self):
    if self.service2 is not None:
      self.keyGo()		    
    self.initcomplete = False
    self.poll_timer.stop()
    if self.tuner_type == "DVB-S":
      from Satscan import Satscan
      self.session.openWithCallback(self.startScanCallback, Satscan, self.frontend)
    else:
      from Cablescan import Cablescan
      self.session.openWithCallback(self.startScanCallback, Cablescan, self.frontend)
    
  def keyCancel(self):
    self.poll_timer.stop()
    if self.frontend:
      self.frontend = None
      del self.raw_channel
    if self.oldref is not None: 
      self.session.nav.playService(self.oldref)
    self.close(None)

  def startServiceScan(self):
    if self.lock:
      if self.service2 is not None:
        self.keyGo()		    
      self.initcomplete = False
      self.poll_timer.stop()
      self.frontend = None
      if self.raw_channel:
        del(self.raw_channel)
      tlist = []
      tlist.append(self.parm)
      flags = 0
      from Screens.ServiceScan import ServiceScan
      self.session.openWithCallback(self.startScanCallback, ServiceScan, [{"transponders": tlist, "feid": self.feid, "flags": flags}])

  def startPIDsScan(self):
    if self.lock:
      if self.service2 is not None:
        self.keyGo()
      self.initcomplete = False
      self.poll_timer.stop()
      demux = self.raw_channel.reserveDemux()
      self.session.openWithCallback(self.startScanCallback, PIDsScan, demux)
      		    
  def startScanCallback(self, answer=None):
    self.keyGo()		    

  def createSummary(self):
    return SignalfinderLCD

################################################################################

def SignalfinderMain(session, **kwargs):
  nims = nimmanager.nim_slots
  nimList = []
  for n in nims:
    if not (n.isCompatible("DVB-S") or n.isCompatible("DVB-T") or n.isCompatible("DVB-C")):
      continue
    if n.config_mode  in ("loopthrough", "satposdepends", "nothing"):
      continue
    if n.isCompatible("DVB-S") and n.config_mode == "advanced" and len(nimmanager.getSatListForNim(n.slot)) < 1:
      continue
    nimList.append(n)
  if len(nimList) == 0:
    session.open(MessageBox, _("No satellite, terrestrial or cable tuner is configured. Please check your tuner setup."), MessageBox.TYPE_ERROR)
  else:
    session.open(Signalfinder)

def SignalfinderStart(menuid, **kwargs):
  if menuid == "scan":
    return [("Signalfinder", SignalfinderMain, "signalfinder", None)]
  else:
    return []

def Plugins(**kwargs):
  if nimmanager.hasNimType("DVB-S") or nimmanager.hasNimType("DVB-T") or nimmanager.hasNimType("DVB-C"):
    return [PluginDescriptor(name="Signalfinder", description=_("Helps setting up your antenna"), 
                             where = [PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU], 
                             needsRestart = False, fnc=SignalfinderMain),
            PluginDescriptor(name="Signalfinder", description=_("Helps setting up your antenna"), 
                             where = PluginDescriptor.WHERE_MENU, needsRestart = False, fnc=SignalfinderStart)]
  else:
    return []
