##########################################################################

from math import log
from enigma import eDVBResourceManager, eDVBFrontendParameters
from enigma import gFont, RT_HALIGN_RIGHT
from enigma import eDVBFrontendParametersCable, eDVBFrontendParametersTerrestrial
from enigma import eTimer 

from Screens.Screen import Screen
from Components.Sources.CanvasSource import CanvasSource
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.NimManager import nimmanager

def RGB(r,g,b):
  return (r<<16)|(g<<8)|b

modstr = ["Auto", "QAM16", "QAM32", "QAM64", "QAM128", "QAM256"]
conststr = ["QPSK", "QAM16", "QAM64", "Auto"]
fec_t_str = {0:"1/2", 1:"2/3", 2:"3/4", 3:"5/6", 4:"7/8", 5:"Auto", 6:"6/7", 7:"8/9"}
fec_c_str = {0:"Auto", 1:"1/2", 2:"2/3", 3:"3/4", 4:"5/6", 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 15:"None"}
guardstr = ["1/32", "1/16", "1/8", "1/4", "Auto"] 
transstr = ["2K", "8K", "Auto"] 
invstr = ["OFF", "ON", "Auto"]
bwstr = ["8 MHz", "7 MHz", "6 MHz", "Auto"]

###########################################################################

class Cablescan(Screen):
  skin = """
    <screen position="center,100" size="930,500" title="Cablescan">
    <widget source="Canvas" render="Canvas" position="0,0" size="930,400"/>
    <widget name="Tuner" position="10,400" valign="center" size="360,30" font="Regular;20"/>
    <widget name="Frequency" position="10,430" valign="center" size="850,30" font="Regular;20"/>
    <eLabel text="Exit" position="10,460" size="100,40" 
      backgroundColor="red" valign="center" halign="center" zPosition="2" 
      foregroundColor="white" font="Regular;20"/>
    <widget name="Start" position="120,460" size="100,40" 
      backgroundColor="green" valign="center" halign="center" zPosition="2" 
      foregroundColor="white" font="Regular;20"/>
    <widget name="LeftBtn" position="230,460" size="100,40" 
      backgroundColor="black" valign="center" halign="center" zPosition="2" 
      foregroundColor="white" font="Regular;20"/>
    <widget name="RightBtn" position="340,460" size="100,40" 
      backgroundColor="black" valign="center" halign="center" zPosition="2" 
      foregroundColor="white" font="Regular;20"/>
    </screen>"""
   
  def __init__(self, session, frontend):
    self.session = session
    self.frontend = frontend
    self.marker = 0
    self.found = 0
    self.searching = False
    Screen.__init__(self, session)
    self["Canvas"] = CanvasSource()
    self["Tuner"] = Label()
    self["Frequency"] = Label()
    self["Start"] = Label(_("Start"))
    self["LeftBtn"] = Label()
    self["RightBtn"] = Label()
    data = {}
    if self.frontend is not None: # just fix crashes ...
	self.frontend.getFrontendData(data)
    self.feid = data.get("tuner_number")

    if nimmanager is not None: # just fix crashes ...
	self.tuner_type = nimmanager.getNimType(self.feid)
	self.tunername = nimmanager.getNimName(self.feid)
	text = nimmanager.getNimDescription(self.feid) 
    else:
	self.tuner_type="unknown"
	self.tunername="unknown"
	text=""
    
    self["Tuner"].setText(text)
    self["ActionMap"] = ActionMap(["SetupActions","ColorActions"],
    {
      "red": self.cancel,
      "cancel": self.cancel,
      "ok": self.startAnalyser,
      "green": self.startAnalyser,
      "right": self.marker_up,
      "left": self.marker_down,
    }, -1)
    self.box()

  def snr_to_db(self, i):
    frq = self.frqtab[i]
    snr = self.snrtab[i] 
    if snr > 0:
      pos = snr * 2 / 25 
      if (self.tuner_type=="DVB-C") and (self.srtab[i] > 6950):
        color = RGB(255, 255, 0) #DOCSIS is yellow 
      else:
        color = RGB(0, 255, 0)   #green
      self["Canvas"].fill(frq-2, 360-pos, 6, pos, color)

  def box(self):
    fg = RGB(255, 255, 255)
    bg = RGB(0,0,0)
    font = gFont("Regular", 20) 
    c = self["Canvas"]
    c.fill(0, 0, 930, 400, bg) # Hintergrund
    c.fill(50, 30, 2, 330, fg)  # Y-Achse
    c.fill(50, 360, 850, 2, fg) # X-Achse (x,y,Breite,Hoehe,Farbe)
    for i in range(9):    # dB-Skala
      c.fill(40, 40+40*i, 10, 2, fg) # Striche
      c.writeText(0, 30+40*i, 30, 20, fg, bg, font, str(40-5*i),RT_HALIGN_RIGHT) # Zahlen
    c.writeText(5, 0, 30, 20, fg, bg, font, "dB")
    for i in range(18):
      c.fill(50+50*i, 360, 2, 10, fg)
    c.writeText(40, 370, 50, 20, fg, bg, font, "50")
    for i in range(16):
      c.writeText(84+50*i, 370, 60, 20, fg, bg, font, str(100+50*i)) # Frequenzen
    c.writeText(880, 370, 50, 20, fg, bg, font, "MHz")
    if self.found > 0:
      for i in range(self.found):
        self.snr_to_db(i)
      c.fill(self.frqtab[self.marker], 30, 2, 330, RGB(255, 0, 0)) # Marker
    c.flush()
    self.setFrequency(self.marker)

  def marker_up(self):
    if (self.found > 0) and (not self.searching):
      bg = RGB(0,0,0)
      c = self["Canvas"]
      c.fill(self.frqtab[self.marker], 30, 2, 330, bg)
      self.snr_to_db(self.marker)
      self.marker += 1
      if(self.marker >= self.found):
        self.marker = 0
      self.snr_to_db(self.marker)
      c.fill(self.frqtab[self.marker], 30, 2, 330, RGB(255, 0, 0))
      c.flush()
      self.setFrequency(self.marker)
      
  def marker_down(self):
    if (self.found > 0) and (not self.searching):
      bg = RGB(0,0,0)
      c = self["Canvas"]
      c.fill(self.frqtab[self.marker], 30, 2, 330, bg)
      self.snr_to_db(self.marker)
      if(self.marker <= 0):
        self.marker = self.found-1
      else:
        self.marker -= 1
      self.snr_to_db(self.marker)
      c.fill(self.frqtab[self.marker], 30, 2, 330, RGB(255, 0, 0))
      c.flush()
      self.setFrequency(self.marker)
      
  def setFrequency(self, i):
    if self.found > 0:
      text = "%d MHz" % self.frqtab[i]
      db = float(self.snrtab[i]) / 100
      mod = self.modtab[i]
      fec = self.fectab[i]
      agc = (100 * self.agctab[i]) / 65536;
      if self.tuner_type == "DVB-C":
        sr = self.srtab[i] 
        text = text + ", SNR %2.1f dB, AGC %d%%, %d kBaud, " % (db,agc,sr) + modstr[mod]  
      elif self.tuner_type == "DVB-T":
        guard = self.guardtab[i]
        trans = self.transtab[i]
        bw = self.bwtab[i]
        text = text + ", SNR %2.1f dB, AGC %d%%, FEC " % (db,agc) + fec_t_str[fec] + ", " + conststr[mod]
        text = text + ", " + transstr[trans] + ", Guard Int. " + guardstr[guard] + ", " + bwstr[bw]
    else:
      text = ""
    self["Frequency"].setText(text)

  def startAnalyser(self):
    if not self.searching:
      self.frqtab = []
      self.snrtab = []
      self.agctab = []
      self.srtab = []
      self.modtab = []
      self.fectab = []
      self.invtab = []
      self.bwtab = []
      self.guardtab = []
      self.transtab = []
      self.marker = 0
      self.found = 0
      self.box()
      self["Start"].setText("")
      self["LeftBtn"].setText("")
      self["RightBtn"].setText("")
      if (self.tuner_type=="DVB-C"):
        self.tps = nimmanager.getTranspondersCable(self.feid)
      elif (self.tuner_type=="DVB-T"):
        self.tps = nimmanager.getTranspondersTerrestrial(nimmanager.getTerrestrialDescription(self.feid))
      self.transponder_index = 0
      self.l = len(self.tps)
      self.searching = True
      self.poll_timer = eTimer()
      self.poll_timer.callback.append(self.updateFrontendStatus)
      self.nextTune()


  def updateFrontendStatus(self):
    status = { }
    self.frontend.getFrontendStatus(status)
    if status:
      lock = status.get("tuner_locked")
      if lock == 1:
        data = { }
        self.frontend.getTransponderData(data, False)
        snr = status.get("tuner_signal_quality")
        snr_db = status.get("tuner_signal_quality_db")
        agc = status.get("tuner_signal_power")
        frq = data.get("frequency")
        inv = data.get("inversion")
        if (self.tuner_type=="DVB-C"):
          sr = data.get("symbol_rate")
          fec = data.get("fec_inner")
          mod = data.get("modulation")
          if self.tunername=="CXD1981":
            self.frqtab.append(frq/1000)
            self.srtab.append(self.sr/1000) #vom CXD1981 gelieferte Symbolrate ist zu ungenau 
          else: #CU1216
            self.frqtab.append(self.freq/1000) #Bug in CU1216-Treiber
            self.srtab.append(sr/1000)
          if snr_db is None:
            if self.tunername=="CXD1981":
              snr = ~snr & 0xff
              if snr == 0:
                snr_db = 0
              else:
                if (mod==2) or (mod==4): 
                  snr_db = int(875.0 * log(650.0 / snr))
                else:
                  snr_db = int(950.0 * log(760.0 / snr))
            else: #CU1216
              snr_db = 0
          self.snrtab.append(snr_db)
          self.agctab.append(agc)
          self.invtab.append(inv)
          self.fectab.append(fec)
          self.modtab.append(mod)
        elif (self.tuner_type=="DVB-T"):
          if self.tunername=="CXD1981":
            agc = ((agc ^ 0x7ff) & 0xfff) << 4
          if snr_db is None: 
            if self.tunername=="CXD1981":
              snr_db = ((~snr & 0xff) * 25) / 2 
            else: #TU1216
              snr_db = 2700
          self.snrtab.append(snr_db)
          self.agctab.append(agc)
          bw = data.get("bandwidth")
          tm = data.get("transmission_mode")
          hi = data.get("hierarchy_information")
          guard = data.get("guard_interval")
          code_rate_hp = data.get("code_rate_hp")
          code_rate_lp = data.get("code_rate_lp")
          mod = data.get("constellation")
          self.frqtab.append(frq/1000000)
          self.bwtab.append(bw)
          self.invtab.append(inv)
          self.fectab.append(code_rate_hp)
          self.modtab.append(mod)
          self.transtab.append(tm)
          self.guardtab.append(guard)
        self.snr_to_db(self.found)
        self["Canvas"].flush()
        self.found += 1 
      self.nextTune()

  def nextTune(self):
    if self.l > self.transponder_index:
      transponder = self.tps[self.transponder_index]
      self.transponder_index += 1
      if (self.tuner_type=="DVB-C"):
        self.freq = transponder[1] 
        if (self.transponder_index == 1) and (self.freq > 510000): #Bug in Enigma2
          self.freq /= 10 
        text = "%d MHz" % (self.freq/1000) 
        self["Frequency"].setText(text)
	parm = eDVBFrontendParametersCable()
	parm.frequency = self.freq 
	self.sr = transponder[2]
	parm.symbol_rate = transponder[2]
	parm.modulation = transponder[3]
	parm.fec_inner = 0
	parm.inversion = parm.Inversion_Unknown
	feparm = eDVBFrontendParameters()
	feparm.setDVBC(parm)
        update_interval = 400
      elif (self.tuner_type=="DVB-T"):
        text = "%d MHz" % (transponder[1]/1000000) 
        self["Frequency"].setText(text)
	parm = eDVBFrontendParametersTerrestrial()
	parm.frequency = transponder[1]
	parm.bandwidth = transponder[2]
	parm.modulation = transponder[3]
	parm.code_rate_HP = transponder[4]
	parm.code_rate_LP = transponder[5]
	parm.guard_interval = transponder[6]
	parm.transmission_mode = transponder[7]
	parm.hierarchy = transponder[8]
	parm.inversion = transponder[9]
	feparm = eDVBFrontendParameters()
	feparm.setDVBT(parm)
        update_interval = 850
      self.frontend.tune(feparm)
      self.poll_timer.start(update_interval, True)
    else:
      self.scanReady()

  def scanReady(self):
    self.searching = False
    self.poll_timer.stop()
    self.box()
    self["LeftBtn"].setText("<")
    self["RightBtn"].setText(">")
    self["Start"].setText(_("Start"))
  
  def cancel(self):
    if self.searching:
      self.scanReady()
    else:
      self.close()
            