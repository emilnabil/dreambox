##########################################################################

from enigma import eDVBResourceManager, eDVBFrontendParameters
from enigma import gFont, RT_HALIGN_RIGHT
from enigma import eDVBFrontendParametersSatellite

from Screens.Screen import Screen
from Components.Sources.CanvasSource import CanvasSource
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.NimManager import nimmanager

def RGB(r,g,b):
  return (r<<16)|(g<<8)|b

modstr = ["Auto", "QPSK", "8PSK", "QAM16"]
fecstr = {0:"Auto", 1:"1/2", 2:"2/3", 3:"3/4", 4:"5/6", 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
pilotstr = ["ON", "OFF", "AUTO"]
invstr = ["OFF", "ON", "AUTO"]
rolloffstr = ["35", "20", "25", "AUTO"] 
systemstr = ["DVB-S", "DVB-S2"]    

###########################################################################

class Satscan(Screen):
  skin = """
    <screen position="center,100" size="1110,500" title="Satscan">
    <widget source="Canvas" render="Canvas" position="0,0" size="1110,400"/>
    <widget name="Tuner" position="10,400" valign="center" size="320,30" font="Regular;20"/>
    <widget name="Sat" position="340,400" valign="center" size="400,30" font="Regular;20"/>
    <widget name="Pol" position="750,400" valign="center" size="100,30" font="Regular;20"/>
    <widget name="Frequency" position="10,430" valign="center" size="900,30" font="Regular;20"/>
    <eLabel text="Exit" position="10,460" size="100,40" 
     backgroundColor="red" valign="center" halign="center" zPosition="2" 
      foregroundColor="white" font="Regular;20"/>
    <widget name="Horizontal" position="120,460" size="100,40" 
      backgroundColor="green" valign="center" halign="center" zPosition="2" 
      foregroundColor="white" font="Regular;20"/>
    <widget name="Vertical" position="230,460" size="100,40" 
      backgroundColor="yellow" valign="center" halign="center" zPosition="2" 
      foregroundColor="white" font="Regular;20"/>
    <widget name="LeftBtn" position="340,460" size="100,40" 
      backgroundColor="black" valign="center" halign="center" zPosition="2" 
      foregroundColor="white" font="Regular;20"/>
    <widget name="RightBtn" position="450,460" size="100,40" 
      backgroundColor="black" valign="center" halign="center" zPosition="2" 
      foregroundColor="white" font="Regular;20"/>
    </screen>"""
   
  def __init__(self, session, frontend):
    self.frontend = frontend
    self.marker = 0
    self.found = 0
    self.searching = False
    Screen.__init__(self, session)
    self["Canvas"] = CanvasSource()
    self["Tuner"] = Label()
    self["Sat"] = Label()
    self["Pol"] = Label()
    self["Frequency"] = Label()
    self["LeftBtn"] = Label()
    self["RightBtn"] = Label()
    self["Horizontal"] = Label(_("Horizontal"))
    self["Vertical"] = Label(_("Vertical"))
    data = {}
    self.frontend.getFrontendData(data)
    self.feid = data.get("tuner_number")
    text = nimmanager.getNimDescription(self.feid) 
    self["Tuner"].setText(text)
    data = { }
    self.frontend.getTransponderData(data,True)
    self.satpos = data.get("orbital_position")
    text = nimmanager.getSatName(self.satpos)
    self["Sat"].setText(text)
    self["ActionMap"] = ActionMap(["SetupActions","ColorActions"],
    {
      "red": self.cancel,
      "cancel": self.cancel,
      "green": self.startHorizontal,
      "yellow": self.startVertical,
      "right": self.marker_up,
      "left": self.marker_down,
    }, -1)
    self.box()

  def snr_to_db(self, i):
    frq = self.frqtab[i]
    snr = self.snrtab[i] 
    width = (self.srtab[i] / 1850) + 1
    if snr > 0:
      pos = snr * 4 / 25 
      if self.systab[i] == 0:
        color = RGB(0, 255, 0)   #DVB-S is green
      else:
        color = RGB(255, 255, 0) #DVB-S2 is yellow 
      self["Canvas"].fill((frq-10700)/2+50-(width/2), 360-pos, width, pos, color)

  def box(self):
    fg = RGB(255, 255, 255)
    bg = RGB(0,0,0)
    font = gFont("Regular", 20) 
    c = self["Canvas"]
    c.fill(0, 0, 1110, 400, bg) # Hintergrund
    c.fill(50, 30, 2, 330, fg)  # Y-Achse
    c.fill(50, 360, 1025, 2, fg) # X-Achse (x,y,Breite,Hoehe,Farbe)
    for i in range(11):    # dB-Skala
      c.fill(40, 40+32*i, 10, 2, fg) # Striche
      c.writeText(0, 30+32*i, 30, 20, fg, bg, font, str(20-2*i),RT_HALIGN_RIGHT) # Zahlen
    c.writeText(5, 0, 30, 20, fg, bg, font, "dB")
    for i in range(21):
      c.fill(50+50*i, 360, 2, 10, fg)
    for i in range(21):
      ghz = float(10700+100*i)/1000.0
      text = "%2.1f" % (ghz)  
      c.writeText(27+50*i, 374, 60, 20, fg, bg, font, text)
    c.writeText(1070, 374, 50, 20, fg, bg, font, "GHz")
    if self.found > 0:
      for i in range(self.found):
        self.snr_to_db(i)
      c.fill((self.frqtab[self.marker]-10700)/2+50, 30, 2, 330, RGB(255, 0, 0)) # Marker
    c.flush()
    self.setFrequency(self.marker)

  def marker_up(self):
    if (self.found > 0) and (not self.searching):
      bg = RGB(0,0,0)
      c = self["Canvas"]
      c.fill((self.frqtab[self.marker]-10700)/2+50, 30, 2, 330, bg)
      self.snr_to_db(self.marker)
      self.marker += 1
      if(self.marker >= self.found):
        self.marker = 0
      self.snr_to_db(self.marker)
      c.fill((self.frqtab[self.marker]-10700)/2+50, 30, 2, 330, RGB(255, 0, 0))
      c.flush()
      self.setFrequency(self.marker)
      
  def marker_down(self):
    if (self.found > 0) and (not self.searching):
      bg = RGB(0,0,0)
      c = self["Canvas"]
      c.fill((self.frqtab[self.marker]-10700)/2+50, 30, 2, 330, bg)
      self.snr_to_db(self.marker)
      if(self.marker <= 0):
        self.marker = self.found-1
      else:
        self.marker -= 1
      self.snr_to_db(self.marker)
      c.fill((self.frqtab[self.marker]-10700)/2+50, 30, 2, 330, RGB(255, 0, 0))
      c.flush()
      self.setFrequency(self.marker)
      
  def setFrequency(self, i):
    if self.found > 0:
      frq = self.frqtab[i] 
      db = float(self.snrtab[i]) / 100
      mod = self.modtab[i]
      fec = self.fectab[i]
      agc = self.agctab[i]
      sr = self.srtab[i] 
      inv = self.invtab[i] 
      system = self.systab[i] 
      if system == 0:
        agc = (agc / -100) + 270
      else:
        agc = (agc / -100) + 180
      text = "%d MHz, SNR=%2.1f dB, AGC=%d dB\xb5V, %d kBaud, " % (frq,db,agc,sr) + systemstr[system] 
      text = text + ", " + modstr[mod] + ", FEC " + fecstr[fec] + ", Inv. " + invstr[inv]   
    else:
      text = ""
    self["Frequency"].setText(text)

  def startHorizontal(self):
    if not self.searching:
      self["Pol"].setText(_("Horizontal"))
      self.readTransponders(0)
      self.startAnalyser()
    
  def startVertical(self):
    if not self.searching:
      self["Pol"].setText(_("Vertical"))
      self.readTransponders(1)
      self.startAnalyser()
    
  def startAnalyser(self):
    self.frqtab = []
    self.snrtab = []
    self.agctab = []
    self.srtab = []
    self.invtab = []
    self.modtab = []
    self.fectab = []
    self.systab = []
    self.pilottab = []
    self.rollofftab = []
    self.marker = 0
    self.found = 0
    self.transponder_index = 0
    self.box()
    self["LeftBtn"].setText("")
    self["RightBtn"].setText("")
    self["Horizontal"].setText("")
    self["Vertical"].setText("")
    self.searching = True
    self.frontend.getStateChangeSignal().append(self.updateFrontendStatus)
    self.nextTune()
      
  def updateFrontendStatus(self, frontend_ptr):
    status = { }
    self.frontend.getFrontendStatus(status)
    if status:
      snr = status.get("tuner_signal_quality_db")
      agc = status.get("tuner_signal_power")
      state = status.get("tuner_state") 
#      print "tuner_state=", state        
      if state in ("LOCKED", "LOSTLOCK", "FAILED"):
	if state == "LOCKED":
          data = { }
          self.frontend.getTransponderData(data, False)
          frq = data.get("frequency")
          sr = data.get("symbol_rate")
          inv = data.get("inversion")
          sys = data.get("system")
          fec = data.get("fec_inner")
          mod = data.get("modulation")
          self.frqtab.append((frq+500)/1000)
          self.snrtab.append(snr)
          self.agctab.append(agc)
          self.srtab.append((sr+500)/1000)
          self.invtab.append(inv)
          self.fectab.append(fec)
          self.modtab.append(mod)
          self.systab.append(sys)
          if sys==1:
            pilot = data.get("pilot")
            rolloff = data.get("rolloff")
            self.pilottab.append(pilot)
            self.rollofftab.append(rolloff)
          self.snr_to_db(self.found)
          self["Canvas"].flush()
          self.found += 1
        self.nextTune()

  def nextTune(self):
    if self.l > self.transponder_index:
      transponder = self.tps[self.transponder_index]
      # 0=SAT, 1=freq, 2=sr, 3=pol, 4=fec, 5=system, 6=mod, 7=inv, 8=rolloff, 9=pilot  
      self.transponder_index += 1
      text = "%d MHz" % ((transponder[1]+500)/1000) 
      self["Frequency"].setText(text)
      parm = eDVBFrontendParametersSatellite()
      parm.frequency = transponder[1]
      parm.symbol_rate = transponder[2]
      parm.polarisation = transponder[3]
      parm.fec = transponder[4]
      parm.inversion = 2
      parm.orbital_position = self.satpos
      parm.system = transponder[5]
      parm.modulation = transponder[6]
      parm.rolloff = 3
      parm.pilot = 2
      feparm = eDVBFrontendParameters()
      feparm.setDVBS(parm, False)
      self.frontend.tune(feparm)
    else:
      self.scanReady()

  def readTransponders(self, pol):
    self.tps = []
    tps = nimmanager.getTransponders(self.satpos)
    tps.sort()
    transponder_index = 0
    l = len(tps)
    while l > transponder_index:
      transponder = tps[transponder_index]
      # 0=SAT, 1=freq, 2=sr, 3=pol, 4=fec, 5=system, 6=mod, 7=inv, 8=rolloff, 9=pilot  
      transponder_index += 1
      if transponder[3] != pol:
        continue 
      self.tps.append(transponder)
    self.l = len(self.tps)

  def scanReady(self):
    self.searching = False
    self.frontend.getStateChangeSignal().remove(self.updateFrontendStatus)
    self.box()
    self["LeftBtn"].setText("<")
    self["RightBtn"].setText(">")
    self["Horizontal"].setText(_("Horizontal"))
    self["Vertical"].setText(_("Vertical"))
  
  def cancel(self):
    if self.searching:
      self.scanReady()
    else:
      self.close()
